import os
import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

pattern = r'suspend fun exportRaBillToCsv.*?return "Opening PDF Preview\.\.\."\n    \}'

replacement = """suspend fun exportRaBillToCsv(
        context: Context,
        project: Project,
        raBill: RaBill,
        boqItems: List<BoqItem>,
        raBillItems: List<RaBillItem>
    ): String {
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>")
            append("@page { size: A4 landscape; margin: 10mm; }")
            append("body { font-family: sans-serif; font-size: 10px; line-height: 1.2; }")
            append(".page-break { page-break-after: always; }")
            append(".center { text-align: center; }")
            append(".right { text-align: right; }")
            append(".left { text-align: left; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 5px; font-size: 10px; }")
            append("th, td { border: 1px solid black; padding: 3px; text-align: right; }")
            append(".no-border { border: none !important; }")
            append("th { background-color: #f2f2f2; text-align: center; }")
            append(".th-left { text-align: left; }")
            append("</style></head><body>")

            // Page 1: Cover
            append("<div class='page-break'>")
            append("<h3 class='center'>Pimpri-Chinchwad Muncipal Corporation, Pimpri 411 018</h3>")
            append("<table style='width: 100%; border: 1px solid black;'>")
            append("<tr>")
            
            append("<td style='width: 50%; vertical-align: top; border-right: 1px solid black; padding: 10px; text-align: left;'>")
            append("<p>Administrative Approval:- Rs. \${project.estimateAmount} /-</p>")
            append("<p>Technical Sanction:- Rs. \${project.estimateAmount} /-</p>")
            append("<p>Tendor Amount : Rs. \${project.agreementAmount} /-</p>")
            append("<p>Total Rs : Rs. \${String.format("%.2f", raBill.grossAmount)} /-</p>")
            append("<br>")
            append("<p>Tendor No:- \${project.tenderNumber}</p>")
            append("<br><br><br><br>")
            append("<p><b>JUNIOR ENGINEER</b></p><br><br><br>")
            append("<p><b>DEPUTY ENGINEER</b></p><br><br><br>")
            append("<p>Checked</p><br><br><br>")
            append("<p>Accounts clerk &nbsp;&nbsp;&nbsp;&nbsp; Divisional Accountant</p>")
            append("</td>")
            
            append("<td style='width: 50%; vertical-align: top; padding: 10px; text-align: left;'>")
            append("<table style='width: 100%; border: none; margin: 0;'>")
            append("<tr><td class='left no-border' style='padding: 0;'>DIVISION</td><td class='left no-border' style='padding: 0;'>Engineering</td></tr>")
            append("<tr><td class='left no-border' style='padding: 0; padding-top: 5px;'>SUB-DIVISION</td><td class='left no-border' style='padding: 0;'></td></tr>")
            append("<tr><td class='left no-border' style='padding: 0; padding-top: 5px;' colspan='2'>Department : \${project.department}</td></tr>")
            append("</table>")
            append("<br>")
            append("<p>Running Account Bill: \${raBill.billNumber}</p>")
            append("<p>(Referred to in Paragraph 10.2.11 of M.P.W.A Code)</p>")
            append("<p>Cash Book &nbsp;&nbsp;&nbsp;&nbsp; Voucher No.</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -10px;'>")
            append("<p><b>Name of the Contractor or Suppliers:-</b><br>\${project.contractorName}</p>")
            append("<p>PAN No.:</p>")
            append("<p>GST No.:</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -10px;'>")
            append("<p><b>Name of Work:-</b><br>\${project.workName}</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -10px;'>")
            append("<p>Serial No. of this Bill- \${raBill.billNumber}</p>")
            append("<br>")
            append("<p>No. and date of previous bill for this work:-</p>")
            append("<p>Reference to agreement :-</p>")
            append("<p><b>Accepted by - S.C.R.No. &nbsp;&nbsp;&nbsp;&nbsp; Dated</b></p>")
            append("<p>Date of written order to commence work:<br>\${project.workOrderNumber}</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -10px;'>")
            append("<p>Date of Completion as stipulated in the contract-</p>")
            append("<p>Extension granted upto--</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -10px;'>")
            append("<p>Date of actual completion of work:-</p>")
            append("<p>Contractor's Ledger Folio No.<br>(for Use in Account General's Office)</p>")
            append("<br>")
            append("<p>Audited &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Review Superident</p>")
            append("<br>")
            append("<p>Auditor &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gazetted Officer</p>")
            append("</td>")
            
            append("</tr>")
            append("</table>")
            append("</div>")

            // Page 2: Part 1
            append("<div class='page-break'>")
            append("<table style='width: 100%; border: 1px solid black; text-align: center; font-size: 9px; border-collapse: collapse;'>")
            append("<tr><td colspan='11' class='center'><b>Part 1- ACCOUNT OF WORK EXECUTED</b></td></tr>")
            append("<tr>")
            append("<td colspan='4' class='left'>Items of work: Grouped under sub-heads or sub work of estimate</td>")
            append("<td colspan='3'></td>")
            append("<td colspan='4'>Payments on the basis of actual measurements</td>")
            append("</tr>")
            append("<tr>")
            append("<td style='width: 8%;' class='center'>Quantity<br>executed<br>upto previous<br>bill as per<br>M.B</td>")
            append("<td style='width: 8%;' class='center'>Quantity<br>executed<br>since<br>Previous Bill<br>as per M.B</td>")
            append("<td style='width: 8%;' class='center'>Quantity<br>executed upto<br>date as per<br>M.B</td>")
            append("<td style='width: 25%;' class='center'>Description Of Work</td>")
            append("<td style='width: 8%;' class='center'>Tendor Rate</td>")
            append("<td style='width: 8%;' class='center'>Proposed Rate</td>")
            append("<td style='width: 7%;' class='center'>Remark</td>")
            append("<td style='width: 6%;' class='center'>Unit</td>")
            append("<td style='width: 8%;' class='center'>Total Upto<br>date</td>")
            append("<td style='width: 7%;' class='center'>Since previous<br>Bill</td>")
            append("<td style='width: 7%;' class='center'>Upto previous<br>bill</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='center'>2</td><td class='center'>3</td><td class='center'>4</td><td class='center'>5</td><td class='center'></td><td class='center'>6</td><td class='center'></td><td class='center'>7</td><td class='center'>8</td><td class='center'>9</td><td class='center'>10</td>")
            append("</tr>")
            
            var totalGross = 0.0
            var totalPrevGross = 0.0
            var totalCurrGross = 0.0
            
            raBillItems.forEach { item ->
                val boq = boqItems.find { it.id == item.boqItemId }
                val desc = boq?.description ?: ""
                val rate = boq?.rate ?: 0.0
                val unit = boq?.unit ?: ""
                
                val currentAmt = item.currentQuantity * rate
                val prevAmt = item.previousQuantity * rate
                val totalAmt = item.totalQuantity * rate
                totalGross += totalAmt
                totalPrevGross += prevAmt
                totalCurrGross += currentAmt
                
                append("<tr>")
                append("<td>\${if (item.previousQuantity > 0) String.format("%.3f", item.previousQuantity) else ""}</td>")
                append("<td>\${if (item.currentQuantity > 0) String.format("%.3f", item.currentQuantity) else ""}</td>")
                append("<td>\${String.format("%.3f", item.totalQuantity)}</td>")
                append("<td class='left'>\${boq?.itemNumber} \$desc</td>")
                append("<td>\${String.format("%.2f", rate)}</td>")
                append("<td>\${String.format("%.2f", rate)}</td>")
                append("<td></td>")
                append("<td class='center'>\$unit</td>")
                append("<td>\${String.format("%.2f", totalAmt)}</td>")
                append("<td>\${if (currentAmt > 0) String.format("%.2f", currentAmt) else "0.00"}</td>")
                append("<td>\${if (prevAmt > 0) String.format("%.2f", prevAmt) else "0.00"}</td>")
                append("</tr>")
            }
            append("<tr><td colspan='8' class='right'><b>TOTAL Rs</b></td><td><b>\${String.format("%.2f", totalGross)}</b></td><td><b>\${String.format("%.2f", totalCurrGross)}</b></td><td><b>\${String.format("%.2f", totalPrevGross)}</b></td></tr>")
            append("</table>")
            
            // Total Summary Table (like Page 4 of PDF)
            append("<table style='width: 100%; border: 1px solid black; font-size: 10px; margin-top: 10px; border-collapse: collapse;'>")
            append("<tr>")
            append("<td colspan='8' class='right'><b>Total Value of Work Done date</b></td>")
            append("<td colspan='3' class='right'><b>\${String.format("%.2f", totalGross)}</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='8' class='right'><b>Deduct- Value or work shown in previous bill</b></td>")
            append("<td colspan='3' class='right'><b>\${String.format("%.2f", totalPrevGross)}</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='8' class='right'><b>Net value of work since previous bill</b></td>")
            append("<td colspan='3' class='right'><b>\${String.format("%.2f", totalCurrGross)}</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='8' class='right'><b>Total</b></td>")
            append("<td colspan='3' class='right'><b>\${String.format("%.2f", totalCurrGross)}</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'><b>Figure in words:- Rs \${numberToWords(totalCurrGross.toLong())} Rupees Only</b></td>")
            append("</tr>")
            
            append("<tr>")
            append("<td colspan='11' class='center'><b>Part II: Account of Secured Advance allowed on the security of materials brought to site</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td class='center'>Quantity outstanding<br>from previous bill</td>")
            append("<td class='center'>Deduct quantity<br>utilized in work<br>measured since<br>previous bill</td>")
            append("<td class='center'>Quantity Outstanding<br>including Qunatity<br>brought to site since<br>previous<br>bill</td>")
            append("<td class='center'>Full rate as assured by<br>the divisional office</td>")
            append("<td class='center'>Description of<br>materials</td>")
            append("<td class='center'>Unit</td>")
            append("<td class='center'>Reduced rate at<br>which advances is<br>made</td>")
            append("<td class='center'>Up to-date amount of<br>advance</td>")
            append("<td colspan='2' class='center'>Reference to divisional<br>officer's written order<br>authorising the advance</td>")
            append("<td class='center'>Reasons for non-clearence of<br>advance when outstanding for<br>more than<br>three months</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='center'>1</td><td class='center'>2</td><td class='center'>3</td><td class='center'>4</td><td class='center'>5</td><td class='center'>6</td><td class='center'>7</td><td class='center'>8</td><td class='center'>NO 9</td><td class='center'>DATE 10</td><td class='center'>11</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='8'><br><br></td>")
            append("<td colspan='3'></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'>Total amount outstanding as per this bill (C)<br>Deduct amount outstanding as entry (C) of previous bill<br>Net amount since previous bill</td>")
            append("</tr>")
            
            append("<tr>")
            append("<td colspan='11' class='center'><b>Part III : Certificate and Signature</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'>1. Entries in columns(4) to (9) of part 1 are based on measurements recorded by Shri/Smt. _____________________ (Junior Engineer) with MB No: _____________ Verified and checked by Shri/Smt. _____________________ (Deputy Engineer)</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'>2.Cerified (1) that in addition to quite apart from the Quantities of work actually executed as some in column 4 of part1, some work has been actually done in connection with several items & the value of such work (after deducting there-from the proportionate amount of secured advance ,if any ultimately recoverable on account of the advance payment as per column 3 of part 1 made or proposed to be made for the convenience of the contractor in anticipation of, and subjected to the results of detailed measurements, which will be made as soon as possible.</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'>3. Certified (1) that the plus quantities of materials shown in columns 3 of part II above been actually brought by the contractor has not previously received any advance on their security(ii) that use in the work in connection with items for which rates for finished work have by the contractor in accordance with paragraph 10-2-19 of the M.P.W.A code is recorded in the Divisional Office.</td>")
            append("</tr>")
            
            append("<tr>")
            append("<td colspan='3' class='center'><b>Contractor</b></td>")
            append("<td colspan='3' class='center'><b>Junior Engineer</b></td>")
            append("<td colspan='3' class='center'><b>Deputy Engineer</b></td>")
            append("<td colspan='2' class='center'><b>Executive Engineer</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='3' class='center'><br></td>")
            append("<td colspan='3' class='center'>P.C.M.C. Pimpri</td>")
            append("<td colspan='3' class='center'>P.C.M.C. Pimpri</td>")
            append("<td colspan='2' class='center'>P.C.M.C. Pimpri</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='3' class='left'>Dated signature of the contractor</td>")
            append("<td colspan='6' class='left'>Dated signature of officer preparing the bill</td>")
            append("<td colspan='2' class='left'>Dated signature of officer authorizing payment</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='11' class='left'>The signature is necessary only when the officer preparing the bill is not the Officer authorizing payment</td>")
            append("</tr>")
            append("</table>")
            
            append("</div>")

            // Page 3: Part IV
            append("<div class='page-break'>")
            
            val totalDeductions = raBill.securityDeposit + raBill.gstAmount + raBill.labourCess + raBill.otherRecoveries
            
            append("<table style='width: 100%; border: 1px solid black; font-size: 11px; margin-top: 10px; border-collapse: collapse;'>")
            append("<tr>")
            append("<td colspan='4' class='center'><b>Part IV Memorandum Of Payments.</b></td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='3' class='left'>1. Total value of work actually measured as per part I, Column 8,Entry(A)</td>")
            append("<td style='width: 15%;' class='center'>Rs.<br>\${String.format("%.2f", totalGross)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='3' class='left'>2. Total up-to date advance payment for work not yet measured as per part I ,Colomn 3,Entry( B )<br>3. Total up-to -date secured advance on security of material as per part II ,Column 8,Entry(C)<br>4. Total ( Items 1+2+3 )<br>5. Deduct- Amount Whithheld<br>&nbsp;&nbsp;&nbsp;&nbsp;Figures for<br>&nbsp;&nbsp;&nbsp;&nbsp;Work abstract&nbsp;&nbsp;&nbsp;&nbsp;(a) From pervious bill as per running account bill&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rs. ps. \${String.format("%.2f", totalPrevGross)}<br>&nbsp;&nbsp;&nbsp;&nbsp;Rs. &nbsp;&nbsp;&nbsp;Ps. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;( b ) From this bill<br><br>&nbsp;&nbsp;&nbsp;&nbsp;6. Balance,ie.Up-to-date payments ( Item 4-5 )<br>&nbsp;&nbsp;&nbsp;&nbsp;7. Balance,ie. Up-to-date payments ( Item 4-5 )<br>&nbsp;&nbsp;&nbsp;&nbsp;account Bill No. ________ Of ________ forwarded with account<br>&nbsp;&nbsp;&nbsp;&nbsp;8. Payments now to be made as detailed below -</td>")
            append("<td style='vertical-align: bottom;' class='right'>\${String.format("%.2f", totalCurrGross)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td style='width: 5%;'></td>")
            append("<td style='width: 5%;' class='center'>1</td>")
            append("<td class='left'>Security Deposit</td>")
            append("<td class='right'>Rs. \${String.format("%.2f", raBill.securityDeposit)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td></td><td class='center'>2</td><td class='left'>GST Amount</td><td class='right'>Rs. \${String.format("%.2f", raBill.gstAmount)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td></td><td class='center'>3</td><td class='left'>Labour Cess</td><td class='right'>Rs. \${String.format("%.2f", raBill.labourCess)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td></td><td class='center'>4</td><td class='left'>Other Recoveries</td><td class='right'>Rs. \${String.format("%.2f", raBill.otherRecoveries)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td></td><td colspan='2' class='left'>( a ) By recovery of amount creditable to this work</td><td></td>")
            append("</tr>")
            append("<tr>")
            append("<td></td><td colspan='2' class='center'>Total 5 ( b ) 8+( a ) ( G )</td><td class='right'>\${String.format("%.2f", totalDeductions)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='right'>\${String.format("%.2f", totalDeductions)}</td><td colspan='3' class='left'>( b )By recovery of amount creditable to other works or heads to account</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='right'>\${String.format("%.2f", raBill.netPayable)}</td><td colspan='3' class='left'>c ) By cheque</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='right'>\${String.format("%.2f", totalCurrGross)}</td><td colspan='2' class='center'>Total 8 ( b ) + ( c ) ( H )</td><td class='right'>\${String.format("%.2f", totalDeductions)} | \${String.format("%.2f", raBill.netPayable)}</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='left'>Passed for<br>payment Rs.</td><td colspan='3' class='left'>\${String.format("%.2f", totalCurrGross)} &nbsp;&nbsp;&nbsp;&nbsp; \${numberToWords(totalCurrGross.toLong()).uppercase()} Rupees Only</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='left'>pay by<br>cheque Rs.</td><td colspan='3' class='left'>\${String.format("%.2f", raBill.netPayable)} &nbsp;&nbsp;&nbsp;&nbsp; \${numberToWords(raBill.netPayable.toLong()).uppercase()} Rupees Only</td>")
            append("</tr>")
            append("<tr>")
            append("<td class='left'>deduction of<br>Rs.</td><td colspan='3' class='left'>\${String.format("%.2f", totalDeductions)} &nbsp;&nbsp;&nbsp;&nbsp; \${numberToWords(totalDeductions.toLong()).uppercase()} Rupees Only</td>")
            append("</tr>")
            append("<tr>")
            append("<td colspan='4'>")
            append("<p class='center'>By Contra Credit</p>")
            append("<br><br>")
            append("<p class='right'>Dated Initials of Disbursing Office</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -5px;'>")
            append("<p class='left'>Dated:-</p>")
            append("<p class='left'>Witness:-</p>")
            append("<br><br>")
            append("<p class='right'>Full Signature of Contractor</p>")
            append("<hr style='border-top: 1px solid black; margin: 5px -5px;'>")
            append("<div style='display: flex; justify-content: space-between;'>")
            append("<p>Paid by me,vide Cheque No.</p>")
            append("<p>Dated</p>")
            append("</div>")
            append("<br><br>")
            append("<p class='right'>Dated Initial of the Person actually making the payments</p>")
            append("</td>")
            append("</tr>")
            append("</table>")
            append("</div>")

            append("</body></html>")
        }
        printHtml(context, html, "RABill_\${raBill.billNumber}", landscape = true)
        return "Opening PDF Preview..."
    }"""

numberToWords = """    private fun numberToWords(number: Long): String {
        if (number == 0L) return "Zero"
        val units = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
        val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")
        
        fun convert(n: Long): String {
            if (n < 20) return units[n.toInt()]
            if (n < 100) return tens[(n / 10).toInt()] + (if (n % 10 != 0L) " " + units[(n % 10).toInt()] else "")
            if (n < 1000) return units[(n / 100).toInt()] + " Hundred" + (if (n % 100 != 0L) " " + convert(n % 100) else "")
            if (n < 100000) return convert(n / 1000) + " Thousand" + (if (n % 1000 != 0L) " " + convert(n % 1000) else "")
            if (n < 10000000) return convert(n / 100000) + " Lakh" + (if (n % 100000 != 0L) " " + convert(n % 100000) else "")
            return convert(n / 10000000) + " Crore" + (if (n % 10000000 != 0L) " " + convert(n % 10000000) else "")
        }
        return convert(number).trim().replace("  ", " ")
    }
"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)
if "numberToWords" not in content:
    content = content.replace("object ExcelExport {", "object ExcelExport {\n\n" + numberToWords)

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
