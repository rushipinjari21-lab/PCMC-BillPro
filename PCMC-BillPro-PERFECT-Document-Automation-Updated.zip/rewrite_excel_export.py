import os

content = """package com.example.utils

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Log
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.*

object ExcelExport {
    
    private suspend fun printHtml(context: Context, htmlContent: String, jobName: String) {
        withContext(Dispatchers.Main) {
            try {
                val webView = WebView(context)
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                        val printAdapter = view.createPrintDocumentAdapter(jobName)
                        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
                    }
                }
                webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null)
            } catch (e: Exception) {
                Log.e("PdfExport", "Error generating PDF", e)
            }
        }
    }

    suspend fun exportMbToCsv(
        context: Context,
        project: Project,
        mb: MeasurementBook,
        boqItems: List<BoqItem>,
        measurements: List<Measurement>
    ): String {
        val html = buildString {
            append("<html><head><style>body { font-family: sans-serif; padding: 20px; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid black; padding: 8px; text-align: left; } th { background-color: #f2f2f2; }</style></head><body>")
            append("<h2>Measurement Book (MB)</h2>")
            append("<p><strong>MB Number:</strong> ${mb.mbNumber}</p>")
            append("<p><strong>Work Name:</strong> ${project.workName}</p>")
            append("<p><strong>Contractor:</strong> ${project.contractorName}</p>")
            
            append("<table><tr><th>SSR Code</th><th>Description</th><th>Date</th><th>Location</th><th>Dim (NxLxBxD)</th><th>Qty</th></tr>")
            
            measurements.forEach { m ->
                val boq = boqItems.find { it.id == m.boqItemId }
                val desc = boq?.description ?: ""
                val ssr = boq?.ssrCode ?: ""
                append("<tr><td>$ssr</td><td>$desc</td><td>${m.date}</td><td>${m.location}</td><td>${m.number} x ${m.length} x ${m.breadth} x ${m.height}</td><td>${String.format("%.3f", m.quantity)}</td></tr>")
            }
            append("</table></body></html>")
        }
        
        printHtml(context, html, "MB_${mb.mbNumber}")
        return "Opening PDF Preview..."
    }

    suspend fun exportRaBillToCsv(
        context: Context,
        project: Project,
        raBill: RaBill,
        boqItems: List<BoqItem>,
        raBillItems: List<RaBillItem>
    ): String {
        val html = buildString {
            append("<html><head><style>body { font-family: sans-serif; padding: 20px; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid black; padding: 8px; text-align: right; } th { background-color: #f2f2f2; text-align: center; } .left { text-align: left; }</style></head><body>")
            append("<h2>RA Bill: ${raBill.billNumber}</h2>")
            append("<p><strong>Work Name:</strong> ${project.workName}</p>")
            append("<p><strong>Contractor:</strong> ${project.contractorName}</p>")
            
            append("<table><tr><th>Item No</th><th>SSR Code</th><th class='left'>Description</th><th>Rate</th><th>Executed Qty</th><th>Amount</th></tr>")
            
            raBillItems.forEach { item ->
                val boq = boqItems.find { it.id == item.boqItemId }
                val desc = boq?.description ?: ""
                val ssr = boq?.ssrCode ?: ""
                val rate = boq?.rate ?: 0.0
                val amount = item.executedQuantity * rate
                append("<tr><td>${boq?.itemNumber}</td><td>$ssr</td><td class='left'>$desc</td><td>$rate</td><td>${String.format("%.3f", item.executedQuantity)}</td><td>${String.format("%.2f", amount)}</td></tr>")
            }
            
            append("<tr><td colspan='5' style='text-align:right'><b>Gross Amount</b></td><td><b>${String.format("%.2f", raBill.grossAmount)}</b></td></tr>")
            append("<tr><td colspan='5' style='text-align:right'><b>GST (${raBill.gstPercent}%)</b></td><td><b>${String.format("%.2f", raBill.gstAmount)}</b></td></tr>")
            append("<tr><td colspan='5' style='text-align:right'><b>Labour Cess (${raBill.labourCessPercent}%)</b></td><td><b>-${String.format("%.2f", raBill.labourCess)}</b></td></tr>")
            append("<tr><td colspan='5' style='text-align:right'><b>Security Deposit (${raBill.sdPercent}%)</b></td><td><b>-${String.format("%.2f", raBill.securityDeposit)}</b></td></tr>")
            append("<tr><td colspan='5' style='text-align:right'><b>Net Payable</b></td><td><b>${String.format("%.2f", raBill.netPayable)}</b></td></tr>")
            
            append("</table></body></html>")
        }
        
        printHtml(context, html, "RABill_${raBill.billNumber}")
        return "Opening PDF Preview..."
    }

    suspend fun exportQuantityVariationToCsv(
        context: Context,
        project: Project,
        variation: QuantityVariation,
        boqItems: List<BoqItem>,
        qvItems: List<QuantityVariationItem>
    ): String {
        val html = buildString {
            append("<html><head><style>body { font-family: sans-serif; padding: 20px; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid black; padding: 8px; text-align: center; } .left { text-align: left; }</style></head><body>")
            append("<h2>Quantity Variation Sheet</h2>")
            append("<p><strong>Work Name:</strong> ${project.workName}</p>")
            
            append("<table><tr><th>Item No</th><th>SSR Code</th><th class='left'>Description</th><th>BOQ Qty</th><th>Executed Qty</th><th>Excess</th><th>Saving</th></tr>")
            
            qvItems.forEach { item ->
                val boq = boqItems.find { it.id == item.boqItemId }
                val desc = boq?.description ?: ""
                val ssr = boq?.ssrCode ?: ""
                val boqQty = boq?.boqQuantity ?: 0.0
                append("<tr><td>${boq?.itemNumber}</td><td>$ssr</td><td class='left'>$desc</td><td>${String.format("%.3f", boqQty)}</td><td>${String.format("%.3f", item.executedQuantity)}</td><td>${String.format("%.3f", item.excessQuantity)}</td><td>${String.format("%.3f", item.savingQuantity)}</td></tr>")
            }
            append("</table></body></html>")
        }
        
        printHtml(context, html, "QV_${project.sapWorkKey}")
        return "Opening PDF Preview..."
    }

    suspend fun exportCertificatesToCsv(
        context: Context,
        project: Project,
        raBill: RaBill
    ): String {
        val workName = project.workName
        val contractorName = project.contractorName
        
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>body { font-family: sans-serif; padding: 20px; line-height: 1.6; } .page-break { page-break-after: always; } .center { text-align: center; } .right { text-align: right; } table { width: 100%; border-collapse: collapse; margin-top: 10px; } th, td { border: 1px solid black; padding: 8px; }</style></head><body>")
            
            // Page 1: First RA Bill Cover
            append("<h2 class='center'>पहिले आर. ए. बिल</h2>")
            append("<p><b>१) कामाचे नाव -</b> $workName</p>")
            append("<p><b>२) ठेकेदाराचे नाव -</b> $contractorName</p>")
            append("<p><b>३) निविदा रक्कम -</b> रक्कम रुपये ${project.agreementAmount}</p>")
            append("<p><b>४) कार्यारंभ आदेश क्र. व दिनांक -</b> ${project.workOrderNumber}</p>")
            append("<p><b>५) देयकाची रक्कम -</b> रक्कम रुपये ${String.format("%.2f", raBill.netPayable)}</p>")
            append("<br><br><br><br><br><br><br>")
            append("<div class='right'><p><b>उप अभियंता (स्था)</b><br>क क्षेत्रीय कार्यालय<br>पिंपरी चिंचवड महानगरपालिका<br>पिंपरी - ४११ ०१८</p></div>")
            append("<div class='page-break'></div>")
            
            // Page 2: 100% Checking Certificate
            append("<h2 class='center'>दाखला</h2>")
            append("<p><b>१) ठेकेदाराचे नाव -</b> $contractorName</p>")
            append("<p><b>२) कामाचे नाव -</b> $workName</p>")
            append("<p><b>३) निविदा रक्कम -</b> रक्कम रुपये ${project.agreementAmount}</p>")
            append("<p><b>४) निविदा क्रमांक -</b> ${project.tenderNumber}</p>")
            append("<p>प्रस्तुत काम अंदाजपत्रकानुसार त्याच जागेवर पुर्ण करणेत आलेले असून कोणताही स्थळ बदल करणेत आलेला नाही.</p>")
            append("<p>सदर कामाची १००% मोजमापे मी स्वतः घेतली असून सदर काम माझ्या देखरेखीखाली समाधानकारक पुर्ण झाले आहे.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between;'><div><b>कनिष्ठ अभियंता</b><br>स्थापत्य क क्षत्रिय</div><div><b>उप अभियंता</b><br>स्थापत्य क क्षत्रिय</div></div>")
            append("<div class='page-break'></div>")
            
            // Page 3: Payment Schedule
            append("<h2>Payment Schedule</h2>")
            append("<p><b>१) कामाचे नाव -</b> $workName</p>")
            append("<p><b>२) ठेकेदाराचे नाव -</b> $contractorName</p>")
            append("<table><tr><th>Sr. No.</th><th>Bill No.</th><th>Bill Amount</th><th>Remark</th></tr>")
            append("<tr><td>1</td><td>${raBill.billNumber}</td><td>${String.format("%.2f", raBill.grossAmount)}</td><td>उपलब्ध तरतुदीप्रमाणे पहिले रनिंग देयक अदा करणेत येत आहे</td></tr></table>")
            append("<br><br><br>")
            append("<div class='right'><p><b>कार्यकारी अभियंता</b><br>स्थापत्य क क्षत्रिय<br>पिंपरी चिंचवड महानगरपालिका</p></div>")
            append("<div class='page-break'></div>")
            
            // Page 4: Labor Laws
            append("<h3 class='center'>पिंपरी चिंचवड महानगरपालिका</h3>")
            append("<h3 class='center'>क क्षेत्रीय कार्यालय स्थापत्य विभाग</h3>")
            append("<h2 class='center'>दाखला</h2>")
            append("<p><b>कामाचे नाव -</b> $workName</p>")
            append("<p><b>ठेकेदाराचे नाव -</b> $contractorName</p>")
            append("<p>वरील कामकाजाबाबत ठेकेदार $contractorName यांनी प्रकरणी कंत्राटी कामगार (नियमन व निर्मूलन) अधिनियम १९७० मधील तरतूदींचे पालन केले आहे. तसेच किमान वेतन कायदा १९४८ कर्मचारी राज्या विमा कायदा १९४८ भविष्य निर्वाह निधी कायदा १९५२ इत्यादी कायदेशीर बाबींचे काटेकोरपणे पालन केले आहे. कंत्राटदाराने कामाचा व त्यावर काम करणा-या कामगारांचा विमा नॅशनल इंन्शुरन्स कं. लि. चिंचवड यांच्याकडे उतरवला आहे.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between;'><div><b>पर्यवेक्षकीय अधिकारी</b></div><div><b>विभागप्रमुख / प्राधिकृत सक्षम अधिकारी</b></div></div>")
            append("<div class='page-break'></div>")
            
            // Page 5: GIS Mapping
            append("<h3 class='center'>पिंपरी चिंचवड महानगरपालिका पिंपरी - ४११ ०१८</h3>")
            append("<h2 class='center'>GIS Mapping दाखला</h2>")
            append("<p><b>१) कामाचे नाव -</b> $workName</p>")
            append("<p><b>२) निविदा क्रमांक -</b> ${project.tenderNumber}</p>")
            append("<p>सदर कामाअंतर्गत केलेल्या कामाची GIS Mapping नोंद घेण्यात आलेली असून सदर कामाची बिल अदायगी करणेत यावी.</p>")
            append("<br><br><br>")
            append("<div class='right'><p><b>कार्यकारी अभियंता (स्था)</b><br>क क्षेत्रीय कार्यालय</p></div>")
            append("<div class='page-break'></div>")
            
            // Page 6: Office Note (Quantity Variation)
            append("<div style='display: flex; justify-content: space-between;'><div><b>कार्यालयीन टिपणी</b></div><div><b>क क्षेत्रीय स्थापत्य विभाग</b></div></div>")
            append("<p><b>विषय -</b> $workName</p>")
            append("<p><b>निविदा नोटीस क्र.</b> ${project.tenderNumber}</p>")
            append("<p><b>मा.स.सादर,</b></p>")
            append("<p>उपरोक्त विषयांकीत कामाचा आदेश ठेकेदार $contractorName यांना देण्यात आला असून कामाचा स्विकृत निविदा दर कमी/जास्त इतका आहे. त्यानुसार आवश्यकतेनुसार इतर अनुषंगिक कामे करणे गरजेचे आहे. परंतु सदर कामे केल्यास मुळ निविदेतील काही बाबींच्या परिमाणात वाढ होणार marginal आहे. सदर बाबींमुळे मुळ निविदा रक्कम बदलत नसून उर्वरीत बाबींच्या बचतीमधून सदर वाढीव परिमाणाचे काम करता येणार आहे.</p>")
            append("<p>तरी सोबत जोडलेल्या Quantity Variation Sheet प्रमाणे सुधारीत परिमाणास मान्यता घेणेकामी स्वाक्षरीस्तव सविनय सादर.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between;'><div><b>उप अभियंता (स्था)</b></div><div><b>कार्यकारी अभियंता (स्था)</b></div><div><b>सह शहर अभियंता</b></div></div>")
            
            append("</body></html>")
        }
        
        printHtml(context, html, "Certificates_${raBill.billNumber}")
        return "Opening PDF Preview..."
    }
}
"""

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
