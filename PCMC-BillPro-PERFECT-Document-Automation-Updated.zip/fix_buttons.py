import re

with open('./app/src/main/java/com/example/ui/boq/BoqScreen.kt', 'r') as f:
    boq_content = f.read()

# Add FAB to BoqScreen
boq_fab = """                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            if (currentBoq != null) {
                ExtendedFloatingActionButton(
                    onClick = onNavigateToMb,
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Edit, contentDescription = "Measurement Book") },
                    text = { Text("Measurement Book") }
                )
            }
        }
    ) { innerPadding ->"""

boq_content = re.sub(
    r'                colors = TopAppBarDefaults\.topAppBarColors\(\n                    containerColor = MaterialTheme\.colorScheme\.primaryContainer,\n                    titleContentColor = MaterialTheme\.colorScheme\.onPrimaryContainer,\n                \)\n            \)\n        }\n    \) \{ innerPadding ->',
    boq_fab,
    boq_content
)

with open('./app/src/main/java/com/example/ui/boq/BoqScreen.kt', 'w') as f:
    f.write(boq_content)


with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    mb_content = f.read()

mb_fab = """                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToRaBill,
                icon = { Icon(androidx.compose.material.icons.Icons.Default.Check, contentDescription = "Generate RA Bill") },
                text = { Text("Generate RA Bill") }
            )
        }
    ) { innerPadding ->"""

mb_content = re.sub(
    r'                colors = TopAppBarDefaults\.topAppBarColors\(\n                    containerColor = MaterialTheme\.colorScheme\.primaryContainer,\n                    titleContentColor = MaterialTheme\.colorScheme\.onPrimaryContainer,\n                \)\n            \)\n        }\n    \) \{ innerPadding ->',
    mb_fab,
    mb_content
)

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(mb_content)
