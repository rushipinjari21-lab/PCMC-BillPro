import re

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    content = f.read()

old_buttons = """                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    IconButton(onClick = { 
                        viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export")
                    }
                }"""

new_buttons = """                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Row {
                        IconButton(onClick = { 
                            viewModel.exportCertificates(context, bill.sapWorkKey, bill.id) { result ->
                                android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) {
                            Icon(androidx.compose.material.icons.Icons.Default.Description, contentDescription = "Export Certificates (Marathi)")
                        }
                        IconButton(onClick = { 
                            viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                                android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) {
                            Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export Bill")
                        }
                    }
                }"""
                
content = content.replace(old_buttons, new_buttons)

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(content)
