import re

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "r") as f:
    content = f.read()

# 1. Update style
content = content.replace(".list-content { flex: 1; }", ".list-content { flex: 1; }\n            append(\".no-border td { border: none !important; padding: 4px; }\")")

# 2. Add doc0 before doc1
doc0_str = """
            val billAmount = formatAmt(raBill.grossAmount)
            val titleText = if (raBill.billNumber.contains("1", ignoreCase = true) || raBill.billNumber.contains("First", ignoreCase = true)) "पहिले आर. ए. बिल" else "आर. ए. बिल (${raBill.billNumber})"
            val doc0 = \"\"\"<div class='page-break'>
                <h3 class='center' style='text-decoration: underline; margin-bottom: 20px;'>$titleText</h3>
                
                <table class='no-border' style='width: 100%; border: none;'>
                    <tr><td style='width: 5%; vertical-align: top;'>१)</td><td style='width: 45%; vertical-align: top;'>कामाचे नाव -</td><td style='width: 50%; vertical-align: top;'><b>\$workName</b></td></tr>
                    <tr><td>२)</td><td>ठेकेदाराचे नाव -</td><td><b>\$contractorName</b></td></tr>
                    <tr><td>३)</td><td>अंदाजपत्रकीय किंमत -</td><td><b>रक्कम रुपये \$adminApprovalAmt/-</b></td></tr>
                    <tr><td>४)</td><td>टेंडरची रक्कम -</td><td><b>रक्कम रुपये \$tenderAmt/-</b></td></tr>
                    <tr><td>५)</td><td>कामाची प्रशासकीय मान्यता -</td><td><b>र.रु. \$adminApprovalAmt/-</b></td></tr>
                    <tr><td>६)</td><td>कामाला तांत्रिक मान्यता -</td><td><b>र.रु. \$adminApprovalAmt/-</b></td></tr>
                    <tr><td>७)</td><td>जाहिरातीचे वर्तमानपत्र व दिनांक -</td><td><b>_____________</b></td></tr>
                    <tr><td>८)</td><td>कामाची निविदा केव्हा मान्य झाली -</td><td><b>_____________</b></td></tr>
                    <tr><td>९)</td><td>कामाचा आदेश दिलेला दिनांक -</td><td><b>_____________</b></td></tr>
                    <tr><td>१०)</td><td>कामाची मुदत -</td><td><b>१२ महिने</b></td></tr>
                    <tr><td>११)</td><td>प्रत्यक्ष काम संपलेली तारिख -</td><td><b>काम चालू आहे.</b></td></tr>
                    <tr><td>१२)</td><td>काम पुर्ण झाले असल्यास कामाचे माप उशिरा घेतले त्याचे कारण -</td><td><b>नाही</b></td></tr>
                    <tr><td>१३)</td><td>मुदतवाढ दिली काय ? दिल्यास केव्हा दिली व किती दिली -</td><td><b>_____________</b></td></tr>
                    <tr><td>१४)</td><td>पहिले आर. ए. बिलाची रक्कम रुपये -</td><td><b>र.रु. \$billAmount /-</b></td></tr>
                    <tr><td>१५)</td><td>एस्टिमेट रिवाईज करणे जरुर आहे काय ? -</td><td><b>नाही</b></td></tr>
                    <tr><td>१६)</td><td>जादा बाब मंजुर करुन घेतले काय ? -</td><td><b>नाही</b></td></tr>
                    <tr><td style='vertical-align: top;'>१७)</td><td style='vertical-align: top;'>ठेकेदारास सिमेंट व इतर सामान एकूण किती दिली व त्याची वसुली कशी केली -</td><td style='vertical-align: top;'><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                    <tr><td style='vertical-align: top;'>१८)</td><td style='vertical-align: top;'>ठेकेदाराने पाणी वापरले काय व त्याचे पैसे भरले नसल्यास १/२ टक्के कापून घेतले काय ? -</td><td style='vertical-align: top;'><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                    <tr><td>१९)</td><td>ठेकेदारास मशिनरी भाड्याने दिली काय ? -</td><td><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                    <tr><td>२०)</td><td colspan="2">इतर - सदर बिलामधून रॉयल्टीपोटी र.रु. ________ /- वजा करणेत यावी.</td></tr>
                </table>
                
                <div class='signature-block' style='margin-top: 60px;'>
                    <div class='signature-item'><b>कनिष्ठ अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८.</div>
                    <div class='signature-item'><b>उप अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८.</div>
                </div>
            </div>\"\"\"
            
            // Doc 1: DE 100%
"""

content = content.replace("// Doc 1: DE 100%", doc0_str.strip() + "\n            \n            // Doc 1: DE 100%")

# 3. Update allDocs list
content = content.replace("val allDocs = listOf(doc1, doc2, doc3, doc4, doc5, doc6, doc7)", "val allDocs = listOf(doc0, doc1, doc2, doc3, doc4, doc5, doc6, doc7)")

# 4. Update docIndex condition
content = content.replace("docIndex in 0..6", "docIndex in 0..7")

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "w") as f:
    f.write(content)
