import re

with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'r') as f:
    content = f.read()

mb_excel = """
    @android.annotation.SuppressLint("NewApi")
    fun exportMBExcel(context: android.content.Context, sapWorkKey: String, mbId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val mb = dao.getMeasurementBookById(mbId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && mb != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val measurements = dao.getMeasurementsByMbId(mbId).first()
                    
                    val csv = StringBuilder()
                    csv.append("Item No,Description,No,Length,Breadth,Depth,Quantity,Remark\\n")
                    
                    for (item in boqItems) {
                        val itemMeasurements = measurements.filter { it.boqItemId == item.id }
                        if (itemMeasurements.isEmpty()) continue
                        
                        val desc = item.description.replace(",", ";").replace("\\n", " ")
                        csv.append("${item.itemNumber},$desc,,,,,,\\n")
                        
                        for (m in itemMeasurements) {
                            csv.append(",,${m.nos},${m.length},${m.breadth},${m.height},${m.quantity},\\n")
                        }
                    }
                    
                    val fileName = "MB_${mbId}_Excel.csv"
                    
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(csv.toString().toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel (CSV) file saved to Downloads: $fileName")
                        } ?: run {
                            onResult("Failed to create file")
                        }
                    } else {
                        try {
                            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            val file = java.io.File(downloadsDir, fileName)
                            file.outputStream().use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(csv.toString().toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel (CSV) file saved to Downloads: $fileName")
                        } catch (e: Exception) {
                            onResult("Failed to save file: ${e.message}")
                        }
                    }
                } else {
                    onResult("Missing project or MB data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }
"""

if "fun exportMBExcel" not in content:
    content = content.replace("fun exportMB(", mb_excel + "\n    fun exportMB(")

with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'w') as f:
    f.write(content)
