import re

with open('./app/src/main/java/com/example/data/AppDao.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'fun getRaBillsByWorkKey(sapWorkKey: String): Flow<List<RaBill>>',
    'fun getRaBillsByWorkKey(sapWorkKey: String): Flow<List<RaBill>>\n\n    @Query("SELECT * FROM ra_bills WHERE id = :billId")\n    suspend fun getRaBillById(billId: Long): RaBill?'
)

with open('./app/src/main/java/com/example/data/AppDao.kt', 'w') as f:
    f.write(content)
