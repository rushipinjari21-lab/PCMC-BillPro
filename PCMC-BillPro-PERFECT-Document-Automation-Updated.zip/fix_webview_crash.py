import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

target = """object ExcelExport {
    
    private suspend fun printHtml(context: Context, htmlContent: String, jobName: String) {"""

replacement = """object ExcelExport {
    
    private var activeWebView: WebView? = null
    
    private suspend fun printHtml(context: Context, htmlContent: String, jobName: String) {"""

content = content.replace(target, replacement)

target2 = """            try {
                val webView = WebView(context)
                webView.webViewClient = object : WebViewClient() {"""

replacement2 = """            try {
                val webView = WebView(context)
                activeWebView = webView // Keep a strong reference to prevent garbage collection and renderer crash
                webView.webViewClient = object : WebViewClient() {"""

content = content.replace(target2, replacement2)

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)

