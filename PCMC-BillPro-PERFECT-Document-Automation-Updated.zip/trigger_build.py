import time
print("Done!")
