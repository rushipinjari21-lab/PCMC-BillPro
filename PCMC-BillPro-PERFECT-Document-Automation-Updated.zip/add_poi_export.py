import re

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

poi_methods = """
    fun exportDossierDocxPOI(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.Dispatchers.IO.invoke {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    if (project != null && bill != null) {
                        val result = com.example.utils.DocumentExportService.exportDossierToDocx(context, project, bill)
                        kotlinx.coroutines.Dispatchers.Main.invoke { onResult(result) }
                    } else {
                        kotlinx.coroutines.Dispatchers.Main.invoke { onResult("Missing project or Bill data") }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.Dispatchers.Main.invoke { onResult("Error: ${e.message}") }
                }
            }
        }
    }

    fun exportDossierXlsxPOI(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.Dispatchers.IO.invoke {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    if (project != null && bill != null) {
                        val result = com.example.utils.DocumentExportService.exportDossierToXlsx(context, project, bill)
                        kotlinx.coroutines.Dispatchers.Main.invoke { onResult(result) }
                    } else {
                        kotlinx.coroutines.Dispatchers.Main.invoke { onResult("Missing project or Bill data") }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.Dispatchers.Main.invoke { onResult("Error: ${e.message}") }
                }
            }
        }
    }
"""

if "exportDossierDocxPOI" not in content:
    content = content.replace("fun getCertificatesHtml(", poi_methods + "\n    fun getCertificatesHtml(")

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
