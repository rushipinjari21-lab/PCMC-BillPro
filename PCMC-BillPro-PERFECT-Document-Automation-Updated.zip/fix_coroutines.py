import re

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace("kotlinx.coroutines.Dispatchers.IO.invoke {", "kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {")
content = content.replace("kotlinx.coroutines.Dispatchers.Main.invoke {", "kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {")

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
