import os
import re

# 1. Update build.gradle.kts
build_gradle_path = "app/build.gradle.kts"
with open(build_gradle_path, "r") as f:
    content = f.read()

content = content.replace("isMinifyEnabled = false", "isMinifyEnabled = true\n      isShrinkResources = true")
with open(build_gradle_path, "w") as f:
    f.write(content)

# 2. proguard-rules.pro
proguard_path = "app/proguard-rules.pro"
proguard_rules = """
# Strict ProGuard / R8 Rules for Reverse-Engineering Defenses

# Repackage classes
-repackageclasses ''
-allowaccessmodification

# Remove Log calls
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
}

# Keep necessary Android components
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# Keep Firebase/Vertex AI from being fully stripped if needed
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
"""
with open(proguard_path, "a") as f:
    f.write("\n" + proguard_rules)

# 3. network_security_config.xml
os.makedirs("app/src/main/res/xml", exist_ok=True)
ns_config_path = "app/src/main/res/xml/network_security_config.xml"
ns_config_content = """<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
"""
with open(ns_config_path, "w") as f:
    f.write(ns_config_content)

# 4. AndroidManifest.xml
manifest_path = "app/src/main/AndroidManifest.xml"
with open(manifest_path, "r") as f:
    manifest = f.read()

# Replace android:allowBackup="true" with "false"
manifest = manifest.replace('android:allowBackup="true"', 'android:allowBackup="false"\n        android:debuggable="false"\n        android:networkSecurityConfig="@xml/network_security_config"')

with open(manifest_path, "w") as f:
    f.write(manifest)

print("Security hardening applied successfully.")
