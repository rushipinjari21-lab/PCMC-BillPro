import re

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    content = f.read()

# Add context and viewModel to RaBillCard parameters
content = content.replace(
    'fun RaBillCard(bill: RaBill) {',
    'fun RaBillCard(bill: RaBill, viewModel: RaBillViewModel, context: android.content.Context) {'
)

# Replace the items(bills) call to pass viewModel and context
content = content.replace(
    'items(bills, key = { it.id }) { bill ->\n                    RaBillCard(bill)',
    'val context = androidx.compose.ui.platform.LocalContext.current\n                items(bills, key = { it.id }) { bill ->\n                    RaBillCard(bill = bill, viewModel = viewModel, context = context)'
)

# Add an export icon to the top right of RaBillCard
content = content.replace(
    'Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)',
    '''Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    IconButton(onClick = { 
                        viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export")
                    }
                }'''
)

# Ensure Icons.Default.Download is imported
if 'androidx.compose.material.icons.filled.Download' not in content:
    content = content.replace('import androidx.compose.material.icons.filled.Add', 'import androidx.compose.material.icons.filled.Add\nimport androidx.compose.material.icons.filled.Download')

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(content)
