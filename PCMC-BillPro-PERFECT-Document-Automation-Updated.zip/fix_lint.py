with open("app/src/main/java/com/example/viewmodel/RaBillViewModel.kt", "r") as f:
    content = f.read()

old_block = """                    val contentValues = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/msword")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                    }

                    val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    uri?.let {
                        context.contentResolver.openOutputStream(it)?.use { outputStream ->
                            outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                            outputStream.write(html.toByteArray(Charsets.UTF_8))
                        }
                        onResult("Word file saved to Downloads: $fileName")
                    } ?: run {
                        onResult("Failed to create file")
                    }"""

new_block = """                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/msword")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Word file saved to Downloads: $fileName")
                        } ?: run {
                            onResult("Failed to create file")
                        }
                    } else {
                        // Fallback for API < 29
                        try {
                            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            val file = java.io.File(downloadsDir, fileName)
                            file.outputStream().use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Word file saved to Downloads: $fileName")
                        } catch (e: Exception) {
                            e.printStackTrace()
                            onResult("Failed to save file: ${e.message}")
                        }
                    }"""

content = content.replace(old_block, new_block)

with open("app/src/main/java/com/example/viewmodel/RaBillViewModel.kt", "w") as f:
    f.write(content)
