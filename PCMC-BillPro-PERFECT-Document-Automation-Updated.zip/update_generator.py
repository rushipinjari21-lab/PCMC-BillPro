import re

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "r") as f:
    content = f.read()

start_sig = "suspend fun generateCertificatesPdfDocket"
start_idx = content.find(start_sig)

if start_idx != -1:
    # Find matching closing brace
    open_braces = 0
    end_idx = -1
    for i in range(start_idx, len(content)):
        if content[i] == '{':
            open_braces += 1
        elif content[i] == '}':
            open_braces -= 1
            if open_braces == 0:
                end_idx = i + 1
                break
    
    new_func = """suspend fun generateCertificatesPdfDocket(context: Context, project: Project, raBill: RaBill, docIndex: Int? = null): String {
        val html = buildString {
            append("<!DOCTYPE html><html><head>")
            append("<meta charset='utf-8'>")
            append("<style>")
            append("body { font-family: 'Noto Sans Devanagari', 'Mangal', sans-serif; font-size: 14pt; line-height: 1.6; margin: 0; padding: 20px; color: #000; }")
            append("h1, h2, h3 { text-align: center; margin: 10px 0; }")
            append("h4 { text-align: right; margin-bottom: 20px; font-weight: normal; }")
            append(".center { text-align: center; }")
            append(".right { text-align: right; }")
            append(".bold { font-weight: bold; }")
            append(".page-break { page-break-after: always; padding-top: 20px; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 20px; margin-bottom: 20px; }")
            append("th, td { border: 1px solid #000; padding: 8px; text-align: left; }")
            append("th { background-color: #f2f2f2; }")
            append(".signature-block { display: flex; justify-content: space-between; margin-top: 50px; text-align: center; }")
            append(".signature-item { flex: 1; }")
            append("</style></head><body>")

            val workName = project.workName
            val contractorName = project.contractorName
            val zone = project.subDivision.ifBlank { "संबंधित क्षेत्रीय कार्यालय" }
            val deName = project.engineerName.ifBlank { "_______________" }
            val eeName = "_______________"
            val tenderNo = project.tenderNumber
            
            // Format amounts
            val formatAmt = { amt: Double -> String.format("%.2f", amt) }
            val grossAmt = formatAmt(raBill.grossAmount)
            val taxableAmt = formatAmt(raBill.grossAmount) // Usually same if no other standard deduction prior to GST
            val gstAmt = formatAmt(raBill.gstAmount)
            val passedAmt = formatAmt(raBill.grossAmount + raBill.gstAmount)
            val totalDeductions = formatAmt(raBill.gstAmount + raBill.labourCess + raBill.securityDeposit + raBill.otherRecoveries)
            val netChequeAmt = formatAmt(raBill.netPayable)
            
            // Doc 1: कार्यालयीन टीपणी
            val doc1 = ""\"<div class='page-break'>
                <h3 class='center'>पिंपरी चिंचवड महानगरपालिका, \$zone, स्थापत्य विभाग.</h3>
                <h4>संदर्भ: मा. शहर अभियंता यांचे परिपत्रक क्र. स्थापत्य/शअ/तां/४/५४/२०२१, दि. २७/०१/२०२१ (३०% व त्यापेक्षा कमी निविदा दर व Quantity Variation मंजुरी).</h4>
                <h2 class='center'>कार्यालयीन टीपणी</h2>
                <p><b>विषय:</b> \$workName</p>
                <p><b>मक्तेदार:</b> \$contractorName</p>
                <p><b>निविदा सूचना क्रमांक:</b> \$tenderNo</p>
                <p>उपरोक्त विषयांकीत कामाचा कार्यारंभ आदेश ठेकेदार \$contractorName यांना देण्यात आला असून कामाचा स्वीकृत निविदा दर _______________ इतका आहे. त्यानुसार प्रत्यक्ष जागेवरील परिस्थितीनुसार आवश्यकतेनुसार इतर अनुषंगिक कामे करणे गरजेचे आहे.</p>
                <p>परंतु सदर कामे केल्यास मूळ निविदेतील काही बाबींच्या परिमाणात वाढ (Quantity Variation) होणार आहे. सदर बाबींमुळे मूळ निविदा रकमेत बदल होत नसून इतर बाबींच्या बचतीमधून सदर वाढीव परिमाणाचे काम पूर्ण होत असल्याचे समर्थन याद्वारे करण्यात येत आहे.</p>
                <p><b>आर्थिक गोषवारा:</b><br>
                १. एकूण काम मूल्य: ₹ \$grossAmt<br>
                २. निविदा दर वजा जाता करपात्र रक्कम: ₹ \$taxableAmt<br>
                ३. १८% जीएसटी मिळून मंजूर रक्कम: ₹ \$passedAmt<br>
                ४. एकूण वैधानिक कपाती (सुरक्षा ठेव + आयकर + GST-TDS + कामगार उपकर): ₹ \$totalDeductions<br>
                <b>५. निव्वळ देय धनादेश रक्कम: ₹ \$netChequeAmt</b>
                </p>
                <p>तरी सदर सुधारीत परिमाणास व देयकास मान्यता मिळणेकामी स्वाक्षरीस्तव सविनय सादर.</p>
                <div class='signature-block'>
                    <div class='signature-item'><b>कनिष्ठ अभियंता (स्था)</b><br>\$zone</div>
                    <div class='signature-item'><b>उप अभियंता (स्था)</b><br>\$zone</div>
                    <div class='signature-item'><b>कार्यकारी अभियंता (स्था)</b><br>\$zone</div>
                    <div class='signature-item'><b>सह शहर अभियंता / शहर अभियंता</b></div>
                </div>
            </div>""\"
            
            // Doc 2: २० मुद्द्यांचा गोषवारा
            val doc2 = ""\"<div class='page-break'>
                <h2 class='center'>चालू / अंतिम देयक २० मुद्द्यांचा गोषवारा दाखला</h2>
                <ol>
                    <li><b>कामाचे नाव:</b> \$workName</li>
                    <li><b>ठेकेदाराचे नाव:</b> \$contractorName</li>
                    <li><b>अंदाजपत्रकीय किंमत:</b> ₹ \${formatAmt(project.estimateAmount)}</li>
                    <li><b>टेंडरची रक्कम:</b> ₹ \${formatAmt(project.agreementAmount)}</li>
                    <li><b>प्रशासकीय मान्यता:</b> _______________</li>
                    <li><b>तांत्रिक मान्यता:</b> _______________</li>
                    <li><b>जाहिरात दिनांक:</b> _______________</li>
                    <li><b>निविदा मान्यता दिनांक:</b> _______________</li>
                    <li><b>कार्यारंभ आदेश दिनांक:</b> _______________</li>
                    <li><b>कामाची मुदत:</b> _______________</li>
                    <li><b>प्रत्यक्ष काम संपलेली तारीख:</b> _______________</li>
                    <li><b>मोजमाप उशिरा घेतल्याचे कारण:</b> नाही</li>
                    <li><b>मुदतवाढ:</b> नाही</li>
                    <li><b>बिलाची रक्कम:</b> ₹ \$grossAmt</li>
                    <li><b>एस्टिमेट रिवाईज करणे गरजेचे आहे काय:</b> नाही</li>
                    <li><b>जादा भाव मंजूर केले काय:</b> नाही</li>
                    <li><b>सिमेंट व साहित्याची वसुली:</b> ठेकेदाराने स्वतः व्यवस्था केली</li>
                    <li><b>पाणीपट्टी कपात:</b> ठेकेदाराने स्वतः व्यवस्था केली</li>
                    <li><b>मशिनरी भाडे:</b> ठेकेदाराने स्वतः व्यवस्था केली</li>
                    <li><b>रॉयल्टी कपात:</b> लागू असल्यास कपात केली आहे</li>
                </ol>
                <div class='signature-block'>
                    <div class='signature-item'><b>कनिष्ठ अभियंता (स्था)</b><br>\$zone</div>
                    <div class='signature-item'><b>उप अभियंता (स्था)</b><br>\$zone</div>
                </div>
            </div>""\"
            
            // Doc 3: DE 100%
            val doc3 = ""\"<div class='page-break'>
                <h2 class='center'>उपअभियंता १००% मोजमाप तपासणी दाखला</h2>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <p>प्रस्तुत कामाची मी <b>\$deName</b>, उपअभियंता विभाग स्थापत्य <b>\$zone</b> १००% तपासणी केली असून सदरच्या कामाचे एस्टिमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार काम योग्य व समाधानकारक आहे.</p>
                <br><br><br>
                <div class='right'>
                    <p><b>उप अभियंता (स्था)</b><br>\$zone<br>पिं. चिं. मनपा.</p>
                </div>
            </div>""\"
            
            // Doc 4: EE 25%
            val doc4 = ""\"<div class='page-break'>
                <h2 class='center'>कार्यकारी अभियंता २५% मोजमाप तपासणी दाखला</h2>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <p>प्रस्तुत कामाची मी <b>\$eeName</b>, कार्यकारी अभियंता विभाग स्थापत्य <b>\$zone</b> २५% तपासणी केली असून सदरच्या कामाचे एस्टिमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार काम योग्य व समाधानकारक आहे.</p>
                <br><br><br>
                <div class='right'>
                    <p><b>कार्यकारी अभियंता (स्था)</b><br>\$zone<br>पिं. चिं. मनपा.</p>
                </div>
            </div>""\"
            
            // Doc 5: Payment Schedule
            val doc5 = ""\"<div class='page-break'>
                <h2 class='center'>Payment Schedule दाखला (देयक इतिहास तक्ता)</h2>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <table>
                    <tr><th>अ.क्र.</th><th>बिल क्र.</th><th>बिलाचा दिनांक</th><th>बिलाची रक्कम (₹)</th><th>शेरा</th></tr>
                    <tr><td>१</td><td>\${raBill.billNumber}</td><td>_______________</td><td>\$grossAmt</td><td>उपलब्ध तरतुदीप्रमाणे चालू देयक अदा करणेत येत आहे</td></tr>
                </table>
                <br><br><br>
                <div class='right'>
                    <p><b>कार्यकारी अभियंता (स्था)</b><br>पिंपरी चिंचवड महानगरपालिका</p>
                </div>
            </div>""\"
            
            // Doc 6: Site verification
            val doc6 = ""\"<div class='page-break'>
                <h2 class='center'>मूळ जागेवर काम झालेबाबत व स्थळ बदल नसलेबाबत दाखला</h2>
                <p><b>ठेकेदाराचे नाव:</b> \$contractorName</p>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <p>प्रस्तुत काम अंदाजपत्रकानुसार त्याच जागेवर पूर्ण करण्यात आलेले असून कोणताही स्थळ बदल करण्यात आलेला नाही.</p>
                <br><br><br>
                <div class='signature-block'>
                    <div class='signature-item'><b>कनिष्ठ अभियंता (स्था)</b><br>\$zone</div>
                    <div class='signature-item'><b>उप अभियंता (स्था)</b><br>\$zone</div>
                </div>
            </div>""\"
            
            // Doc 7: Labor Laws
            val doc7 = ""\"<div class='page-break'>
                <h2 class='center'>कंत्राटी कामगार कायदा, किमान वेतन, PF व विमा दाखला</h2>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <p><b>मक्तेदार:</b> \$contractorName</p>
                <p>वरील कामकाजाबाबत ठेकेदार \$contractorName यांनी प्रकरणी कंत्राटी कामगार (नियमन व निर्मूलन) अधिनियम १९७० मधील तरतुदींचे पालन केले आहे. तसेच किमान वेतन कायदा १९४८, कर्मचारी राज्य विमा कायदा (ESIC) १९४८, भविष्य निर्वाह निधी (PF) कायदा १९५२, आणि विमा पॉलिसी (National Insurance Co. Ltd.) इत्यादी कायदेशीर बाबींचे काटेकोरपणे पालन केले आहे.</p>
                <br><br><br>
                <div class='signature-block'>
                    <div class='signature-item'><b>पर्यवेक्षकीय अधिकारी (JE)</b><br>स्वाक्षरी: <br>पदनाम:</div>
                    <div class='signature-item'><b>विभागप्रमुख / सक्षम प्राधिकारी (EE)</b><br>स्वाक्षरी: <br>पदनाम:</div>
                </div>
                <p><small>टिप – सदरचा दाखला संबंधित ठेकेदाराचे बिल अदा करताना प्रकरणी समाविष्ट करणे बंधनकारक आहे.</small></p>
            </div>""\"
            
            // Doc 8: GIS Mapping
            val doc8 = ""\"<div class='page-break'>
                <h3 class='center'>पिंपरी चिंचवड महानगरपालिका, पिंपरी – ४११ ०१८</h3>
                <h2 class='center'>जीआयएस मॅपिंग (GIS Mapping) दाखला</h2>
                <p><b>कामाचे नाव:</b> \$workName</p>
                <p>सदर कामाअंतर्गत केलेल्या कामाची GIS Mapping नोंद घेण्यात आलेली असून, सदर कामाची बिल अदायगी करण्यात यावी.</p>
                <br><br><br>
                <div class='right'>
                    <p><b>कार्यकारी अभियंता (स्था)</b><br>\$zone<br>पिं. चिं. महानगरपालिका, पिंपरी – ४११ ०१८</p>
                </div>
            </div>""\"

            val allDocs = listOf(doc1, doc2, doc3, doc4, doc5, doc6, doc7, doc8)
            
            if (docIndex != null && docIndex in 0..7) {
                append(allDocs[docIndex])
            } else {
                allDocs.forEach { append(it) }
            }

            append("</body></html>")
        }
        printHtml(context, html, "Certificates_\${raBill.billNumber}_\${docIndex ?: "All"}", landscape = false)
        return "Opening PDF Preview..."
    }"""
    
    with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "w") as f:
        f.write(content[:start_idx] + new_func + content[end_idx:])

