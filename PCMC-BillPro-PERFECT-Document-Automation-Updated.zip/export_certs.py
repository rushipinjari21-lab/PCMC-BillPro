import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

cert_function = """
    fun exportCertificatesToCsv(
        context: Context,
        project: Project,
        raBill: com.example.data.RaBill
    ): String {
        val fileName = "CERTIFICATES_${raBill.billNumber}_${project.sapWorkKey}.csv"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        val file = File(dir, fileName)

        try {
            val writer = FileWriter(file)
            writer.append('\\uFEFF')
            
            val workName = project.workName.replace(",", " ")
            val contractorName = project.contractorName.replace(",", " ")
            
            writer.append("पहिले आर. ए. बिल,,,,\\n\\n")
            writer.append("१) कामाचे नाव - $workName,,,,\\n")
            writer.append("२) ठेकेदाराचे नाव - $contractorName,,,,\\n")
            writer.append("३) अंदाजपत्रकीय किंमत - रक्कम रुपये ${project.estimateAmount},,,,\\n")
            writer.append("४) टेंडरची रक्कम - रक्कम रुपये ${project.agreementAmount},,,,\\n")
            writer.append("५) कामाची प्रशासकीय मान्यता - र.रु.${project.estimateAmount},,,,\\n")
            writer.append("६) कामाला तांत्रिक मान्यता - र.रु.${project.agreementAmount},,,,\\n")
            writer.append("७) जाहिरातीचे वर्तमानपत्र व दिनांक - ${project.tenderNumber},,,,\\n")
            writer.append("८) कामाची निविदा केव्हा मान्य झाली - ,,,,\\n")
            writer.append("९) कामाचा आदेश दिलेला दिनांक - ,,,,\\n")
            writer.append("१०) कामाची मुदत - ,,,,\\n")
            writer.append("११) प्रत्यक्ष काम संपलेली तारिख - काम चालू आहे.,,,,\\n")
            writer.append("१२) काम पुर्ण झाले असल्यास कामाचे माप उशिरा घेतले त्याचे कारण - नाही,,,,\\n")
            writer.append("१३) मुदतवाढ दिली काय ? दिल्यास केव्ही दिली व किती दिली - ,,,,\\n")
            writer.append("१४) पहिले आर. ए. बिलाची रक्कम रुपये - र.रु. ${raBill.grossAmount},,,,\\n")
            writer.append("१५) एस्टिमेट रिव्हाईज करणे जरुर आहे काय ? - नाही,,,,\\n")
            writer.append("१६) जादा बाब मंजुर करुन घेतले काय ? - नाही,,,,\\n")
            writer.append("१७) ठेकेदारास सिमेंट व इतर सामान एकूण किती दिली व त्याची वसुली कशी केली - ठेकेदार याने स्वतः व्यवस्था केली.,,,,\\n")
            writer.append("१८) ठेकेदाराने पाणी वापरले काय व त्याचे पैसे भरले नसल्यास १/२ टक्के कापुन घेतले काय ? - ठेकेदार याने स्वतः व्यवस्था केली.,,,,\\n")
            writer.append("१९) ठेकेदारास मशिनरी भाड्याने दिली काय ? - ठेकेदार याने स्वतः व्यवस्था केली,,,,\\n")
            writer.append("२०) इतर - सदर बिलामधून रॉयल्टीपोटी र.रु. 0.00 वजा करणेत यावी.,,,,\\n\\n")
            writer.append("कनिष्ठ अभियंता,,उप अभियंता,,\\n")
            writer.append("पिंपरी चिंचवड महानगरपालिका,,पिंपरी चिंचवड महानगरपालिका,,\\n")
            writer.append("पिंपरी - ४११ ०१८,,पिंपरी - ४११ ०१८,,\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")
            
            writer.append("दाखला,,,,\\n\\n")
            writer.append("१) ठेकेदाराचे नाव - $contractorName,,,,\\n")
            writer.append("२) कामाचे नाव - $workName,,,,\\n")
            writer.append("३) प्रशासकीय मान्यता - रक्कम रुपये ${project.estimateAmount},,,,\\n")
            writer.append("४) निविदा रक्कम - रक्कम रुपये ${project.agreementAmount},,,,\\n")
            writer.append("५) निविदा क्रमांक - ${project.tenderNumber},,,,\\n")
            writer.append("६) कामाचा दर - कमी/जास्त,,,,\\n")
            writer.append("७) कामाची मुळ मुदत - ,,,,\\n")
            writer.append("८) कामाचे बिल क्रमांक - ${raBill.billNumber},,,,\\n\\n")
            writer.append("प्रस्तुत कामाची मी उप अभियंता विभाग स्थापत्य क क्षत्रिय १००% तपासणी केली असुन,,,,\\n")
            writer.append("सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम,,,,\\n")
            writer.append("विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.,,,,\\n\\n")
            writer.append(",,,,उप अभियंता\\n")
            writer.append(",,,,स्थापत्य क क्षत्रिय\\n")
            writer.append(",,,,पिं.चिं.मनपा\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")
            
            writer.append("दाखला,,,,\\n\\n")
            writer.append("१) ठेकेदाराचे नाव - $contractorName,,,,\\n")
            writer.append("२) कामाचे नाव - $workName,,,,\\n")
            writer.append("३) प्रशासकीय मान्यता - रक्कम रुपये ${project.estimateAmount},,,,\\n")
            writer.append("४) निविदा रक्कम - रक्कम रुपये ${project.agreementAmount},,,,\\n")
            writer.append("५) निविदा क्रमांक - ${project.tenderNumber},,,,\\n")
            writer.append("६) कामाचा दर - कमी/जास्त,,,,\\n")
            writer.append("७) कामाची मुळ मुदत - ,,,,\\n")
            writer.append("८) कामाचे बिल क्रमांक - ${raBill.billNumber},,,,\\n\\n")
            writer.append("प्रस्तुत कामाची मी कार्यकारी अभियंता विभाग स्थापत्य क क्षत्रिय २५% तपासणी केली असुन,,,,\\n")
            writer.append("सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम,,,,\\n")
            writer.append("विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.,,,,\\n\\n")
            writer.append(",,,,कार्यकारी अभियंता\\n")
            writer.append(",,,,स्थापत्य क क्षत्रिय\\n")
            writer.append(",,,,पिं.चिं.मनपा\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")

            writer.append("Payment Schedule,,,,\\n\\n")
            writer.append("कामाचे नाव - $workName,,,,\\n")
            writer.append("निविदा क्रमांक - ${project.tenderNumber},,,,\\n\\n")
            writer.append("Sr. No.,Bill No.,Bill Date,Bill Amount,Remark\\n")
            writer.append("1,${raBill.billNumber},,${raBill.grossAmount},उपलब्ध तरतुदीप्रमाणे पहिले रनिंग देयक अदा करणेत येत आहे\\n\\n")
            writer.append(",,,,कार्यकारी अभियंता\\n")
            writer.append(",,,,स्थापत्य क क्षत्रिय\\n")
            writer.append(",,,,पिंपरी चिंचवड महानगरपालिका\\n")
            writer.append(",,,,पिंपरी पुणे-१८\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")

            writer.append("दाखला,,,,\\n\\n")
            writer.append("१) ठेकेदाराचे नाव - $contractorName,,,,\\n")
            writer.append("२) कामाचे नाव - $workName,,,,\\n")
            writer.append("३) निविदा रक्कम - रक्कम रुपये ${project.agreementAmount},,,,\\n")
            writer.append("४) निविदा क्रमांक - ${project.tenderNumber},,,,\\n\\n")
            writer.append("प्रस्तुत काम अंदाजपत्रकानुसार त्याच जागेवर पुर्ण करणेत आलेले,,,,\\n")
            writer.append("असून कोणताही स्थळ बदल करणेत आलेला नाही.,,,,\\n\\n")
            writer.append("कनिष्ठ अभियंता,,,,उप अभियंता\\n")
            writer.append("स्थापत्य क क्षत्रिय,,,,स्थापत्य क क्षत्रिय\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")

            writer.append("पिंपरी चिंचवड महानगरपालिका,,,,\\n")
            writer.append("क क्षेत्रीय कार्यालय स्थापत्य विभाग,,,,\\n\\n")
            writer.append("दाखला,,,,\\n\\n")
            writer.append("कामाचे नाव - $workName,,,,\\n")
            writer.append("निविदा क्रमांक - ${project.tenderNumber},,,,\\n")
            writer.append("ठेकेदाराचे नाव - $contractorName,,,,\\n\\n")
            writer.append("वरील कामकाजाबाबत ठेकेदार $contractorName यांनी प्रकरणी कंत्राटी,,,,\\n")
            writer.append("कामगार (नियमन व निर्मूलन) अधिनियम १९७० मधील तरतूदींचे पालन केले आहे. तसेच,,,,\\n")
            writer.append("किमान वेतन कायदा १९४८ कर्मचारी राज्या विमा कायदा १९४८ भविष्य निर्वाह निधी,,,,\\n")
            writer.append("कायदा १९५२ इत्यादी कायदेशीर बाबींचे काटेकोरपणे पालन केले आहे. कंत्राटदाराने,,,,\\n")
            writer.append("कामाचा व त्यावर काम करणा-या कामगारांचा विमा नॅशनल इंन्शुरन्स कं. लि. चिंचवड,,,,\\n")
            writer.append("यांच्याकडे उतरवला आहे.,,,,\\n\\n")
            writer.append("पर्यवेक्षकीय अधिकारी -,,,,विभागप्रमुख / प्राधिकृत सक्षम अधिकारी\\n")
            writer.append("स्वाक्षरी -,,,,स्वाक्षरी -\\n")
            writer.append("पदनाम -,,,,पदनाम -\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")
            
            writer.append("पिंपरी चिंचवड महानगरपालिका पिंपरी - ४११ ०१८,,,,\\n")
            writer.append("GIS Mapping दाखला,,,,\\n\\n")
            writer.append("१) कामाचे नाव - $workName,,,,\\n")
            writer.append("२) निविदा क्रमांक - ${project.tenderNumber},,,,\\n\\n")
            writer.append("सदर कामाअंतर्गत केलेल्या कामाची GIS Mapping नोंद घेण्यात,,,,\\n")
            writer.append("आलेली असून सदर कामाची बिल अदायगी करणेत यावी.,,,,\\n\\n")
            writer.append(",,,,कार्यकारी अभियंता (स्था)\\n")
            writer.append(",,,,क क्षेत्रीय कार्यालय\\n")
            writer.append(",,,,पिंपरी चिंचवड महानगरपालिका\\n")
            writer.append(",,,,पिंपरी - ४११ ०१८\\n\\n")
            writer.append("--------------------------------------------------------------------------------,\\n\\n")

            writer.append("कार्यालयीन टिपणी,,,,क क्षेत्रीय स्थापत्य विभाग\\n\\n")
            writer.append("विषय - $workName,,,,\\n")
            writer.append("निविदा नोटीस क्र. ${project.tenderNumber},,,,\\n\\n")
            writer.append("मा.स.सादर,,,,\\n\\n")
            writer.append("उपरोक्त विषयांकीत कामाचा आदेश ठेकेदार $contractorName यांना,,,,\\n")
            writer.append("देण्यात आला असून कामाचा स्विकृत निविदा दर कमी/जास्त इतका आहे. त्यानुसार,,,,\\n")
            writer.append("आवश्यकतेनुसार इतर अनुषंगिक कामे करणे गरजेचे आहे. परंतु सदर कामे केल्यास मुळ निविदेतील,,,,\\n")
            writer.append("काही बाबींच्या परिमाणात वाढ होणार marginal आहे. सदर बाबींमुळे मुळ निविदा रक्कम,,,,\\n")
            writer.append("बदलत नसून उर्वरीत बाबींच्या बचतीमधून सदर वाढीव परिमाणाचे काम करता येणार आहे.,,,,\\n\\n")
            writer.append("तरी सोबत जोडलेल्या Quantity Variation Sheet प्रमाणे सुधारीत,,,,\\n")
            writer.append("परिमाणास मान्यता घेणेकामी स्वाक्षरीस्तव सविनय सादर.,,,,\\n\\n")
            writer.append("उप अभियंता (स्था),,कार्यकारी अभियंता (स्था),,सह शहर अभियंता\\n")
            writer.append("क क्षेत्रीय कार्यालय,,क क्षेत्रीय कार्यालय,,पिंपरी चिंचवड महानगरपालिका\\n")
            writer.append("पिं.चिं.महानगरपालिका,,पिं.चिं.महानगरपालिका,,पिंपरी-४११ ०१८\\n")
            
            writer.flush()
            writer.close()
            return file.absolutePath
        } catch (e: Exception) {
            Log.e("ExcelExport", "Error exporting Certificates to CSV", e)
            throw e
        }
    }
"""

last_brace = content.rfind('}')
content = content[:last_brace] + cert_function + "\\n}"

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
