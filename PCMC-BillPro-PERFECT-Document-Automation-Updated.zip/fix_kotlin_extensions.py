import re

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    mb_content = f.read()

mb_content = mb_content.replace(
    'import androidx.compose.foundation.layout.*',
    'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.verticalScroll\nimport androidx.compose.foundation.rememberScrollState'
)

mb_content = mb_content.replace(
    '.androidx.compose.foundation.verticalScroll',
    '.verticalScroll'
)

mb_content = mb_content.replace(
    'val scrollState = androidx.compose.foundation.rememberScrollState()',
    'val scrollState = rememberScrollState()'
)

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(mb_content)


with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    rabill_content = f.read()

rabill_content = rabill_content.replace(
    'import androidx.compose.foundation.layout.*',
    'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.verticalScroll\nimport androidx.compose.foundation.rememberScrollState'
)

rabill_content = rabill_content.replace(
    '.androidx.compose.foundation.verticalScroll',
    '.verticalScroll'
)

rabill_content = rabill_content.replace(
    'val scrollState = androidx.compose.foundation.rememberScrollState()',
    'val scrollState = rememberScrollState()'
)

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(rabill_content)

