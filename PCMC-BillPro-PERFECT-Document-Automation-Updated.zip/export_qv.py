import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

qv_function = """
    fun exportQuantityVariationToCsv(
        context: Context,
        project: Project,
        variation: com.example.data.QuantityVariation,
        boqItems: List<BoqItem>,
        variationItems: List<com.example.data.QuantityVariationItem>
    ): String {
        val fileName = "QV_${project.sapWorkKey}_${variation.id}.csv"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        val file = File(dir, fileName)

        try {
            val writer = FileWriter(file)
            
            writer.append("Pimpri Chinchwad Municipal Corporation Pimpri - 18,,,,,,,,\\n")
            writer.append("C Zone Office Civil Department,,,,,,,,\\n")
            writer.append("Name of Work - ${project.workName.replace(",", " ")},,,,,,,,\\n")
            writer.append("Agency Name - M/s. ${project.contractorName.replace(",", " ")},,,,,,,,\\n")
            writer.append("Tender No. ${project.tenderNumber},,,,,,,,\\n")
            writer.append("Quantity Variation Sheet,,,,,,,,\\n")
            writer.append(",,,,,,,,\\n")
            
            writer.append("Item No.,Description,Unit,As per Tender,,,As Executed,,\\n")
            writer.append(",,,Tender quantity,Rate,Amount,Qty. As Executed,Rate,Amount\\n")
            
            var totalTenderAmount = 0.0
            var totalExecutedAmount = 0.0
            
            for (item in variationItems) {
                val boqItem = boqItems.find { it.id == item.boqItemId } ?: continue
                val desc = boqItem.description.replace(",", " ")
                
                val tenderAmount = boqItem.boqQuantity * boqItem.rate
                val executedAmount = item.finalExecutedQuantity * boqItem.rate
                
                totalTenderAmount += tenderAmount
                totalExecutedAmount += executedAmount
                
                writer.append("${boqItem.itemNumber},$desc,${boqItem.unit},${boqItem.boqQuantity},${boqItem.rate},${String.format(Locale.US, "%.2f", tenderAmount)},${item.finalExecutedQuantity},${boqItem.rate},${String.format(Locale.US, "%.2f", executedAmount)}\\n")
            }
            
            writer.append(",,,,Total :-,${String.format(Locale.US, "%.2f", totalTenderAmount)},-,${String.format(Locale.US, "%.2f", totalExecutedAmount)}\\n")
            writer.append(",,,,Total Say :-,${String.format(Locale.US, "%.0f", totalTenderAmount)},-,${String.format(Locale.US, "%.0f", totalExecutedAmount)}\\n")
            
            val diff = totalTenderAmount - totalExecutedAmount
            writer.append("Difference :-,,,,,,,${String.format(Locale.US, "%.2f", diff)},\\n")
            
            writer.append(",,,,,,,,\\n")
            writer.append(",,,,,,,,\\n")
            writer.append("Junior Engineer,,,,,Executive Engineer,,\\n")
            writer.append("C Zone Civil Dept.,,,,,C Zone Civil Dept.,,\\n")
            writer.append("P.C.M.C. Pimpri - 18,,,,,P.C.M.C. Pimpri - 18,,\\n")
            writer.append(",,,Deputy Engineer,,,,,\\n")
            writer.append(",,,C Zone Civil Dept.,,,,,\\n")
            writer.append(",,,P.C.M.C. Pimpri - 18,,,,,\\n")

            writer.flush()
            writer.close()
            return file.absolutePath
        } catch (e: Exception) {
            Log.e("ExcelExport", "Error exporting QV to CSV", e)
            throw e
        }
    }
"""

content = content.replace("}\n}", "}\n" + qv_function + "\n}")

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
