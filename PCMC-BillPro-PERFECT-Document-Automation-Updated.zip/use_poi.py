import re

with open('app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt', 'r') as f:
    content = f.read()

# Update top bar to use POI
content = content.replace("viewModel.exportCertificatesWord(context, sapWorkKey, billId, null)", "viewModel.exportDossierDocxPOI(context, sapWorkKey, billId)")
content = content.replace("viewModel.exportCertificatesExcel(context, sapWorkKey, billId, null)", "viewModel.exportDossierXlsxPOI(context, sapWorkKey, billId)")

with open('app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt', 'w') as f:
    f.write(content)
