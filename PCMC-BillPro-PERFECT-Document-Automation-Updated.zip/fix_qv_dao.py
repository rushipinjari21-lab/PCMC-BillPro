import re

with open('./app/src/main/java/com/example/data/AppDao.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'fun getQuantityVariationsByWorkKey(sapWorkKey: String): Flow<List<QuantityVariation>>',
    'fun getQuantityVariationsByWorkKey(sapWorkKey: String): Flow<List<QuantityVariation>>\n\n    @Query("SELECT * FROM quantity_variations WHERE id = :variationId")\n    suspend fun getQuantityVariationById(variationId: Long): QuantityVariation?'
)

with open('./app/src/main/java/com/example/data/AppDao.kt', 'w') as f:
    f.write(content)
