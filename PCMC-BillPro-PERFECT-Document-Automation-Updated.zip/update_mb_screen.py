import re

with open('app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    content = f.read()

mb_pdf = """                    IconButton(onClick = {
                        viewModel.exportMB(context, sapWorkKey, mbId) { result ->
                            Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(Icons.Default.Download, contentDescription = "Export MB")
                    }"""
                    
mb_excel = """                    IconButton(onClick = {
                        viewModel.exportMBExcel(context, sapWorkKey, mbId) { result ->
                            Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.filled.TableChart, contentDescription = "Export MB Excel")
                    }"""

if "exportMBExcel" not in content:
    content = content.replace(mb_pdf, mb_pdf + "\n" + mb_excel)

with open('app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(content)
