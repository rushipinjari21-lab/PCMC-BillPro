import re

for file_path in [
    'app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt',
    'app/src/main/java/com/example/ui/mb/MeasurementScreen.kt',
    'app/src/main/java/com/example/ui/rabill/RaBillScreen.kt'
]:
    with open(file_path, 'r') as f:
        content = f.read()
    
    if "import androidx.compose.material.icons.filled.List" not in content:
        content = content.replace('import androidx.compose.material.icons.filled.Warning', 'import androidx.compose.material.icons.filled.Warning\nimport androidx.compose.material.icons.filled.List')
    
    content = content.replace('Icons.Default.Download', 'Icons.Default.List')
    
    with open(file_path, 'w') as f:
        f.write(content)
