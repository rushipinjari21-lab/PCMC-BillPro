manifest_path = "app/src/main/AndroidManifest.xml"
with open(manifest_path, "r") as f:
    manifest = f.read()

# Remove the explicit debuggable flag, as Gradle's Lint requires it to be managed automatically during the build process
manifest = manifest.replace('        android:debuggable="false"\n', '')

with open(manifest_path, "w") as f:
    f.write(manifest)
print("Manifest updated.")
