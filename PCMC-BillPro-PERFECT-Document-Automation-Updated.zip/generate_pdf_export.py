import os

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()
    
# We will just write a new PdfExport class instead of parsing the whole ExcelExport right now.
