import re

for file_path in [
    'app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt',
    'app/src/main/java/com/example/ui/mb/MeasurementScreen.kt',
    'app/src/main/java/com/example/ui/rabill/RaBillScreen.kt'
]:
    with open(file_path, 'r') as f:
        content = f.read()
    
    content = content.replace('Icons.Default.List', 'androidx.compose.material.icons.Icons.Default.Download')
    
    if file_path == 'app/src/main/java/com/example/ui/rabill/RaBillScreen.kt':
        if "import androidx.compose.material.icons.Icons" not in content:
            content = content.replace('import androidx.compose.material.icons.filled.Warning', 'import androidx.compose.material.icons.filled.Warning\nimport androidx.compose.material.icons.Icons')

    with open(file_path, 'w') as f:
        f.write(content)
