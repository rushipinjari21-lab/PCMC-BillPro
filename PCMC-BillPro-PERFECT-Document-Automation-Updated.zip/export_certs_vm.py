import re

with open('./app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

export_cert_func = """
    fun exportCertificates(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val path = com.example.utils.ExcelExport.exportCertificatesToCsv(context, project, bill)
                    onResult("Exported Certificates to $path")
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }
"""
content = content.replace("    fun clearError() {", export_cert_func + "\n    fun clearError() {")

with open('./app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
