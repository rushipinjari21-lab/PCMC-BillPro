with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "r") as f:
    content = f.read()

# Replace the messy line with the correct append statements
broken = 'append(".no-border td { border: none !important; padding: 4px; }")")'
good = 'append(".no-border td { border: none !important; padding: 4px; }")'

content = content.replace(broken, good)

# also remove duplicate if it exists:
content = content.replace('append(".no-border td { border: none !important; padding: 4px; }")\n            append(".no-border td { border: none !important; padding: 4px; }")', 'append(".no-border td { border: none !important; padding: 4px; }")')


with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "w") as f:
    f.write(content)

print("Fixed syntax 3")
