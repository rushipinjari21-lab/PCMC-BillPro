import re

with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'r') as f:
    content = f.read()

if "import kotlinx.coroutines.flow.map" not in content:
    content = content.replace("import kotlinx.coroutines.flow.first", "import kotlinx.coroutines.flow.first\nimport kotlinx.coroutines.flow.map")

content = content.replace(
    "fun getMeasurements(mbId: Long): Flow<List<Measurement>> {\n        return measurementStorage.getMeasurements(mbId)\n    }",
    "fun getMeasurements(mbId: Long): Flow<List<Measurement>> {\n        return measurementStorage.getMeasurements(mbId).map { list -> list.sortedByDescending { it.id } }\n    }"
)

with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'w') as f:
    f.write(content)
