import re

with open('app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt', 'r') as f:
    content = f.read()

# Add to top app bar
top_bar_word = """                    IconButton(onClick = {
                        selectedBillId?.let { billId ->
                            viewModel.exportCertificatesWord(context, sapWorkKey, billId, null) { result ->
                                Toast.makeText(context, result ?: "Exported Combined Word Doc", Toast.LENGTH_LONG).show()
                            }
                        } ?: run {
                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.Description, contentDescription = "Export Full Dossier (Word)")
                    }"""

top_bar_excel = """                    IconButton(onClick = {
                        selectedBillId?.let { billId ->
                            viewModel.exportCertificatesExcel(context, sapWorkKey, billId, null) { result ->
                                Toast.makeText(context, result ?: "Exported Combined Excel Doc", Toast.LENGTH_LONG).show()
                            }
                        } ?: run {
                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.filled.TableChart, contentDescription = "Export Full Dossier (Excel)")
                    }"""

if "exportCertificatesExcel" not in content[:content.find("fun CertificatesScreen") + 3000]:
    content = content.replace(top_bar_word, top_bar_word + "\n" + top_bar_excel)

# Add to individual certificate list
list_word = """                                // Export Word Button
                                OutlinedButton(
                                    onClick = {
                                        selectedBillId?.let { billId ->
                                            viewModel.exportCertificatesWord(context, sapWorkKey, billId, index) { result ->
                                                Toast.makeText(context, result ?: "Exported Word Doc", Toast.LENGTH_LONG).show()
                                            }
                                        } ?: run {
                                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = "Export Word", modifier = Modifier.size(18.dp))
                                }"""

list_excel = """
                                // Export Excel Button
                                OutlinedButton(
                                    onClick = {
                                        selectedBillId?.let { billId ->
                                            viewModel.exportCertificatesExcel(context, sapWorkKey, billId, index) { result ->
                                                Toast.makeText(context, result ?: "Exported Excel Doc", Toast.LENGTH_LONG).show()
                                            }
                                        } ?: run {
                                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Icon(androidx.compose.material.icons.filled.TableChart, contentDescription = "Export Excel", modifier = Modifier.size(18.dp))
                                }"""

if "exportCertificatesExcel" not in content[content.find("fun CertificatesScreen") + 3000:]:
    content = content.replace(list_word, list_word + list_excel)

with open('app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt', 'w') as f:
    f.write(content)
