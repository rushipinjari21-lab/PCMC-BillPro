import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

ra_bill_function = """
    fun exportRaBillToCsv(
        context: Context,
        project: Project,
        raBill: com.example.data.RaBill,
        boqItems: List<BoqItem>,
        raBillItems: List<com.example.data.RaBillItem>
    ): String {
        val fileName = "RABILL_${raBill.billNumber}_${project.sapWorkKey}.csv"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        val file = File(dir, fileName)

        try {
            val writer = FileWriter(file)
            
            // Header exactly like PCMC RA Bill PDF
            writer.append("Pimpri-Chinchwad Muncipal Corporation Pimpri 411 018,,,,,,,,,\\n")
            writer.append("Administrative Approval: Rs. ${project.agreementAmount},,,,DIVISION,Engineering,,,,\\n")
            writer.append("Technical Sanction: Rs. ${project.estimateAmount},,,,SUB-DIVISION,,,,,\\n")
            writer.append("Tender Amount: Rs. ${project.agreementAmount},,,,Department : ${project.department},,,,\\n")
            writer.append("Running Account Bill: ${raBill.billNumber},,,,,,,,,\\n")
            writer.append("Name of the Contractor or Suppliers:,${project.contractorName.replace(",", " ")},,,,,,,,\\n")
            writer.append("Name of Work:,${project.workName.replace(",", " ")},,,,,,,,\\n")
            writer.append(",,,,,,,,,\\n")
            
            // Part 1
            writer.append("Part 1- ACCOUNT OF WORK EXECUTED,,,,,,,,,\\n")
            writer.append("Items of work: Grouped under sub-heads or sub work of estimate,,,,,,,,Payments on the basis of actual measurements,\\n")
            writer.append("Item No,Qty Upto Prev,Qty Since Prev,Qty Upto Date,Description Of Work,Unit,Tender Rate,Total Upto date,Since previous Bill,Upto previous bill\\n")
            
            var totalGross = 0.0
            
            for (item in raBillItems) {
                val boqItem = boqItems.find { it.id == item.boqItemId } ?: continue
                val desc = boqItem.description.replace(",", " ").take(60)
                
                writer.append("${boqItem.itemNumber},${item.previousQuantity},${item.currentQuantity},${item.totalQuantity},$desc,${boqItem.unit},${boqItem.rate},${item.amount},${item.amount},0.0\\n")
                totalGross += item.amount
            }
            
            writer.append(",,,,,,,TOTAL Rs,${String.format(Locale.US, "%.2f", totalGross)},\\n")
            writer.append(",,,,,,,Total (A+B+Extra Item) Rs,${String.format(Locale.US, "%.2f", totalGross)},\\n")
            
            val gstTotal = raBill.gstAmount
            val cgst = gstTotal / 2
            val sgst = gstTotal / 2
            
            writer.append(",,,,,,,Total CGST,${String.format(Locale.US, "%.2f", cgst)},\\n")
            writer.append(",,,,,,,Total SGST,${String.format(Locale.US, "%.2f", sgst)},\\n")
            val totalWithGst = totalGross + gstTotal
            writer.append(",,,,,,,Total Amount Rs,${String.format(Locale.US, "%.2f", totalWithGst)},\\n")
            writer.append(",,,,,,,,,\\n")
            
            // Part IV
            writer.append("Part IV Memorandum Of Payments.,,,,,,,,,\\n")
            writer.append("1. Total value of work actually measured as per part I,Rs.,${String.format(Locale.US, "%.2f", totalGross)},,,,,,,\\n")
            writer.append("8. Payments now to be made as detailed below -,,${String.format(Locale.US, "%.2f", raBill.netPayable)},,,,,,,\\n")
            
            writer.append("1,Security Deposit,Rs.,${String.format(Locale.US, "%.2f", raBill.securityDeposit)},,,,,,\\n")
            val tds = totalGross * 0.01 // Assuming 1% CGST and SGST TDS
            writer.append("2,TDS - CGST @ 1%,Rs.,${String.format(Locale.US, "%.2f", tds)},,,,,,\\n")
            writer.append("3,TDS - SGST @ 1%,Rs.,${String.format(Locale.US, "%.2f", tds)},,,,,,\\n")
            writer.append("4,Labor Welfare Upkar,Rs.,${String.format(Locale.US, "%.2f", raBill.labourCess)},,,,,,\\n")
            writer.append("5,Other Recoveries,Rs.,${String.format(Locale.US, "%.2f", raBill.otherRecoveries)},,,,,,\\n")
            
            val totalDeductions = raBill.securityDeposit + raBill.labourCess + raBill.otherRecoveries + (tds * 2)
            writer.append("(a) Total Deductions,,${String.format(Locale.US, "%.2f", totalDeductions)},,,,,,,\\n")
            writer.append("(c) By cheque,,${String.format(Locale.US, "%.2f", raBill.netPayable)},,,,,,,\\n")

            writer.flush()
            writer.close()
            return file.absolutePath
        } catch (e: Exception) {
            Log.e("ExcelExport", "Error exporting RA Bill to CSV", e)
            throw e
        }
    }
}
"""

content = content.replace("}\n}", "}\n" + ra_bill_function)

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
