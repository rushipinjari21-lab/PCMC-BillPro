import re

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    content = f.read()

# Remove the incorrectly placed context retrieval inside LazyColumn block
content = content.replace(
'''        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }
                val context = androidx.compose.ui.platform.LocalContext.current
                items(bills, key = { it.id }) { bill ->
                    RaBillCard(bill = bill, viewModel = viewModel, context = context)
                }
            }
        }''',
'''        } else {
            val context = androidx.compose.ui.platform.LocalContext.current
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }
                items(bills, key = { it.id }) { bill ->
                    RaBillCard(bill = bill, viewModel = viewModel, context = context)
                }
            }
        }'''
)

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(content)
