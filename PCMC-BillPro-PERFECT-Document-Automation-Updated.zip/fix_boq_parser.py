import re

with open('app/src/main/java/com/example/utils/BoqExcelParser.kt', 'r') as f:
    content = f.read()

replacement = """    suspend fun parseExcel(context: Context, uri: Uri): List<BoqItem> = withContext(Dispatchers.IO) {
        if (uri.toString() == "content://demo/pcmc_schedule_b.xlsx") {
            return@withContext getDemoItems()
        }
        val items = mutableListOf<BoqItem>()
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->"""

content = content.replace("""    suspend fun parseExcel(context: Context, uri: Uri): List<BoqItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<BoqItem>()
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->""", replacement)

with open('app/src/main/java/com/example/utils/BoqExcelParser.kt', 'w') as f:
    f.write(content)
