import re

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'r') as f:
    content = f.read()

# Fix ProjectFormScreen
content = content.replace(
'''            ProjectFormScreen(
                viewModel = projectViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }
            )''',
'''            ProjectFormScreen(
                viewModel = projectViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )'''
)

# Fix BoqScreen
content = content.replace(
'''            BoqScreen(
                viewModel = boqViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }
            )''',
'''            BoqScreen(
                viewModel = boqViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMb = { navController.navigate(Screen.MeasurementBook.createRoute(sapWorkKey)) }
            )'''
)

# Fix AbstractScreen
content = content.replace(
'''            AbstractScreen(
                viewModel = abstractViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }
            )''',
'''            AbstractScreen(
                viewModel = abstractViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )'''
)

# Fix RaBillScreen
content = content.replace(
'''            RaBillScreen(
                viewModel = raBillViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }
            )''',
'''            RaBillScreen(
                viewModel = raBillViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )'''
)

# Fix QuantityVariationScreen
content = content.replace(
'''            QuantityVariationScreen(
                viewModel = qvViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }
            )''',
'''            QuantityVariationScreen(
                viewModel = qvViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )'''
)

# Fix the fact that my earlier script broke sapWorkKey logic if it was nullable
content = content.replace("Screen.RaBill.createRoute(sapWorkKey)", "Screen.RaBill.createRoute(sapWorkKey ?: \"\")")
content = content.replace("Screen.MeasurementBook.createRoute(sapWorkKey)", "Screen.MeasurementBook.createRoute(sapWorkKey ?: \"\")")

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'w') as f:
    f.write(content)
