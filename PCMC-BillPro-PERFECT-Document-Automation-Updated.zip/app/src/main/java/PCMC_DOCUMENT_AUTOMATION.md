# PCMC BillPro – Automatic Documents

The project now treats Project as the master data source for PCMC documents.

## Generated document package
1. पहिले आर. ए. बिल (20-point scrutiny)
2. दाखला – उप अभियंता 100% मोजमाप तपासणी
3. दाखला – कार्यकारी अभियंता 25% मोजमाप तपासणी
4. Payment Schedule
5. दाखला – Site Verification
6. दाखला – Labour Compliance
7. GIS Mapping दाखला
8. कार्यालयीन टिपणी

## Data flow
Project → BOQ → MB → MB Abstract → RA Bill → Quantity Variation → Payment → Documents

## MB rules
- Date, Location and Remark are mandatory.
- SSR Code is inherited from the BOQ item.
- MB screen is newest-first.
- Official export is Part A → Part B → Part C → Part D and SSR Code ascending.

## Reference basis
The Marathi wording and page organization are based on the user-supplied PCMC document screenshots and the supplied PCMC R1/MB references. Missing project-specific fields remain editable in the Project → PCMC Document Details section.
