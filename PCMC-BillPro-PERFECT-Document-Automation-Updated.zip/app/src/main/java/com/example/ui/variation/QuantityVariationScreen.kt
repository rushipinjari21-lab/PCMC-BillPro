package com.example.ui.variation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.QuantityVariation
import com.example.data.QuantityVariationItem
import com.example.viewmodel.QuantityVariationViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuantityVariationScreen(
    viewModel: QuantityVariationViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit
) {
    val variations by viewModel.getVariations(sapWorkKey).collectAsStateWithLifecycle(initialValue = emptyList())
    val error by viewModel.error.collectAsStateWithLifecycle()

    var selectedVariation by remember { mutableStateOf<QuantityVariation?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (selectedVariation == null) "Quantity Variations" else "Variation Details") },
                navigationIcon = {
                    IconButton(onClick = { 
                        if (selectedVariation != null) selectedVariation = null else onNavigateBack() 
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            if (selectedVariation == null && variations.none { it.status != "Rejected" }) {
                FloatingActionButton(onClick = { viewModel.generateVariation(sapWorkKey) {} }) {
                    Icon(Icons.Default.Add, contentDescription = "Generate Variation")
                }
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize().padding(16.dp)) {
            if (error != null) {
                Text(error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 16.dp))
            }

            if (selectedVariation == null) {
                if (variations.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No Variations generated yet.")
                    }
                } else {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(variations, key = { it.id }) { variation ->
                            VariationCard(
                                variation = variation,
                                onClick = { selectedVariation = variation },
                                onDownloadClick = {
                                    viewModel.exportQuantityVariation(context, sapWorkKey, variation.id) { result ->
                                        android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        }
                    }
                }
            } else {
                VariationDetailView(
                    viewModel = viewModel,
                    variation = selectedVariation!!,
                    onStatusUpdated = { selectedVariation = null }
                )
            }
        }
    }
}

@Composable
fun VariationCard(variation: QuantityVariation, onClick: () -> Unit, onDownloadClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Status: ${variation.status}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    IconButton(onClick = onDownloadClick) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export")
                    }
                }
                val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(variation.createdDate))
                Text(text = dateStr, style = MaterialTheme.typography.bodySmall)
            }
            if (variation.approverName != null) {
                Text(text = "Approved by: ${variation.approverName}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun VariationDetailView(
    viewModel: QuantityVariationViewModel,
    variation: QuantityVariation,
    onStatusUpdated: () -> Unit
) {
    val items by viewModel.getVariationItems(variation.id).collectAsStateWithLifecycle(initialValue = emptyList())

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Current Status: ${variation.status}", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (variation.status == "Draft") {
                        Button(onClick = { viewModel.submitVariation(variation.id); onStatusUpdated() }) {
                            Text("Submit for Approval")
                        }
                    }
                    if (variation.status == "Submitted") {
                        Button(
                            onClick = { viewModel.approveVariation(variation.id, "Executive Engineer"); onStatusUpdated() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                        ) {
                            Text("Approve")
                        }
                        Button(
                            onClick = { viewModel.rejectVariation(variation.id); onStatusUpdated() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Reject")
                        }
                    }
                }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { item ->
                VariationItemCard(item)
            }
        }
    }
}

@Composable
fun VariationItemCard(item: QuantityVariationItem) {
    val isIncrease = item.variationType == "Increase"
    val color = if (isIncrease) MaterialTheme.colorScheme.error else Color(0xFF4CAF50)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "BOQ Item ID: ${item.boqItemId}", style = MaterialTheme.typography.titleSmall)
                Text(
                    text = "${if (item.variationQuantity > 0) "+" else ""}${String.format("%.2f", item.variationPercentage)}%",
                    style = MaterialTheme.typography.titleSmall,
                    color = color
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Original Qty: ${item.originalBoqQuantity}", style = MaterialTheme.typography.bodySmall)
                Text(text = "Final Qty: ${item.finalExecutedQuantity}", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text(text = "Var Amt: ₹%,.2f".format(item.variationAmount), style = MaterialTheme.typography.labelMedium, color = color)
            }
        }
    }
}
