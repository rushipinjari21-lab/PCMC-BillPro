package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object ProjectList : Screen("project_list")
    object ProjectForm : Screen("project_form?sapWorkKey={sapWorkKey}") {
        fun createRoute(sapWorkKey: String?) = 
            if (sapWorkKey != null) "project_form?sapWorkKey=$sapWorkKey" else "project_form"
    }
    object ProjectDetail : Screen("project_detail/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "project_detail/$sapWorkKey"
    }
    object Boq : Screen("boq/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "boq/$sapWorkKey"
    }
    object MeasurementBook : Screen("mb/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "mb/$sapWorkKey"
    }
    object MeasurementBookEntries : Screen("mb_entries/{sapWorkKey}/{mbId}") {
        fun createRoute(sapWorkKey: String, mbId: Long) = "mb_entries/$sapWorkKey/$mbId"
    }
    object Abstract : Screen("abstract/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "abstract/$sapWorkKey"
    }
    object RaBill : Screen("ra_bill/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "ra_bill/$sapWorkKey"
    }
    object QuantityVariation : Screen("qv/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "qv/$sapWorkKey"
    }
    object Certificates : Screen("certificates/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "certificates/$sapWorkKey"
    }
    object Invoice : Screen("invoice/{sapWorkKey}") {
        fun createRoute(sapWorkKey: String) = "invoice/$sapWorkKey"
    }
}
