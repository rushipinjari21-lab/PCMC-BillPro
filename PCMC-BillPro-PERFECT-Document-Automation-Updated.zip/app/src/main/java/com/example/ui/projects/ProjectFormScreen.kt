package com.example.ui.projects

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.Project
import com.example.viewmodel.ProjectViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectFormScreen(
    viewModel: ProjectViewModel,
    sapWorkKey: String?, // Null if creating new
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(sapWorkKey != null) }

    // Form State
    var stateSapWorkKey by remember { mutableStateOf(sapWorkKey ?: "") }
    var workName by remember { mutableStateOf("") }
    var workOrderNumber by remember { mutableStateOf("") }
    var tenderNumber by remember { mutableStateOf("") }
    var contractorName by remember { mutableStateOf("") }
    var contractorAddress by remember { mutableStateOf("") }
    var department by remember { mutableStateOf("") }
    var division by remember { mutableStateOf("") }
    var subDivision by remember { mutableStateOf("") }
    var estimateNumber by remember { mutableStateOf("") }
    var estimateAmount by remember { mutableStateOf("") }
    var agreementAmount by remember { mutableStateOf("") }
    var budgetHead by remember { mutableStateOf("") }
    var ssrYear by remember { mutableStateOf("") }
    var engineerName by remember { mutableStateOf("") }
    var contractorEngineer by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Active") }
    var remarks by remember { mutableStateOf("") }
    var wardName by remember { mutableStateOf("") }
    var regionalOffice by remember { mutableStateOf("") }
    var adminApprovalNumber by remember { mutableStateOf("") }
    var technicalSanctionNumber by remember { mutableStateOf("") }
    var technicalSanctionAmount by remember { mutableStateOf("") }
    var tenderRateType by remember { mutableStateOf("AT PAR") }
    var tenderRatePercent by remember { mutableStateOf("") }
    var advertisementDate by remember { mutableStateOf("") }
    var tenderAcceptanceDate by remember { mutableStateOf("") }
    var workOrderDate by remember { mutableStateOf("") }
    var workDurationMonths by remember { mutableStateOf("12") }
    var panNumber by remember { mutableStateOf("") }
    var gstNumber by remember { mutableStateOf("") }
    var deputyEngineerName by remember { mutableStateOf("") }
    var executiveEngineerName by remember { mutableStateOf("") }

    // Error State
    var sapWorkKeyError by remember { mutableStateOf<String?>(null) }

    val isEditMode = sapWorkKey != null

    LaunchedEffect(sapWorkKey) {
        if (sapWorkKey != null) {
            val project = viewModel.getProject(sapWorkKey)
            if (project != null) {
                workName = project.workName
                workOrderNumber = project.workOrderNumber
                tenderNumber = project.tenderNumber
                contractorName = project.contractorName
                contractorAddress = project.contractorAddress
                department = project.department
                division = project.division
                subDivision = project.subDivision
                estimateNumber = project.estimateNumber
                estimateAmount = project.estimateAmount.toString()
                agreementAmount = project.agreementAmount.toString()
                budgetHead = project.budgetHead
                ssrYear = project.ssrYear
                engineerName = project.engineerName
                contractorEngineer = project.contractorEngineer
                status = project.status
                remarks = project.remarks
                wardName = project.wardName
                regionalOffice = project.regionalOffice
                adminApprovalNumber = project.adminApprovalNumber
                technicalSanctionNumber = project.technicalSanctionNumber
                technicalSanctionAmount = project.technicalSanctionAmount.toString()
                tenderRateType = project.tenderRateType
                tenderRatePercent = project.tenderRatePercent.toString()
                advertisementDate = project.advertisementDate
                tenderAcceptanceDate = project.tenderAcceptanceDate
                workOrderDate = project.workOrderDate
                workDurationMonths = project.workDurationMonths.toString()
                panNumber = project.panNumber
                gstNumber = project.gstNumber
                deputyEngineerName = project.deputyEngineerName
                executiveEngineerName = project.executiveEngineerName
            }
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "Edit Project" else "New Project") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        }
    ) { innerPadding ->
        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.padding(innerPadding))
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            item {
                OutlinedTextField(
                    value = stateSapWorkKey,
                    onValueChange = { 
                        stateSapWorkKey = it
                        sapWorkKeyError = null
                    },
                    label = { Text("SAP Work Key *") },
                    isError = sapWorkKeyError != null,
                    supportingText = { sapWorkKeyError?.let { Text(it) } },
                    enabled = !isEditMode, // Key cannot be edited once created
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { FormTextField(value = workName, onValueChange = { workName = it }, label = "Work Name") }
            item { FormTextField(value = workOrderNumber, onValueChange = { workOrderNumber = it }, label = "Work Order Number") }
            item { FormTextField(value = tenderNumber, onValueChange = { tenderNumber = it }, label = "Tender Number") }
            item { FormTextField(value = contractorName, onValueChange = { contractorName = it }, label = "Contractor Name") }
            item { FormTextField(value = contractorAddress, onValueChange = { contractorAddress = it }, label = "Contractor Address") }
            
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = department, onValueChange = { department = it }, label = "Department", modifier = Modifier.weight(1f))
                    FormTextField(value = division, onValueChange = { division = it }, label = "Division", modifier = Modifier.weight(1f))
                }
            }
            
            item { FormTextField(value = subDivision, onValueChange = { subDivision = it }, label = "Sub Division") }
            
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = estimateNumber, onValueChange = { estimateNumber = it }, label = "Estimate Number", modifier = Modifier.weight(1f))
                    FormTextField(value = budgetHead, onValueChange = { budgetHead = it }, label = "Budget Head", modifier = Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = estimateAmount, onValueChange = { estimateAmount = it }, label = "Estimate Amount", isNumeric = true, modifier = Modifier.weight(1f))
                    FormTextField(value = agreementAmount, onValueChange = { agreementAmount = it }, label = "Agreement Amount", isNumeric = true, modifier = Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = ssrYear, onValueChange = { ssrYear = it }, label = "SSR Year", modifier = Modifier.weight(1f))
                    FormTextField(value = status, onValueChange = { status = it }, label = "Status", modifier = Modifier.weight(1f))
                }
            }

            item { FormTextField(value = engineerName, onValueChange = { engineerName = it }, label = "Engineer Name") }
            item { FormTextField(value = contractorEngineer, onValueChange = { contractorEngineer = it }, label = "Contractor Engineer") }

            item {
                Text("PCMC Document Details", style = MaterialTheme.typography.titleMedium)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = wardName, onValueChange = { wardName = it }, label = "Ward / Prabhag", modifier = Modifier.weight(1f))
                    FormTextField(value = regionalOffice, onValueChange = { regionalOffice = it }, label = "Regional Office", modifier = Modifier.weight(1f))
                }
            }
            item { FormTextField(value = adminApprovalNumber, onValueChange = { adminApprovalNumber = it }, label = "Administrative Approval Ref.") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = technicalSanctionNumber, onValueChange = { technicalSanctionNumber = it }, label = "Technical Sanction Ref.", modifier = Modifier.weight(1f))
                    FormTextField(value = technicalSanctionAmount, onValueChange = { technicalSanctionAmount = it }, label = "Technical Sanction Amount", isNumeric = true, modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = tenderRateType, onValueChange = { tenderRateType = it.uppercase() }, label = "Tender Rate Type", modifier = Modifier.weight(1f))
                    FormTextField(value = tenderRatePercent, onValueChange = { tenderRatePercent = it }, label = "Tender Rate %", isNumeric = true, modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = advertisementDate, onValueChange = { advertisementDate = it }, label = "Advertisement Date", modifier = Modifier.weight(1f))
                    FormTextField(value = tenderAcceptanceDate, onValueChange = { tenderAcceptanceDate = it }, label = "Tender Acceptance Date", modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = workOrderDate, onValueChange = { workOrderDate = it }, label = "Work Order Date", modifier = Modifier.weight(1f))
                    FormTextField(value = workDurationMonths, onValueChange = { workDurationMonths = it }, label = "Duration (Months)", isNumeric = true, modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = panNumber, onValueChange = { panNumber = it.uppercase() }, label = "Contractor PAN", modifier = Modifier.weight(1f))
                    FormTextField(value = gstNumber, onValueChange = { gstNumber = it.uppercase() }, label = "Contractor GST", modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormTextField(value = deputyEngineerName, onValueChange = { deputyEngineerName = it }, label = "Deputy Engineer", modifier = Modifier.weight(1f))
                    FormTextField(value = executiveEngineerName, onValueChange = { executiveEngineerName = it }, label = "Executive Engineer", modifier = Modifier.weight(1f))
                }
            }
            item { FormTextField(value = remarks, onValueChange = { remarks = it }, label = "Remarks", minLines = 3) }

            item {
                Button(
                    onClick = {
                        if (stateSapWorkKey.isBlank()) {
                            sapWorkKeyError = "SAP Work Key is required"
                            return@Button
                        }
                        coroutineScope.launch {
                            // Enforce uniqueness if creating new
                            if (!isEditMode) {
                                val existing = viewModel.getProject(stateSapWorkKey)
                                if (existing != null) {
                                    sapWorkKeyError = "SAP Work Key must be unique"
                                    return@launch
                                }
                            }

                            val project = Project(
                                sapWorkKey = stateSapWorkKey,
                                workName = workName,
                                workOrderNumber = workOrderNumber,
                                tenderNumber = tenderNumber,
                                contractorName = contractorName,
                                contractorAddress = contractorAddress,
                                department = department,
                                division = division,
                                subDivision = subDivision,
                                estimateNumber = estimateNumber,
                                estimateAmount = estimateAmount.toDoubleOrNull() ?: 0.0,
                                agreementAmount = agreementAmount.toDoubleOrNull() ?: 0.0,
                                budgetHead = budgetHead,
                                ssrYear = ssrYear,
                                startDate = System.currentTimeMillis(), // TODO: add date picker
                                completionDate = 0L,
                                engineerName = engineerName,
                                contractorEngineer = contractorEngineer,
                                status = status,
                                remarks = remarks,
                                wardName = wardName,
                                regionalOffice = regionalOffice,
                                adminApprovalNumber = adminApprovalNumber,
                                technicalSanctionNumber = technicalSanctionNumber,
                                technicalSanctionAmount = technicalSanctionAmount.toDoubleOrNull() ?: 0.0,
                                tenderRateType = tenderRateType.ifBlank { "AT PAR" },
                                tenderRatePercent = tenderRatePercent.toDoubleOrNull() ?: 0.0,
                                advertisementDate = advertisementDate,
                                tenderAcceptanceDate = tenderAcceptanceDate,
                                workOrderDate = workOrderDate,
                                workDurationMonths = workDurationMonths.toIntOrNull() ?: 12,
                                panNumber = panNumber,
                                gstNumber = gstNumber,
                                deputyEngineerName = deputyEngineerName,
                                executiveEngineerName = executiveEngineerName
                            )
                            viewModel.saveProject(project)
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                ) {
                    Text("Save Project")
                }
            }
        }
    }
}

@Composable
fun FormTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isNumeric: Boolean = false,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        keyboardOptions = if (isNumeric) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        minLines = minLines
    )
}
