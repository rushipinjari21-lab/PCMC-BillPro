package com.example.ui.mb

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MeasurementBook
import com.example.viewmodel.MeasurementViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeasurementBookListScreen(
    viewModel: MeasurementViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit,
    onNavigateToMb: (Long) -> Unit
) {
    val mbs by viewModel.getMeasurementBooks(sapWorkKey).collectAsStateWithLifecycle(initialValue = emptyList())
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Measurement Books - $sapWorkKey") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Create MB")
            }
        }
    ) { innerPadding ->
        if (mbs.isEmpty()) {
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No Measurement Books found. Create one to start.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }
                items(mbs, key = { it.id }) { mb ->
                    MbCard(mb = mb, onClick = { onNavigateToMb(mb.id) })
                }
            }
        }
    }

    if (showCreateDialog) {
        var newMbNumber by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New MB") },
            text = {
                OutlinedTextField(
                    value = newMbNumber,
                    onValueChange = { newMbNumber = it },
                    label = { Text("MB Number (e.g., MB-001)") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.createOrOpenMeasurementBook(sapWorkKey, newMbNumber) { newMbId ->
                        showCreateDialog = false
                        onNavigateToMb(newMbId)
                    }
                }) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun MbCard(mb: MeasurementBook, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "MB Number: ${mb.mbNumber}", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            val dateString = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(mb.date))
            Text(text = "Created: $dateString", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
