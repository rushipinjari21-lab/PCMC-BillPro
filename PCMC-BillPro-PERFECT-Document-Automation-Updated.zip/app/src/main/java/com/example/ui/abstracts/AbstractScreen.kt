package com.example.ui.abstracts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.models.AbstractItem
import com.example.viewmodel.AbstractViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbstractScreen(
    viewModel: AbstractViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit
) {
    val abstractItems by viewModel.getProjectAbstract(sapWorkKey).collectAsStateWithLifecycle(initialValue = emptyList())
    val totalAmount = abstractItems.sumOf { it.amount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Abstract - $sapWorkKey") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Total Abstract Value", style = MaterialTheme.typography.titleSmall)
                    Text("₹ %,.2f".format(totalAmount), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                }
            }

            if (abstractItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No executed quantities found. Add measurements in MB first.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(abstractItems, key = { it.boqItem.id }) { item ->
                        AbstractItemCard(item)
                    }
                }
            }
        }
    }
}

@Composable
fun AbstractItemCard(abstractItem: AbstractItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = abstractItem.boqItem.ssrCode, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(text = "₹ %,.2f".format(abstractItem.amount), style = MaterialTheme.typography.titleMedium)
            }
            Text(text = abstractItem.boqItem.description, style = MaterialTheme.typography.bodyMedium)
            
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("BOQ Qty: ${abstractItem.boqItem.boqQuantity}", style = MaterialTheme.typography.bodySmall)
                    Text("Total Exec: ${abstractItem.totalQuantity}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Rate: ₹${abstractItem.boqItem.rate}", style = MaterialTheme.typography.bodySmall)
                    Text("Balance: ${abstractItem.balanceQuantity}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
