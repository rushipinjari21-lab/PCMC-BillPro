package com.example.ui.rabill

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.RaBill
import com.example.viewmodel.RaBillViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RaBillScreen(
    viewModel: RaBillViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit
) {
    val bills by viewModel.getRaBills(sapWorkKey).collectAsStateWithLifecycle(initialValue = emptyList())
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RA Bills - $sapWorkKey") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Generate RA Bill")
            }
        }
    ) { innerPadding ->
        if (bills.isEmpty()) {
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No RA Bills generated yet.")
            }
        } else {
            val context = androidx.compose.ui.platform.LocalContext.current
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }
                items(bills, key = { it.id }) { bill ->
                    RaBillCard(bill = bill, viewModel = viewModel, context = context)
                }
            }
        }
    }

    if (showCreateDialog) {
        RaBillCreateDialog(
            viewModel = viewModel,
            sapWorkKey = sapWorkKey,
            onDismiss = { showCreateDialog = false }
        )
    }
}

@Composable
fun RaBillCreateDialog(
    viewModel: RaBillViewModel,
    sapWorkKey: String,
    onDismiss: () -> Unit
) {
    var billNumber by remember { mutableStateOf("") }
    var gstPercent by remember { mutableStateOf("18.0") }
    var labourCessPercent by remember { mutableStateOf("1.0") }
    var sdPercent by remember { mutableStateOf("5.0") }
    var otherRecoveries by remember { mutableStateOf("0.0") }
    var tenderRateType by remember { mutableStateOf("AT PAR") }
    var tenderRatePercent by remember { mutableStateOf("0.0") }
    var testingCharges by remember { mutableStateOf("0.0") }
    var royalty by remember { mutableStateOf("0.0") }
    var tds194cPercent by remember { mutableStateOf("2.0") }
    var tdsCgstPercent by remember { mutableStateOf("1.0") }
    var tdsSgstPercent by remember { mutableStateOf("1.0") }
    var labourWelfarePercent by remember { mutableStateOf("1.0") }

    val error by viewModel.error.collectAsStateWithLifecycle()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generate New RA Bill") },
        text = {
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier.verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                
                OutlinedTextField(
                    value = billNumber,
                    onValueChange = { billNumber = it },
                    label = { Text("Bill Number (e.g. RA-01)") },
                    singleLine = true
                )
                Text("Tender Rate Adjustment", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("AT PAR", "BELOW", "ABOVE").forEach { type ->
                        FilterChip(
                            selected = tenderRateType == type,
                            onClick = { tenderRateType = type },
                            label = { Text(type) }
                        )
                    }
                }
                if (tenderRateType != "AT PAR") {
                    OutlinedTextField(
                        value = tenderRatePercent,
                        onValueChange = { tenderRatePercent = it },
                        label = { Text("Tender Rate % ${if (tenderRateType == "BELOW") "Below" else "Above"}") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }
                OutlinedTextField(
                    value = gstPercent,
                    onValueChange = { gstPercent = it },
                    label = { Text("GST (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = labourCessPercent,
                    onValueChange = { labourCessPercent = it },
                    label = { Text("Labour Cess (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = sdPercent,
                    onValueChange = { sdPercent = it },
                    label = { Text("Security Deposit (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = otherRecoveries,
                    onValueChange = { otherRecoveries = it },
                    label = { Text("Other Recoveries (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = testingCharges,
                    onValueChange = { testingCharges = it },
                    label = { Text("Testing Charges (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = royalty,
                    onValueChange = { royalty = it },
                    label = { Text("Royalty (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                Text("PCMC Payment Deductions", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = tds194cPercent,
                    onValueChange = { tds194cPercent = it },
                    label = { Text("194C Contractor TDS (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = tdsCgstPercent,
                    onValueChange = { tdsCgstPercent = it },
                    label = { Text("TDS CGST (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = tdsSgstPercent,
                    onValueChange = { tdsSgstPercent = it },
                    label = { Text("TDS SGST (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = labourWelfarePercent,
                    onValueChange = { labourWelfarePercent = it },
                    label = { Text("Labour Welfare Cess (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    viewModel.generateRaBill(
                        sapWorkKey = sapWorkKey,
                        billNumber = billNumber,
                        gstPercent = gstPercent.toDoubleOrNull() ?: 18.0,
                        labourCessPercent = labourCessPercent.toDoubleOrNull() ?: 1.0,
                        sdPercent = sdPercent.toDoubleOrNull() ?: 5.0,
                        otherRecoveries = otherRecoveries.toDoubleOrNull() ?: 0.0,
                        tenderRateType = tenderRateType,
                        tenderRatePercent = tenderRatePercent.toDoubleOrNull() ?: 0.0,
                        testingCharges = testingCharges.toDoubleOrNull() ?: 0.0,
                        royalty = royalty.toDoubleOrNull() ?: 0.0,
                        tds194cPercent = tds194cPercent.toDoubleOrNull() ?: 2.0,
                        tdsCgstPercent = tdsCgstPercent.toDoubleOrNull() ?: 1.0,
                        tdsSgstPercent = tdsSgstPercent.toDoubleOrNull() ?: 1.0,
                        labourWelfarePercent = labourWelfarePercent.toDoubleOrNull() ?: 1.0,
                        onSuccess = { onDismiss() }
                    )
                },
                enabled = billNumber.isNotBlank()
            ) {
                Text("Generate")
            }
        },
        dismissButton = {
            TextButton(
                onClick = { 
                    viewModel.clearError()
                    onDismiss() 
                }
            ) { Text("Cancel") }
        }
    )
}

@Composable
fun RaBillCard(bill: RaBill, viewModel: RaBillViewModel, context: android.content.Context) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(bill.date)),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "${bill.tenderRateType} ${String.format(Locale.US, "%.2f", bill.tenderRatePercent)}% • Work ₹${String.format(Locale.US, "%,.2f", bill.grossAmount)} • Payable ₹${String.format(Locale.US, "%,.2f", bill.netPayable)}",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { 
                        viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RA Bill")
                }
                OutlinedButton(
                    onClick = { 
                        viewModel.exportRaBillExcel(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RA Bill Excel")
                }
                
                Button(
                    onClick = { 
                        viewModel.exportCertificates(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("दाखला (Certificates)")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Gross Amount:", style = MaterialTheme.typography.bodyMedium)
                Text("₹ %,.2f".format(bill.grossAmount), style = MaterialTheme.typography.bodyMedium)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("GST Amount (+):", style = MaterialTheme.typography.bodySmall)
                Text("₹ %,.2f".format(bill.gstAmount), style = MaterialTheme.typography.bodySmall)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Deductions (Cess+SD+Other) (-):", style = MaterialTheme.typography.bodySmall)
                val totalDeductions = bill.labourCess + bill.securityDeposit + bill.otherRecoveries
                Text("₹ %,.2f".format(totalDeductions), style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Net Payable:", style = MaterialTheme.typography.titleMedium)
                Text("₹ %,.2f".format(bill.netPayable), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
