package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.data.AppDatabase
import com.example.ui.boq.BoqScreen
import com.example.ui.mb.MeasurementBookListScreen
import com.example.ui.mb.MeasurementScreen
import com.example.ui.projects.ProjectDetailScreen
import com.example.ui.projects.ProjectFormScreen
import com.example.ui.projects.ProjectListScreen
import com.example.ui.abstracts.AbstractScreen
import com.example.ui.rabill.RaBillScreen
import com.example.ui.variation.QuantityVariationScreen
import com.example.ui.certificates.CertificatesScreen
import com.example.ui.invoice.InvoiceScreen
import com.example.viewmodel.AbstractViewModel
import com.example.viewmodel.AbstractViewModelFactory
import com.example.viewmodel.BoqViewModel
import com.example.viewmodel.BoqViewModelFactory
import com.example.viewmodel.MeasurementViewModel
import com.example.viewmodel.MeasurementViewModelFactory
import com.example.viewmodel.ProjectViewModel
import com.example.viewmodel.ProjectViewModelFactory
import com.example.viewmodel.QuantityVariationViewModel
import com.example.viewmodel.QuantityVariationViewModelFactory
import com.example.viewmodel.RaBillViewModel
import com.example.viewmodel.RaBillViewModelFactory

@Composable
fun AppNavigation(
    navController: NavHostController,
    database: AppDatabase,
    modifier: Modifier = Modifier
) {
    val projectViewModel: ProjectViewModel = viewModel(
        factory = ProjectViewModelFactory(database.appDao())
    )
    
    val boqViewModel: BoqViewModel = viewModel(
        factory = BoqViewModelFactory(database.appDao())
    )

    val mbViewModel: MeasurementViewModel = viewModel(
        factory = MeasurementViewModelFactory(database.appDao())
    )

    val abstractViewModel: AbstractViewModel = viewModel(
        factory = AbstractViewModelFactory(database.appDao())
    )

    val raBillViewModel: RaBillViewModel = viewModel(
        factory = RaBillViewModelFactory(database.appDao())
    )

    val qvViewModel: QuantityVariationViewModel = viewModel(
        factory = QuantityVariationViewModelFactory(database.appDao())
    )

    NavHost(
        navController = navController,
        startDestination = Screen.ProjectList.route,
        modifier = modifier
    ) {
        composable(Screen.Dashboard.route) {
            // DashboardScreen()
        }

        composable(Screen.ProjectList.route) {
            ProjectListScreen(
                viewModel = projectViewModel,
                onNavigateToForm = { sapWorkKey ->
                    navController.navigate(Screen.ProjectForm.createRoute(sapWorkKey))
                },
                onNavigateToDetail = { sapWorkKey ->
                    navController.navigate(Screen.ProjectDetail.createRoute(sapWorkKey))
                }
            )
        }

        composable(
            route = Screen.ProjectForm.route,
            arguments = listOf(
                navArgument("sapWorkKey") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey")
            ProjectFormScreen(
                viewModel = projectViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.ProjectDetail.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            ProjectDetailScreen(
                viewModel = projectViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToBoq = { navController.navigate(Screen.Boq.createRoute(it)) },
                onNavigateToMb = { navController.navigate(Screen.MeasurementBook.createRoute(it)) },
                onNavigateToAbstract = { navController.navigate(Screen.Abstract.createRoute(it)) },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(it)) },
                onNavigateToQuantityVariation = { navController.navigate(Screen.QuantityVariation.createRoute(it)) },
                onNavigateToCertificates = { navController.navigate(Screen.Certificates.createRoute(it)) },
                onNavigateToInvoice = { navController.navigate(Screen.Invoice.createRoute(it)) }
            )
        }
        
        composable(
            route = Screen.Boq.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            BoqScreen(
                viewModel = boqViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMb = { navController.navigate(Screen.MeasurementBook.createRoute(sapWorkKey ?: "")) }
            )
        }

        composable(
            route = Screen.MeasurementBook.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            MeasurementBookListScreen(
                viewModel = mbViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToMb = { mbId -> navController.navigate(Screen.MeasurementBookEntries.createRoute(sapWorkKey, mbId)) }
            )
        }

        composable(
            route = Screen.MeasurementBookEntries.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType },
                navArgument("mbId") { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            val mbId = backStackEntry.arguments?.getLong("mbId") ?: return@composable
            MeasurementScreen(
                viewModel = mbViewModel,
                sapWorkKey = sapWorkKey,
                mbId = mbId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey ?: "")) }
            )
        }

        composable(
            route = Screen.Abstract.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            AbstractScreen(
                viewModel = abstractViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.RaBill.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            RaBillScreen(
                viewModel = raBillViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.QuantityVariation.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            QuantityVariationScreen(
                viewModel = qvViewModel,
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable(
            route = Screen.Certificates.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            CertificatesScreen(
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Invoice.route,
            arguments = listOf(
                navArgument("sapWorkKey") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val sapWorkKey = backStackEntry.arguments?.getString("sapWorkKey") ?: return@composable
            InvoiceScreen(
                sapWorkKey = sapWorkKey,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
