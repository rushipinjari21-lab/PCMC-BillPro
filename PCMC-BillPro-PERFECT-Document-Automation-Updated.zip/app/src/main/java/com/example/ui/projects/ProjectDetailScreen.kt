package com.example.ui.projects

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.Project
import com.example.viewmodel.ProjectViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    viewModel: ProjectViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit,
    onNavigateToBoq: (String) -> Unit,
    onNavigateToMb: (String) -> Unit,
    onNavigateToAbstract: (String) -> Unit,
    onNavigateToRaBill: (String) -> Unit,
    onNavigateToQuantityVariation: (String) -> Unit,
    onNavigateToCertificates: (String) -> Unit,
    onNavigateToInvoice: (String) -> Unit
) {
    var project by remember { mutableStateOf<Project?>(null) }
    
    LaunchedEffect(sapWorkKey) {
        project = viewModel.getProject(sapWorkKey)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.workName ?: "Project Hub") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        }
    ) { innerPadding ->
        if (project == null) {
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SAP Work Key: \${project!!.sapWorkKey}", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Contractor: \${project!!.contractorName}", style = MaterialTheme.typography.bodyMedium)
                    Text("Status: \${project!!.status}", style = MaterialTheme.typography.bodyMedium)
                }
            }

            Text("Modules", style = MaterialTheme.typography.titleLarge)

            ModuleButton("BOQ (Bill of Quantities)") { onNavigateToBoq(sapWorkKey) }
            ModuleButton("Measurement Book (MB)") { onNavigateToMb(sapWorkKey) }
            ModuleButton("Abstract") { onNavigateToAbstract(sapWorkKey) }
            ModuleButton("RA Bill") { onNavigateToRaBill(sapWorkKey) }
            ModuleButton("Quantity Variation") { onNavigateToQuantityVariation(sapWorkKey) }
            ModuleButton("Marathi Dakhale / Certificates") { onNavigateToCertificates(sapWorkKey) }
            ModuleButton("Tax Invoice Generator") { onNavigateToInvoice(sapWorkKey) }
        }
    }
}

@Composable
fun ModuleButton(title: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = MaterialTheme.shapes.medium
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
    }
}
