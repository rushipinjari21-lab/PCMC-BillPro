package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SlateBlue80 = Color(0xFFAEC6FF)
val SlateGrey80 = Color(0xFFC0C7CD)
val Teal80 = Color(0xFF80D6D0)

val SlateBlue40 = Color(0xFF285AB4)
val SlateGrey40 = Color(0xFF585F65)
val Teal40 = Color(0xFF006A65)
