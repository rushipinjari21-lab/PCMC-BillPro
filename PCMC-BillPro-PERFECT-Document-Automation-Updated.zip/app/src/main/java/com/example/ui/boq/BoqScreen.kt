package com.example.ui.boq

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BoqItem
import com.example.viewmodel.BoqViewModel

private val excelMimeTypes = arrayOf(
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoqScreen(
    viewModel: BoqViewModel,
    sapWorkKey: String,
    onNavigateBack: () -> Unit,
    onNavigateToMb: () -> Unit = {}
) {
    val context = LocalContext.current
    val currentBoq by viewModel.currentBoq.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    LaunchedEffect(sapWorkKey) { viewModel.loadBoqForProject(sapWorkKey) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { viewModel.uploadAndParseBoq(context, sapWorkKey, it) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BOQ • $sapWorkKey") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { filePickerLauncher.launch(arrayOf("application/pdf", *excelMimeTypes)) }) {
                        Icon(Icons.Default.UploadFile, contentDescription = "Upload BOQ")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            )
        },
        floatingActionButton = {
            if (currentBoq != null) {
                ExtendedFloatingActionButton(onClick = onNavigateToMb, text = { Text("Measurement Book") }, icon = { Icon(Icons.Default.TableView, contentDescription = null) })
            }
        }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding).fillMaxSize()) {
            when {
                isLoading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                errorMessage != null -> ImportError(
                    message = errorMessage!!,
                    onDismiss = { viewModel.clearError() },
                    onRetry = { filePickerLauncher.launch(arrayOf("application/pdf", *excelMimeTypes)) }
                )
                currentBoq == null -> EmptyBoq(
                    onExcel = { filePickerLauncher.launch(excelMimeTypes) },
                    onPdf = { filePickerLauncher.launch(arrayOf("application/pdf")) }
                )
                else -> BoqContent(viewModel, currentBoq!!.id)
            }
        }
    }
}

@Composable
private fun EmptyBoq(onExcel: () -> Unit, onPdf: () -> Unit) {
    Column(
        Modifier.align(Alignment.Center),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No BOQ uploaded", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("Import the contractor's original Excel or PDF. The app will not replace rows with demo data.")
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onExcel) {
                Icon(Icons.Default.TableView, null)
                Spacer(Modifier.width(8.dp))
                Text("Excel BOQ")
            }
            OutlinedButton(onClick = onPdf) {
                Icon(Icons.Default.PictureAsPdf, null)
                Spacer(Modifier.width(8.dp))
                Text("PDF BOQ")
            }
        }
    }
}

@Composable
private fun ImportError(message: String, onDismiss: () -> Unit, onRetry: () -> Unit) {
    Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("BOQ import failed", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(8.dp))
        Text(message)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDismiss) { Text("Close") }
            Button(onClick = onRetry) { Text("Choose another file") }
        }
    }
}

@Composable
fun BoqContent(viewModel: BoqViewModel, boqId: Long) {
    val parts by viewModel.getParts(boqId).collectAsStateWithLifecycle(initialValue = emptyList())
    var selectedPart by remember { mutableStateOf("Part A") }
    var searchQuery by remember { mutableStateOf("") }
    val totalAmount by viewModel.getTotalAmount(boqId).collectAsStateWithLifecycle(initialValue = 0.0)

    LaunchedEffect(parts) {
        if (selectedPart !in parts && parts.isNotEmpty()) selectedPart = parts.first()
    }

    val visibleItems by if (searchQuery.isBlank()) {
        viewModel.getItemsByPart(boqId, selectedPart).collectAsStateWithLifecycle(initialValue = emptyList())
    } else {
        viewModel.searchItems(boqId, searchQuery).collectAsStateWithLifecycle(initialValue = emptyList())
    }

    Column(Modifier.fillMaxSize()) {
        Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("BOQ • SSR Schedule", fontWeight = FontWeight.Bold)
                    Text(if (searchQuery.isBlank()) selectedPart else "Search results")
                }
                Text("₹ %,.2f".format(totalAmount), fontWeight = FontWeight.Bold)
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Search SSR code, item number or description") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true
        )

        if (searchQuery.isBlank()) {
            ScrollableTabRow(selectedTabIndex = parts.indexOf(selectedPart).coerceAtLeast(0), edgePadding = 8.dp) {
                parts.forEach { part ->
                    Tab(selected = selectedPart == part, onClick = { selectedPart = part }, text = { Text(part) })
                }
            }
        }

        if (visibleItems.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No BOQ items found in $selectedPart")
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(visibleItems, key = { it.id }) { item -> BoqItemCard(item) }
            }
        }
    }
}

@Composable
fun BoqItemCard(item: BoqItem) {
    val horizontal = rememberScrollState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.part} • Item ${item.itemNumber}", fontWeight = FontWeight.Bold)
                Text(item.ssrCode, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(8.dp))
            Text(item.description)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(horizontal), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                ValueCell("Unit", item.unit)
                ValueCell("Quantity", numberText(item.boqQuantity))
                ValueCell("Rate", "₹ ${"%,.2f".format(item.rate)}")
                ValueCell("Amount", "₹ ${"%,.2f".format(item.amount)}")
            }
        }
    }
}

@Composable
private fun RowScope.ValueCell(label: String, value: String) {
    Column(Modifier.widthIn(min = 90.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private fun numberText(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()

