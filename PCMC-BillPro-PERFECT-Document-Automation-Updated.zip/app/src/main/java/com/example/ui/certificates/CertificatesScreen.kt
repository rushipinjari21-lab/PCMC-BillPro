package com.example.ui.certificates

import android.webkit.WebView
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.viewmodel.RaBillViewModel
import com.example.viewmodel.RaBillViewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CertificatesScreen(
    sapWorkKey: String,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getDatabase(context).appDao() }
    val viewModel: RaBillViewModel = viewModel(factory = RaBillViewModelFactory(dao))

    val raBills by viewModel.getRaBills(sapWorkKey).collectAsState(initial = emptyList())
    var expanded by remember { mutableStateOf(false) }
    var selectedBillId by remember { mutableStateOf<Long?>(null) }
    var selectedBillNumber by remember { mutableStateOf("Select RA Bill") }

    var showPreviewDialog by remember { mutableStateOf(false) }
    var previewHtml by remember { mutableStateOf("") }
    var previewTitle by remember { mutableStateOf("") }

    LaunchedEffect(raBills) {
        if (raBills.isNotEmpty() && selectedBillId == null) {
            selectedBillId = raBills.last().id
            selectedBillNumber = raBills.last().billNumber
        }
    }

    val certificates = listOf(
        "२० मुद्द्यांचा गोषवारा दाखला (20-Point Scrutiny Fact Sheet)",
        "उपअभियंता १००% मोजमाप तपासणी दाखला (Deputy Engineer 100% Checking)",
        "कार्यकारी अभियंता २५% मोजमाप तपासणी दाखला (Executive Engineer 25% Test Checking)",
        "पेमेंट शेड्युल दाखला (Payment Schedule)",
        "मूळ जागेवर काम झालेबाबत व स्थळ बदल नसलेबाबत दाखला (Site Verification)",
        "कंत्राटी कामगार कायदा, किमान वेतन, PF व विमा दाखला (Labor Compliance)",
        "जीआयएस मॅपिंग (GIS Mapping) दाखला",
        "कार्यालयीन टिपणी (Official Office Note)"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Marathi Dakhale / Certificates") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        selectedBillId?.let { billId ->
                            viewModel.exportCertificates(context, sapWorkKey, billId, null) { result ->
                                Toast.makeText(context, result ?: "Exported Combined PDF", Toast.LENGTH_SHORT).show()
                            }
                        } ?: run {
                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Print Full Dossier (PDF)")
                    }
                    IconButton(onClick = {
                        selectedBillId?.let { billId ->
                            viewModel.exportDossierDocxPOI(context, sapWorkKey, billId) { result ->
                                Toast.makeText(context, result ?: "Exported Combined Word Doc", Toast.LENGTH_LONG).show()
                            }
                        } ?: run {
                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.Description, contentDescription = "Export Full Dossier (Word)")
                    }
                    IconButton(onClick = {
                        selectedBillId?.let { billId ->
                            viewModel.exportDossierXlsxPOI(context, sapWorkKey, billId) { result ->
                                Toast.makeText(context, result ?: "Exported Combined Excel Doc", Toast.LENGTH_LONG).show()
                            }
                        } ?: run {
                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.Description, contentDescription = "Export Full Dossier (Excel)")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedBillNumber,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select RA Bill for Certificates") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    if (raBills.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No RA Bills found") },
                            onClick = { expanded = false }
                        )
                    } else {
                        raBills.forEach { bill ->
                            DropdownMenuItem(
                                text = { Text(bill.billNumber) },
                                onClick = {
                                    selectedBillId = bill.id
                                    selectedBillNumber = bill.billNumber
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Automatic PCMC Document Package",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "Project, BOQ, MB, RA Bill and Quantity Variation data are reused automatically in every document.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            FilledTonalButton(
                onClick = {
                    selectedBillId?.let { billId ->
                        viewModel.exportCertificates(context, sapWorkKey, billId, null) { result ->
                            Toast.makeText(context, result ?: "Generated complete PCMC document package", Toast.LENGTH_LONG).show()
                        }
                    } ?: Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate All 8 PCMC Documents")
            }

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(certificates.size) { index ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "${index + 1}. ${certificates[index]}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                // Preview Button
                                FilledTonalButton(
                                    onClick = {
                                        selectedBillId?.let { billId ->
                                            viewModel.getCertificatesHtml(sapWorkKey, billId, index) { html ->
                                                if (html != null) {
                                                    previewHtml = html
                                                    previewTitle = certificates[index]
                                                    showPreviewDialog = true
                                                } else {
                                                    Toast.makeText(context, "Failed to load preview", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        } ?: run {
                                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Icon(Icons.Default.Visibility, contentDescription = "Preview", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Preview")
                                }
                                
                                // Export Word Button
                                OutlinedButton(
                                    onClick = {
                                        selectedBillId?.let { billId ->
                                            viewModel.exportCertificatesWord(context, sapWorkKey, billId, index) { result ->
                                                Toast.makeText(context, result ?: "Exported Word Doc", Toast.LENGTH_LONG).show()
                                            }
                                        } ?: run {
                                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.padding(end = 8.dp)
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = "Export Word", modifier = Modifier.size(18.dp))
                                }

                                // Print PDF Button
                                Button(
                                    onClick = {
                                        selectedBillId?.let { billId ->
                                            viewModel.exportCertificates(context, sapWorkKey, billId, index) { result ->
                                                Toast.makeText(context, result ?: "Exported PDF", Toast.LENGTH_SHORT).show()
                                            }
                                        } ?: run {
                                            Toast.makeText(context, "Please select an RA Bill first", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = "Print PDF", modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("PDF")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPreviewDialog) {
        Dialog(
            onDismissRequest = { showPreviewDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = previewTitle.split("(")[0].trim(),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { showPreviewDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close Preview")
                        }
                    }
                    Divider()
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = false
                                loadDataWithBaseURL(null, previewHtml, "text/HTML", "UTF-8", null)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                }
            }
        }
    }
}
