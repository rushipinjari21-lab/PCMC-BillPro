package com.example.ui.mb

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BoqItem
import com.example.data.Measurement
import com.example.viewmodel.MeasurementViewModel

import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeasurementScreen(
    viewModel: MeasurementViewModel,
    sapWorkKey: String,
    mbId: Long,
    onNavigateBack: () -> Unit,
    onNavigateToRaBill: () -> Unit
) {
    val context = LocalContext.current
    val error by viewModel.error.collectAsStateWithLifecycle()
    val measurements by viewModel.getMeasurements(mbId).collectAsStateWithLifecycle(initialValue = emptyList())
    val boqItems by viewModel.getBoqItems(sapWorkKey).collectAsStateWithLifecycle(initialValue = emptyList())

    var selectedBoqItem by remember { mutableStateOf<BoqItem?>(null) }
    val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
    var dateStr by remember { mutableStateOf(sdf.format(java.util.Date())) }
    var location by remember { mutableStateOf("") }
    var remark by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("1") }
    var length by remember { mutableStateOf("1") }
    var breadth by remember { mutableStateOf("1") }
    var height by remember { mutableStateOf("1") }

    var expandedDropdown by remember { mutableStateOf(false) }
    var showCalculatorsDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MB Entries") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showCalculatorsDialog = true }) {
                        Icon(Icons.Default.Calculate, contentDescription = "Smart Calculators")
                    }
                    IconButton(onClick = {
                        viewModel.exportMB(context, sapWorkKey, mbId) { result ->
                            Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export MB")
                    }
                    IconButton(onClick = {
                        viewModel.exportMBExcel(context, sapWorkKey, mbId) { result ->
                            Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                        }
                    }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export MB Excel")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToRaBill,
                icon = { Icon(androidx.compose.material.icons.Icons.Default.Check, contentDescription = "Generate RA Bill") },
                text = { Text("Generate RA Bill") }
            )
        }
    ) { innerPadding ->
        val scrollState = rememberScrollState()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (error != null) {
                Text(text = error!!, color = MaterialTheme.colorScheme.error)
                LaunchedEffect(error) {
                    kotlinx.coroutines.delay(3000)
                    viewModel.clearError()
                }
            }

            // BOQ Item Selection
            ExposedDropdownMenuBox(
                expanded = expandedDropdown,
                onExpandedChange = { expandedDropdown = !expandedDropdown },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedBoqItem?.ssrCode ?: "Select SSR Code",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("SSR Code") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false }
                ) {
                    boqItems.forEach { item ->
                        DropdownMenuItem(
                            text = { Text("${item.ssrCode} - ${item.description.take(30)}...") },
                            onClick = {
                                selectedBoqItem = item
                                expandedDropdown = false
                            }
                        )
                    }
                }
            }

            // BOQ Info Display
            selectedBoqItem?.let { item ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(8.dp).fillMaxWidth()) {
                        Text("${item.part} • ${item.ssrCode} • Item ${item.itemNumber}", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.description, style = MaterialTheme.typography.bodyMedium)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Unit: ${item.unit}", style = MaterialTheme.typography.labelMedium)
                            Text("BOQ Qty: ${item.boqQuantity}", style = MaterialTheme.typography.labelMedium)
                            Text("Rate: ₹${item.rate}", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            // Measurement Form
            OutlinedTextField(
                value = dateStr,
                onValueChange = { dateStr = it },
                label = { Text("Date *") },
                supportingText = { Text("Mandatory for every measurement") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Location *") },
                supportingText = { Text("Mandatory: landmark / road / site location") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = remark,
                onValueChange = { remark = it },
                label = { Text("Remark *") },
                supportingText = { Text("Mandatory: what was measured / verification note") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DimensionField(value = number, label = "No.", onValueChange = { number = it }, modifier = Modifier.weight(1f))
                DimensionField(value = length, label = "L", onValueChange = { length = it }, modifier = Modifier.weight(1f))
                DimensionField(value = breadth, label = "B", onValueChange = { breadth = it }, modifier = Modifier.weight(1f))
                DimensionField(value = height, label = "D/H", onValueChange = { height = it }, modifier = Modifier.weight(1f))
            }

            Button(
                onClick = {
                    selectedBoqItem?.let { item ->
                        viewModel.saveMeasurement(
                            mbId = mbId,
                            boqItem = item,
                            date = dateStr,
                            location = location,
                            remark = remark,
                            number = number.toDoubleOrNull() ?: 1.0,
                            length = length.toDoubleOrNull() ?: 1.0,
                            breadth = breadth.toDoubleOrNull() ?: 1.0,
                            height = height.toDoubleOrNull() ?: 1.0
                        )
                        // Reset simple fields (kept date, location, remark to avoid retyping)
                        number = "1"
                        length = "1"
                        breadth = "1"
                        height = "1"
                    } ?: run {
                        // Error handling via ViewModel would be better, but simple check:
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = selectedBoqItem != null
            ) {
                Text("Add Measurement Row")
            }

            HorizontalDivider()

            Text("Measurements in this MB", style = MaterialTheme.typography.titleMedium)

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                measurements.forEach { m ->
                    MeasurementRowCard(m)
                }
            }
        }
        
        if (showCalculatorsDialog) {
            SmartCalculatorsDialog(
                onDismiss = { showCalculatorsDialog = false },
                onApplyDimensions = { n, l, b, h ->
                    number = n
                    length = l
                    breadth = b
                    height = h
                    showCalculatorsDialog = false
                }
            )
        }
    }
}

@Composable
fun SmartCalculatorsDialog(
    onDismiss: () -> Unit,
    onApplyDimensions: (String, String, String, String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    
    // Circular Geometry State
    var innerDia by remember { mutableStateOf("") }
    var thickness by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var foundationDepth by remember { mutableStateOf("") }
    var pccDepth by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var calcResult by remember { mutableStateOf("") }
    
    // Transform State
    var sourceL by remember { mutableStateOf("") }
    var sourceB by remember { mutableStateOf("") }
    var sourceH by remember { mutableStateOf("") }
    var sourceN by remember { mutableStateOf("1") }
    var transformType by remember { mutableStateOf("Plaster/Paint") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Smart Calculators") },
        text = {
            Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Circular Geo") })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Transform") })
                }
                Spacer(modifier = Modifier.height(16.dp))
                
                if (selectedTab == 0) {
                    Text("Tree Katta / Manhole Calculator", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    DimensionField(value = innerDia, label = "Inner Dia (Din)", onValueChange = { innerDia = it })
                    DimensionField(value = thickness, label = "Wall Thick (t)", onValueChange = { thickness = it })
                    DimensionField(value = height, label = "Height (H)", onValueChange = { height = it })
                    DimensionField(value = foundationDepth, label = "Found. Depth (df)", onValueChange = { foundationDepth = it })
                    DimensionField(value = pccDepth, label = "PCC Depth (dpcc)", onValueChange = { pccDepth = it })
                    DimensionField(value = qty, label = "Nos", onValueChange = { qty = it })
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        val din = innerDia.toDoubleOrNull() ?: 0.0
                        val t = thickness.toDoubleOrNull() ?: 0.0
                        val h = height.toDoubleOrNull() ?: 0.0
                        val df = foundationDepth.toDoubleOrNull() ?: 0.0
                        val dpcc = pccDepth.toDoubleOrNull() ?: 0.0
                        val n = qty.toDoubleOrNull() ?: 1.0
                        
                        val dMean = din + t
                        val dOuter = din + (2 * t)
                        val lMean = 3.1416 * dMean
                        val lOut = 3.1416 * dOuter
                        val lIn = 3.1416 * din
                        val bTrench = t + 0.15
                        val bCoping = t + 0.05
                        
                        calcResult = """
                            Dmean = \${String.format("%.3f", dMean)}, Lmean = \${String.format("%.3f", lMean)}
                            1. Exc: Nos=\$n, L=\${String.format("%.3f", lMean)}, B=\${String.format("%.3f", bTrench)}, H=\$df
                            2. PCC: Nos=\$n, L=\${String.format("%.3f", lMean)}, B=\${String.format("%.3f", bTrench)}, H=\$dpcc
                            3. Brick: Nos=\$n, L=\${String.format("%.3f", lMean)}, B=\$t, H=\$h
                            4. Out Plstr: Nos=\$n, L=\${String.format("%.3f", lOut)}, B=0, H=\$h
                            5. In Plstr: Nos=\$n, L=\${String.format("%.3f", lIn)}, B=0, H=\$h
                            6. Coping: Nos=\$n, L=\${String.format("%.3f", lMean)}, B=\${String.format("%.3f", bCoping)}, H=0
                        """.trimIndent()
                    }) {
                        Text("Calculate Standard Entries")
                    }
                    if (calcResult.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(calcResult, style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Text("Clone & Transform Logic", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    DimensionField(value = sourceN, label = "Source Nos", onValueChange = { sourceN = it })
                    DimensionField(value = sourceL, label = "Source L", onValueChange = { sourceL = it })
                    DimensionField(value = sourceB, label = "Source B", onValueChange = { sourceB = it })
                    DimensionField(value = sourceH, label = "Source H/D", onValueChange = { sourceH = it })
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Target Transformation:")
                    listOf("Plaster/Paint", "Wall Area", "Flooring/PCC").forEach { type ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = transformType == type, onClick = { transformType = type })
                            Text(type, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (selectedTab == 1) {
                Button(onClick = {
                    val n = sourceN.toDoubleOrNull() ?: 1.0
                    val l = sourceL.toDoubleOrNull() ?: 1.0
                    val b = sourceB.toDoubleOrNull() ?: 1.0
                    val h = sourceH.toDoubleOrNull() ?: 1.0
                    
                    when (transformType) {
                        "Plaster/Paint" -> onApplyDimensions((n * 2).toString(), l.toString(), "0", h.toString())
                        "Wall Area" -> onApplyDimensions(n.toString(), l.toString(), "0", h.toString())
                        "Flooring/PCC" -> onApplyDimensions(n.toString(), l.toString(), b.toString(), "0.10") // override 0.10m
                    }
                }) {
                    Text("Apply Transformation")
                }
            } else {
                Button(onClick = onDismiss) {
                    Text("Close")
                }
            }
        },
        dismissButton = {
            if (selectedTab == 1) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

@Composable
fun DimensionField(value: String, label: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
fun MeasurementRowCard(measurement: Measurement) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text("Date: ${measurement.date} | Loc: ${measurement.location} | Rem: ${measurement.remark}", style = MaterialTheme.typography.bodySmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dims: ${measurement.number} x ${measurement.length} x ${measurement.breadth} x ${measurement.height}", style = MaterialTheme.typography.bodySmall)
                Text("Qty: ${String.format("%.3f", measurement.quantity)}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
