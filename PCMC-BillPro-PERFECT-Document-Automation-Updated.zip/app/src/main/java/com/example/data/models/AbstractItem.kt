package com.example.data.models

import com.example.data.BoqItem

data class AbstractItem(
    val boqItem: BoqItem,
    val previousQuantity: Double,
    val currentQuantity: Double,
    val totalQuantity: Double,
    val balanceQuantity: Double,
    val amount: Double
)
