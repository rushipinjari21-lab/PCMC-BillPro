package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Projects
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project)

    @Update
    suspend fun updateProject(project: Project)

    @Query("SELECT * FROM projects")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE sapWorkKey = :sapWorkKey")
    suspend fun getProjectByWorkKey(sapWorkKey: String): Project?

    @Query("DELETE FROM projects WHERE sapWorkKey = :sapWorkKey")
    suspend fun deleteProject(sapWorkKey: String)

    // BOQs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoq(boq: Boq): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoqItems(items: List<BoqItem>)

    @Query("SELECT * FROM boqs WHERE sapWorkKey = :sapWorkKey")
    suspend fun getBoqByWorkKey(sapWorkKey: String): Boq?

    @Query("SELECT * FROM boq_items WHERE boqId = :boqId")
    fun getBoqItems(boqId: Long): Flow<List<BoqItem>>

    @Query("DELETE FROM boqs WHERE sapWorkKey = :sapWorkKey")
    suspend fun deleteBoqByWorkKey(sapWorkKey: String)

    // Measurement Books
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurementBook(mb: MeasurementBook): Long

    @Query("SELECT * FROM measurement_books WHERE sapWorkKey = :sapWorkKey")
    fun getMeasurementBooksByWorkKey(sapWorkKey: String): Flow<List<MeasurementBook>>
    
    @Query("SELECT * FROM measurement_books WHERE sapWorkKey = :sapWorkKey AND mbNumber = :mbNumber")
    suspend fun getMeasurementBookByNumber(sapWorkKey: String, mbNumber: String): MeasurementBook?

    @Query("SELECT * FROM measurement_books WHERE id = :id")
    suspend fun getMeasurementBookById(id: Long): MeasurementBook?

    // Measurements
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: Measurement)

    @Query("SELECT * FROM measurements WHERE mbId = :mbId")
    fun getMeasurementsByMbId(mbId: Long): Flow<List<Measurement>>
    
    @Query("SELECT * FROM measurements WHERE boqItemId = :boqItemId")
    suspend fun getMeasurementsByBoqItemId(boqItemId: Long): List<Measurement>

    // RA Bills
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRaBill(bill: RaBill): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRaBillItems(items: List<RaBillItem>)

    @Query("SELECT * FROM ra_bills WHERE sapWorkKey = :sapWorkKey")
    fun getRaBillsByWorkKey(sapWorkKey: String): Flow<List<RaBill>>

    @Query("SELECT * FROM ra_bills WHERE id = :billId")
    suspend fun getRaBillById(billId: Long): RaBill?
    @Query("SELECT * FROM ra_bills WHERE sapWorkKey = :sapWorkKey ORDER BY date DESC, id DESC LIMIT 1")
    suspend fun getLatestRaBill(sapWorkKey: String): RaBill?

    // Quantity Variations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuantityVariation(variation: QuantityVariation): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuantityVariationItems(items: List<QuantityVariationItem>)

    @Query("SELECT * FROM quantity_variations WHERE sapWorkKey = :sapWorkKey")
    fun getQuantityVariationsByWorkKey(sapWorkKey: String): Flow<List<QuantityVariation>>

    @Query("SELECT * FROM quantity_variations WHERE id = :variationId")
    suspend fun getQuantityVariationById(variationId: Long): QuantityVariation?

    @Query("SELECT * FROM ra_bill_items WHERE billId = :billId")
    fun getRaBillItems(billId: Long): Flow<List<RaBillItem>>

    @Query("SELECT * FROM quantity_variation_items WHERE variationId = :variationId")
    fun getQuantityVariationItems(variationId: Long): Flow<List<QuantityVariationItem>>

    @Query("UPDATE quantity_variations SET status = :status, approvedDate = :date, approverName = :approver WHERE id = :id")
    suspend fun updateQuantityVariationStatus(id: Long, status: String, date: Long?, approver: String?)
}
