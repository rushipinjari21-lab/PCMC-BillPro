package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index
import java.util.Date

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey
    val sapWorkKey: String,
    val workName: String,
    val workOrderNumber: String,
    val tenderNumber: String,
    val contractorName: String,
    val contractorAddress: String,
    val department: String,
    val division: String,
    val subDivision: String,
    val estimateNumber: String,
    val estimateAmount: Double,
    val agreementAmount: Double,
    val budgetHead: String,
    val ssrYear: String,
    val startDate: Long,
    val completionDate: Long,
    val engineerName: String,
    val contractorEngineer: String,
    val status: String,
    val remarks: String,
    // PCMC document metadata. Optional in storage, populated once and reused by every document.
    val wardName: String = "",
    val regionalOffice: String = "",
    val adminApprovalNumber: String = "",
    val technicalSanctionNumber: String = "",
    val technicalSanctionAmount: Double = 0.0,
    val tenderRateType: String = "AT PAR",
    val tenderRatePercent: Double = 0.0,
    val advertisementDate: String = "",
    val tenderAcceptanceDate: String = "",
    val workOrderDate: String = "",
    val workDurationMonths: Int = 12,
    val panNumber: String = "",
    val gstNumber: String = "",
    val deputyEngineerName: String = "",
    val executiveEngineerName: String = ""
)

@Entity(
    tableName = "boqs",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["sapWorkKey"],
            childColumns = ["sapWorkKey"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["sapWorkKey"], unique = true)]
)
data class Boq(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sapWorkKey: String,
    val uploadedAt: Long
)

@Entity(
    tableName = "boq_items",
    foreignKeys = [
        ForeignKey(
            entity = Boq::class,
            parentColumns = ["id"],
            childColumns = ["boqId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["boqId"])]
)
data class BoqItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val boqId: Long,
    val part: String, // Part A, Part B, etc.
    val itemNumber: String,
    val ssrCode: String,
    val description: String,
    val unit: String,
    val boqQuantity: Double,
    val rate: Double,
    val amount: Double,
    val specification: String,
    val remarks: String
)

@Entity(
    tableName = "measurement_books",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["sapWorkKey"],
            childColumns = ["sapWorkKey"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sapWorkKey"]),
        Index(value = ["sapWorkKey", "mbNumber"], unique = true)
    ]
)
data class MeasurementBook(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sapWorkKey: String,
    val mbNumber: String,
    val date: Long
)

@Entity(
    tableName = "measurements",
    foreignKeys = [
        ForeignKey(
            entity = MeasurementBook::class,
            parentColumns = ["id"],
            childColumns = ["mbId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = BoqItem::class,
            parentColumns = ["id"],
            childColumns = ["boqItemId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["mbId"]), Index(value = ["boqItemId"])]
)
data class Measurement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mbId: Long,
    val boqItemId: Long,
    val date: String = "",
    val location: String,
    val remark: String,
    val number: Double,
    val length: Double,
    val breadth: Double,
    val height: Double,
    val quantity: Double
)

@Entity(
    tableName = "ra_bills",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["sapWorkKey"],
            childColumns = ["sapWorkKey"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sapWorkKey"]),
        Index(value = ["sapWorkKey", "billNumber"], unique = true)
    ]
)
data class RaBill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sapWorkKey: String,
    val billNumber: String, // RA-01, RA-02
    val date: Long,
    val grossAmount: Double,
    val gstAmount: Double,
    val labourCess: Double,
    val securityDeposit: Double,
    val otherRecoveries: Double,
    val netPayable: Double,
    // PCMC tender-rate and payment controls captured from the official RA bill format.
    val tenderRateType: String = "AT PAR", // BELOW, ABOVE, AT PAR
    val tenderRatePercent: Double = 0.0,
    val tenderAdjustmentAmount: Double = 0.0,
    val testingCharges: Double = 0.0,
    val royalty: Double = 0.0,
    val cgstPercent: Double = 9.0,
    val sgstPercent: Double = 9.0,
    val cgstAmount: Double = 0.0,
    val sgstAmount: Double = 0.0,
    val tds194c: Double = 0.0,
    val tdsCgst: Double = 0.0,
    val tdsSgst: Double = 0.0,
    val labourWelfareCess: Double = 0.0,
    val roundingOff: Double = 0.0,
    val passedForPayment: Double = 0.0,
    val chequeAmount: Double = 0.0
)

@Entity(
    tableName = "ra_bill_items",
    foreignKeys = [
        ForeignKey(
            entity = RaBill::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = BoqItem::class,
            parentColumns = ["id"],
            childColumns = ["boqItemId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["billId"]), Index(value = ["boqItemId"])]
)
data class RaBillItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val boqItemId: Long,
    val previousQuantity: Double,
    val currentQuantity: Double,
    val totalQuantity: Double,
    val rate: Double,
    val amount: Double
)

@Entity(
    tableName = "quantity_variations",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["sapWorkKey"],
            childColumns = ["sapWorkKey"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["sapWorkKey"])]
)
data class QuantityVariation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sapWorkKey: String,
    val status: String, // Draft, Submitted, Approved, Rejected
    val createdDate: Long,
    val approvedDate: Long?,
    val approverName: String?
)

@Entity(
    tableName = "quantity_variation_items",
    foreignKeys = [
        ForeignKey(
            entity = QuantityVariation::class,
            parentColumns = ["id"],
            childColumns = ["variationId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = BoqItem::class,
            parentColumns = ["id"],
            childColumns = ["boqItemId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["variationId"]), Index(value = ["boqItemId"])]
)
data class QuantityVariationItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val variationId: Long,
    val boqItemId: Long,
    val originalBoqQuantity: Double,
    val finalExecutedQuantity: Double,
    val variationQuantity: Double,
    val variationPercentage: Double,
    val variationAmount: Double,
    val variationType: String, // Increase, Decrease, No Variation
    val reason: String,
    val engineerRemark: String
)
