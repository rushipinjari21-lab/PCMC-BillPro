package com.example.services

import com.example.data.AppDao
import com.example.data.Boq
import com.example.data.BoqItem
import com.example.utils.BoqFileParser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BoqStorage(private val dao: AppDao) {
    suspend fun saveBOQ(sapWorkKey: String, items: List<BoqItem>) {
        val existing = dao.getBoqByWorkKey(sapWorkKey)
        if (existing != null) dao.deleteBoqByWorkKey(sapWorkKey)

        val boq = Boq(sapWorkKey = sapWorkKey, uploadedAt = System.currentTimeMillis())
        val boqId = dao.insertBoq(boq)
        val ordered = BoqFileParser.sortForPcMc(items)
        dao.insertBoqItems(ordered.map { it.copy(boqId = boqId) })
    }

    suspend fun getBOQ(sapWorkKey: String): Boq? = dao.getBoqByWorkKey(sapWorkKey)

    suspend fun deleteBOQ(sapWorkKey: String) = dao.deleteBoqByWorkKey(sapWorkKey)

    suspend fun replaceBOQ(sapWorkKey: String, items: List<BoqItem>) = saveBOQ(sapWorkKey, items)

    fun getItemsForBoq(boqId: Long): Flow<List<BoqItem>> = dao.getBoqItems(boqId).map(BoqFileParser::sortForPcMc)

    fun getParts(boqId: Long): Flow<List<String>> = dao.getBoqItems(boqId).map { items ->
        val available = items.map { it.part }.distinct()
        listOf("Part A", "Part B", "Part C", "Part D").filter { available.contains(it) } +
            available.filterNot { it in setOf("Part A", "Part B", "Part C", "Part D") }.sorted()
    }

    fun getItemsByPart(boqId: Long, part: String): Flow<List<BoqItem>> = dao.getBoqItems(boqId).map { items ->
        BoqFileParser.sortForPcMc(items.filter { it.part.equals(part, ignoreCase = true) })
    }

    fun getSSRList(boqId: Long): Flow<List<String>> = dao.getBoqItems(boqId).map { items ->
        BoqFileParser.sortForPcMc(items).map { it.ssrCode }.distinct()
    }

    fun searchItems(boqId: Long, query: String): Flow<List<BoqItem>> {
        val lowerQuery = query.trim().lowercase()
        return dao.getBoqItems(boqId).map { items ->
            BoqFileParser.sortForPcMc(if (lowerQuery.isBlank()) items else items.filter {
                it.ssrCode.lowercase().contains(lowerQuery) ||
                    it.description.lowercase().contains(lowerQuery) ||
                    it.itemNumber.lowercase().contains(lowerQuery) ||
                    it.part.lowercase().contains(lowerQuery)
            })
        }
    }

    fun getTotalQty(boqId: Long): Flow<Double> = dao.getBoqItems(boqId).map { items -> items.sumOf { it.boqQuantity } }
    fun getTotalAmount(boqId: Long): Flow<Double> = dao.getBoqItems(boqId).map { items -> items.sumOf { it.amount } }
}
