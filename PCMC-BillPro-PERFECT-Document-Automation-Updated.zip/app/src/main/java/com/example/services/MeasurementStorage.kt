package com.example.services

import com.example.data.AppDao
import com.example.data.BoqItem
import com.example.data.Measurement
import com.example.data.MeasurementBook
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MeasurementStorage(private val dao: AppDao) {

    suspend fun createOrGetMeasurementBook(sapWorkKey: String, mbNumber: String): Long {
        val existingMb = dao.getMeasurementBookByNumber(sapWorkKey, mbNumber)
        if (existingMb != null) {
            return existingMb.id
        }
        val newMb = MeasurementBook(
            sapWorkKey = sapWorkKey,
            mbNumber = mbNumber,
            date = System.currentTimeMillis()
        )
        return dao.insertMeasurementBook(newMb)
    }

    fun getMeasurementBooks(sapWorkKey: String): Flow<List<MeasurementBook>> {
        return dao.getMeasurementBooksByWorkKey(sapWorkKey)
    }

    suspend fun addMeasurement(measurement: Measurement) {
        dao.insertMeasurement(measurement)
    }

    fun getMeasurements(mbId: Long): Flow<List<Measurement>> {
        return dao.getMeasurementsByMbId(mbId)
    }

    suspend fun getTotalExecutedQuantity(boqItemId: Long): Double {
        val measurements = dao.getMeasurementsByBoqItemId(boqItemId)
        return measurements.sumOf { it.quantity }
    }
}
