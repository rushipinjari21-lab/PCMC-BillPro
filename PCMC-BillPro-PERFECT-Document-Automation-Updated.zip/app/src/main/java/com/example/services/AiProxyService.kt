package com.example.services

import com.google.firebase.Firebase
import com.google.firebase.vertexai.vertexAI
import com.google.firebase.vertexai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Secure AI Service that uses Firebase Vertex AI.
 * 
 * Architecture Security:
 * 1. NO API keys on the client side (no BuildConfig, no strings.xml).
 * 2. Requests route through Firebase infrastructure (Firebase AI).
 * 3. Protected by Firebase App Check and Google Play Integrity API 
 *    (Initialized in MyApplication).
 */
class AiProxyService {
    
    // Initialize the Vertex AI model provided by Firebase.
    // The API key is securely managed in your Firebase project console,
    // NOT on the client device.
    private val generativeModel = Firebase.vertexAI.generativeModel(
        modelName = "gemini-1.5-flash"
    )

    suspend fun generateMeasurementInsights(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val response = generativeModel.generateContent(
                content {
                    text(prompt)
                }
            )
            response.text ?: "No insights generated."
        } catch (e: Exception) {
            "Error securely generating insights: ${e.message}"
        }
    }
}
