package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.Project
import com.example.data.RaBill
import org.apache.poi.xwpf.usermodel.ParagraphAlignment
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.xwpf.usermodel.BreakType
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/** PCMC automatic dossier exports.  Content is generated from the same master project/bill fields used by the PDF renderer. */
class DocumentExportService {
    companion object {
        fun exportDossierToDocx(context: Context, project: Project, raBill: RaBill): String? = try {
            val doc = XWPFDocument()
            val html = PdfDocketGenerator.getCertificatesHtml(project, raBill, null)
            // Keep Word output editable while retaining the eight-document page sequence.
            val docs = extractPageBodies(html)
            docs.forEachIndexed { index, body ->
                if (index > 0) doc.createParagraph().createRun().addBreak(BreakType.PAGE)
                val title = doc.createParagraph().apply { alignment = ParagraphAlignment.CENTER }
                val run = title.createRun(); run.isBold = true; run.fontSize = 14; run.fontFamily = "Noto Sans Devanagari"; run.setText(documentTitles[index])
                val plain = htmlToPlainText(body)
                plain.lines().filter { it.isNotBlank() }.forEach { line ->
                    val p = doc.createParagraph(); p.alignment = ParagraphAlignment.LEFT
                    val r = p.createRun(); r.fontFamily = "Noto Sans Devanagari"; r.fontSize = 11; r.setText(line.trim())
                }
            }
            val name = "PCMC_${sanitize(raBill.billNumber)}_Document_Package.docx"
            saveFileToDownloads(context, name, "application/vnd.openxmlformats-officedocument.wordprocessingml.document") { doc.write(it) }
            doc.close(); "DOCX exported to Downloads: $name"
        } catch (e: Exception) { "Error exporting DOCX: ${e.message}" }

        fun exportDossierToXlsx(context: Context, project: Project, raBill: RaBill): String? = try {
            val workbook = XSSFWorkbook()
            val sheet = workbook.createSheet("Document Package")
            val titleStyle = workbook.createCellStyle().apply { font = workbook.createFont().apply { bold = true } }
            val values = linkedMapOf(
                "Contractor" to project.contractorName,
                "Work Name" to project.workName,
                "Tender No." to project.tenderNumber,
                "Tender Amount" to project.agreementAmount,
                "Admin Approval Amount" to project.estimateAmount,
                "Technical Sanction Amount" to if (project.technicalSanctionAmount == 0.0) project.estimateAmount else project.technicalSanctionAmount,
                "Tender Rate" to "${raBill.tenderRateType} ${raBill.tenderRatePercent}%",
                "RA Bill" to raBill.billNumber,
                "RA Bill Gross" to raBill.grossAmount,
                "GST" to raBill.gstAmount,
                "Deductions" to (raBill.securityDeposit + raBill.tds194c + raBill.tdsCgst + raBill.tdsSgst + raBill.labourWelfareCess + raBill.labourCess + raBill.otherRecoveries),
                "Net Payable" to raBill.netPayable
            )
            var r = sheet.createRow(0); r.createCell(0).setCellValue("PCMC BILLPRO - AUTOMATIC DOCUMENT PACKAGE"); r.getCell(0).cellStyle = titleStyle
            values.entries.forEachIndexed { i, e -> r = sheet.createRow(i + 2); r.createCell(0).setCellValue(e.key); r.createCell(1).setCellValue(e.value.toString()) }
            documentTitles.forEachIndexed { i, title -> r = sheet.createRow(i + 16); r.createCell(0).setCellValue("${i + 1}. $title"); r.createCell(1).setCellValue("Generated automatically from Project + RA Bill") }
            sheet.setColumnWidth(0, 9000); sheet.setColumnWidth(1, 22000)
            val name = "PCMC_${sanitize(raBill.billNumber)}_Document_Package.xlsx"
            saveFileToDownloads(context, name, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") { workbook.write(it) }
            workbook.close(); "XLSX exported to Downloads: $name"
        } catch (e: Exception) { "Error exporting XLSX: ${e.message}" }

        private val documentTitles = listOf(
            "पहिले आर. ए. बिल",
            "दाखला - उप अभियंता १००% मोजमाप तपासणी",
            "दाखला - कार्यकारी अभियंता २५% मोजमाप तपासणी",
            "Payment Schedule",
            "दाखला - Site Verification",
            "दाखला - Labor Compliance",
            "GIS Mapping दाखला",
            "कार्यालयीन टिपणी"
        )

        private fun extractPageBodies(html: String): List<String> = Regex("<div class='page-break'>(.*?)</div>(?=<div class='page-break'>|</body>)", setOf(RegexOption.DOT_MATCHES_ALL)).findAll(html).map { it.groupValues[1] }.toList()

        private fun htmlToPlainText(html: String): String = html
            .replace(Regex("<br\\s*/?>"), "\\n")
            .replace(Regex("</p>"), "\\n")
            .replace(Regex("</tr>"), "\\n")
            .replace(Regex("</td>"), "  ")
            .replace(Regex("<[^>]+>"), "")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")

        private fun sanitize(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]+"), "_")

        private fun saveFileToDownloads(context: Context, fileName: String, mimeType: String, writer: (OutputStream) -> Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Failed to create MediaStore entry")
                context.contentResolver.openOutputStream(uri)?.use(writer) ?: error("Failed to open output stream")
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(dir, fileName)
                FileOutputStream(file).use(writer)
            }
        }
    }
}
