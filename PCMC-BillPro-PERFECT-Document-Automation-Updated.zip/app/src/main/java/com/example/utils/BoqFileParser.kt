package com.example.utils

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.BoqItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.WorkbookFactory
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.text.PDFTextStripper
import java.util.Locale

/**
 * Imports BOQ data from Excel (.xls/.xlsx) and text-based PDF files.
 * The importer intentionally does not manufacture fallback/demo rows: uploaded data
 * must be preserved exactly as supplied, then grouped/sorted only for display.
 */
object BoqFileParser {
    private val partRegex = Regex("\\bpart\\s*[-:]?\\s*([A-D])\\b", RegexOption.IGNORE_CASE)
    private val itemRegex = Regex("^\\s*(\\d+[A-Za-z]?(?:[.\\-]\\d+)*)\\s+(.*)$")
    private val numberRegex = Regex("[-+]?\\d+(?:,\\d{3})*(?:\\.\\d+)?")

    suspend fun parse(context: Context, uri: Uri, displayName: String = ""): List<BoqItem> =
        withContext(Dispatchers.IO) {
            val name = displayName.ifBlank { uri.toString() }.lowercase(Locale.ROOT)
            val isPdf = name.endsWith(".pdf") || name.contains("application/pdf")
            if (isPdf) parsePdf(context, uri) else parseExcel(context, uri)
        }

    private fun parseExcel(context: Context, uri: Uri): List<BoqItem> {
        val formatter = DataFormatter()
        context.contentResolver.openInputStream(uri)?.use { input ->
            WorkbookFactory.create(input).use { workbook ->
                val output = mutableListOf<BoqItem>()
                for (sheet in workbook) {
                    output += parseSheet(sheet, formatter)
                }
                return sortForPcMc(output)
            }
        } ?: error("Unable to open the selected Excel file.")
    }

    private fun parseSheet(sheet: org.apache.poi.ss.usermodel.Sheet, formatter: DataFormatter): List<BoqItem> {
        val rows = sheet.iterator().asSequence().toList()
        if (rows.isEmpty()) return emptyList()

        val headerRowIndex = rows.indexOfFirst { row ->
            val text = row.joinToString(" | ") { formatter.formatCellValue(it).trim().lowercase(Locale.ROOT) }
            (text.contains("ssr") || text.contains("schedule") || text.contains("item")) &&
                (text.contains("description") || text.contains("particular") || text.contains("work"))
        }
        val header = if (headerRowIndex >= 0) rows[headerRowIndex] else null
        val headerMap = header?.let { mapHeaders(it, formatter) }

        var currentPart = "Part A"
        val output = mutableListOf<BoqItem>()
        val start = if (headerRowIndex >= 0) headerRowIndex + 1 else 0

        for (i in start until rows.size) {
            val row = rows[i]
            val values = row.map { formatter.formatCellValue(it).trim() }
            val rowText = values.joinToString(" ").trim()
            if (rowText.isBlank()) continue

            val detectedPart = detectPart(rowText)
            if (detectedPart != null) {
                currentPart = detectedPart
                continue
            }

            val itemNo = headerMap?.item?.let { values.getOrNull(it) }?.takeIf { it.isNotBlank() }
                ?: values.getOrNull(1).orEmpty()
            val ssr = headerMap?.ssr?.let { values.getOrNull(it) }?.takeIf { it.isNotBlank() }
                ?: values.getOrNull(2).orEmpty()
            val description = headerMap?.description?.let { values.getOrNull(it) }?.takeIf { it.isNotBlank() }
                ?: values.getOrNull(3).orEmpty()
            val unit = headerMap?.unit?.let { values.getOrNull(it) }?.takeIf { it.isNotBlank() }
                ?: values.getOrNull(4).orEmpty()
            val qtyText = headerMap?.quantity?.let { values.getOrNull(it) }.orEmpty()
                .ifBlank { values.getOrNull(5).orEmpty() }
            val rateText = headerMap?.rate?.let { values.getOrNull(it) }.orEmpty()
                .ifBlank { values.getOrNull(6).orEmpty() }
            val amountText = headerMap?.amount?.let { values.getOrNull(it) }.orEmpty()

            val normalizedItem = itemNo.trim()
            val normalizedSsr = ssr.trim()
            val qty = parseNumber(qtyText)
            val rate = parseNumber(rateText)
            val amount = parseNumber(amountText) ?: qty?.times(rate ?: 0.0)

            if (isLikelyItem(normalizedItem, normalizedSsr, description) && qty != null && rate != null) {
                output += BoqItem(
                    boqId = 0,
                    part = normalizePart(currentPart),
                    itemNumber = normalizedItem,
                    ssrCode = normalizedSsr,
                    description = description.trim(),
                    unit = unit.trim(),
                    boqQuantity = qty,
                    rate = rate,
                    amount = amount ?: 0.0,
                    specification = "",
                    remarks = "Imported from Excel"
                )
            }
        }
        return output
    }

    private data class HeaderMap(
        val item: Int?, val ssr: Int?, val description: Int?, val unit: Int?,
        val quantity: Int?, val rate: Int?, val amount: Int?
    )

    private fun mapHeaders(row: Row, formatter: DataFormatter): HeaderMap {
        fun find(vararg terms: String): Int? = row.mapIndexed { index, cell ->
            val v = formatter.formatCellValue(cell).trim().lowercase(Locale.ROOT)
            index to v
        }.firstOrNull { (_, value) -> terms.any { value.contains(it) } }?.first
        return HeaderMap(
            item = find("item no", "item number", "sr no", "sr. no", "srno"),
            ssr = find("ssr code", "ssr", "schedule code", "code"),
            description = find("description", "particular", "name of work", "item description"),
            unit = find("unit"),
            quantity = find("quantity", "qty"),
            rate = find("rate", "unit rate", "tender rate"),
            amount = find("amount", "cost", "value")
        )
    }

    private fun parsePdf(context: Context, uri: Uri): List<BoqItem> {
        PDFBoxResourceLoader.init(context.applicationContext)
        context.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { document ->
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                val text = stripper.getText(document)
                if (text.isBlank()) error("The PDF has no selectable text. OCR is required for a scanned/image-only PDF.")
                return parsePdfText(text)
            }
        } ?: error("Unable to open the selected PDF file.")
    }

    private fun parsePdfText(text: String): List<BoqItem> {
        val output = mutableListOf<BoqItem>()
        var currentPart = "Part A"

        text.lines().forEach { raw ->
            val line = raw.replace('\u00A0', ' ').trim()
            if (line.isBlank()) return@forEach

            detectPart(line)?.let {
                currentPart = it
                return@forEach
            }

            val match = itemRegex.find(line) ?: return@forEach
            val itemNo = match.groupValues[1]
            val remainder = match.groupValues[2].trim()
            if (remainder.length < 4) return@forEach

            // Most PCMC BOQ PDFs have the numeric tail: unit, quantity, rate, amount.
            val tokens = remainder.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (tokens.size < 5) return@forEach

            val numericPositions = tokens.mapIndexedNotNull { index, token ->
                parseNumber(token)?.let { index to it }
            }
            if (numericPositions.size < 3) return@forEach

            val last = numericPositions.takeLast(3)
            val amount = last[2].second
            val rate = last[1].second
            val qty = last[0].second
            val rateIndex = last[1].first
            val qtyIndex = last[0].first
            if (qtyIndex <= 0 || rateIndex <= qtyIndex) return@forEach

            val prefix = tokens.subList(0, qtyIndex)
            if (prefix.size < 2) return@forEach
            val ssrIndex = prefix.indexOfLast { looksLikeSsr(it) }
            if (ssrIndex < 0) return@forEach

            val ssr = prefix[ssrIndex]
            val unit = if (qtyIndex > 0) tokens[qtyIndex - 1] else ""
            val description = prefix.subList(ssrIndex + 1, qtyIndex - 1).joinToString(" ").trim()
            if (description.isBlank() || unit.isBlank()) return@forEach

            output += BoqItem(
                boqId = 0,
                part = normalizePart(currentPart),
                itemNumber = itemNo,
                ssrCode = ssr,
                description = description,
                unit = unit,
                boqQuantity = qty,
                rate = rate,
                amount = amount,
                specification = "",
                remarks = "Imported from PDF"
            )
        }
        return sortForPcMc(output)
    }

    private fun looksLikeSsr(value: String): Boolean {
        val clean = value.trim().trimEnd(',', ';')
        return clean.matches(Regex("[A-Za-z0-9]+(?:[./()_-][A-Za-z0-9]+)+")) ||
            clean.matches(Regex("[A-Za-z]{0,3}-?\\d+(?:[./_-]\\d+)+[A-Za-z0-9]*"))
    }

    private fun detectPart(text: String): String? {
        val m = partRegex.find(text) ?: return null
        return "Part ${m.groupValues[1].uppercase(Locale.ROOT)}"
    }

    private fun normalizePart(value: String): String {
        val match = partRegex.find(value)
        return if (match != null) "Part ${match.groupValues[1].uppercase(Locale.ROOT)}" else value.trim()
    }

    private fun isLikelyItem(item: String, ssr: String, description: String): Boolean {
        return item.isNotBlank() && ssr.isNotBlank() && description.isNotBlank() &&
            (item.any(Char::isDigit) || item.any(Char::isLetter))
    }

    private fun parseNumber(raw: String): Double? {
        if (raw.isBlank()) return null
        val clean = raw.replace("₹", "").replace("Rs.", "", ignoreCase = true)
            .replace("Rs", "", ignoreCase = true).trim().replace(",", "")
        return clean.toDoubleOrNull() ?: numberRegex.find(clean)?.value?.replace(",", "")?.toDoubleOrNull()
    }

    fun sortForPcMc(items: List<BoqItem>): List<BoqItem> {
        fun partRank(part: String): Int = when (part.uppercase(Locale.ROOT).replace(" ", "")) {
            "PARTA", "A" -> 1
            "PARTB", "B" -> 2
            "PARTC", "C" -> 3
            "PARTD", "D" -> 4
            else -> 99
        }
        fun itemRank(value: String): List<Int> = Regex("\\d+").findAll(value).map { it.value.toInt() }.toList().ifEmpty { listOf(Int.MAX_VALUE) }
        return items.sortedWith(compareBy<BoqItem>({ partRank(it.part) }, { itemRank(it.ssrCode) }, { itemRank(it.itemNumber) }, { it.ssrCode.lowercase(Locale.ROOT) }))
    }
}
