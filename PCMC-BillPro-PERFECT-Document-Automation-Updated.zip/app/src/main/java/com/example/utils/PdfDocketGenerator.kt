package com.example.utils

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.util.Log
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * Central PCMC document renderer.  The same project/BOQ/MB/RA data feeds every generated document,
 * so the user enters master information once and the document package reuses it consistently.
 */
object PdfDocketGenerator {
    private var activeWebView: WebView? = null

    private suspend fun printHtml(
        context: Context,
        htmlContent: String,
        jobName: String,
        landscape: Boolean = false
    ) {
        withContext(Dispatchers.Main) {
            try {
                val webView = WebView(context)
                activeWebView = webView
                webView.settings.defaultTextEncodingName = "UTF-8"
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                        val printAdapter = view.createPrintDocumentAdapter(jobName)
                        val builder = PrintAttributes.Builder()
                            .setMediaSize(if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape() else PrintAttributes.MediaSize.ISO_A4.asPortrait())
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        printManager.print(jobName, printAdapter, builder.build())
                    }
                }
                webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
            } catch (e: Throwable) {
                Log.e("PCMC-PDF", "Error generating PDF", e)
            }
        }
    }

    private fun esc(v: String): String = v
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")

    private fun money(v: Double): String = String.format(Locale.US, "%,.2f", v)
    private fun qty(v: Double): String = String.format(Locale.US, "%.3f", v)
    private fun dateText(millis: Long): String = if (millis <= 0L) "" else SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(millis))

    private fun partRank(part: String): Int = when (part.uppercase(Locale.ROOT).replace(" ", "")) {
        "PARTA", "A" -> 1
        "PARTB", "B" -> 2
        "PARTC", "C" -> 3
        "PARTD", "D" -> 4
        else -> 99
    }

    private fun codeRank(value: String): List<Int> = Regex("\\d+")
        .findAll(value)
        .map { it.value.toIntOrNull() ?: Int.MAX_VALUE }
        .toList()
        .ifEmpty { listOf(Int.MAX_VALUE) }

    private fun sortedBoq(items: List<BoqItem>): List<BoqItem> = items.sortedWith(
        compareBy<BoqItem>({ partRank(it.part) }, { codeRank(it.ssrCode) }, { codeRank(it.itemNumber) }, { it.ssrCode.lowercase(Locale.ROOT) })
    )

    private fun numberToWords(number: Long): String {
        if (number == 0L) return "Zero"
        val units = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
        val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")
        fun convert(n: Long): String = when {
            n < 20 -> units[n.toInt()]
            n < 100 -> tens[(n / 10).toInt()] + if (n % 10 != 0L) " " + units[(n % 10).toInt()] else ""
            n < 1000 -> units[(n / 100).toInt()] + " Hundred" + if (n % 100 != 0L) " " + convert(n % 100) else ""
            n < 100000 -> convert(n / 1000) + " Thousand" + if (n % 1000 != 0L) " " + convert(n % 1000) else ""
            n < 10000000 -> convert(n / 100000) + " Lakh" + if (n % 100000 != 0L) " " + convert(n % 100000) else ""
            else -> convert(n / 10000000) + " Crore" + if (n % 10000000 != 0L) " " + convert(n % 10000000) else ""
        }
        return convert(number).trim()
    }

    suspend fun generateMbPdfDocket(
        context: Context,
        project: Project,
        mb: MeasurementBook,
        boqItems: List<BoqItem>,
        measurements: List<Measurement>
    ): String {
        val orderedBoq = sortedBoq(boqItems)
        val byItem = measurements.groupBy { it.boqItemId }
        val html = buildString {
            append("""
                <!doctype html><html><head><meta charset='UTF-8'><style>
                @page { size:A4 portrait; margin:10mm; }
                body { font-family:'Noto Sans Devanagari','Mangal',sans-serif; color:#000; font-size:10pt; line-height:1.35; }
                .page { page-break-after:always; } .page:last-child { page-break-after:auto; }
                h1,h2,h3 { text-align:center; margin:6px 0; } .center{text-align:center}.left{text-align:left}.right{text-align:right}
                table{width:100%;border-collapse:collapse;margin:10px 0;font-size:8.5pt} th,td{border:1px solid #000;padding:4px;vertical-align:middle;text-align:center}
                th{font-weight:700}.sign{height:90px;vertical-align:bottom;text-align:center}.muted{font-size:8pt}
                </style></head><body>
            """.trimIndent())
            append("<div class='page'>")
            append("<h2>पिंपरी चिंचवड महानगरपालिका<br>पिंपरी - ४११ ०१८</h2>")
            append("<h2>मोजमाप पुस्तक</h2>")
            append("<table>")
            append("<tr><th>Project No.</th><td>${esc(project.sapWorkKey)}</td><th>MB No.</th><td>${esc(mb.mbNumber)}</td></tr>")
            append("<tr><th>कामाचे नाव</th><td colspan='3' class='left'>${esc(project.workName)}</td></tr>")
            append("<tr><th>निविदा क्र.</th><td>${esc(project.tenderNumber)}</td><th>ठेकेदार</th><td class='left'>${esc(project.contractorName)}</td></tr>")
            append("<tr><th>विभाग</th><td>${esc(project.department)}</td><th>प्रभाग / क्षेत्र</th><td>${esc(project.wardName.ifBlank { project.subDivision })}</td></tr>")
            append("<tr><th>MB दिनांक</th><td>${dateText(mb.date)}</td><th>JE</th><td>${esc(project.engineerName)}</td></tr>")
            append("</table>")
            append("<p class='muted'>टीप: अधिकृत निर्यातामध्ये Part A → B → C → D आणि SSR Code ascending क्रम ठेवण्यात येतो. स्क्रीनवरील नोंदी मात्र newest-first दाखवल्या जातात.</p>")
            append("<table><tr><th>अ.क्र.</th><th>कामाचे नाव</th><th>निविदा क्र.</th><th>ठेकेदार</th><th>MB No.</th></tr>")
            append("<tr><td>1</td><td class='left'>${esc(project.workName)}</td><td>${esc(project.tenderNumber)}</td><td class='left'>${esc(project.contractorName)}</td><td>${esc(mb.mbNumber)}</td></tr></table>")
            append("<div style='height:120px'></div>")
            append("<table><tr><td class='sign'><b>कनिष्ठ अभियंता</b><br>${esc(project.engineerName)}</td><td class='sign'><b>उप अभियंता</b><br>${esc(project.deputyEngineerName)}</td><td class='sign'><b>कार्यकारी अभियंता</b><br>${esc(project.executiveEngineerName)}</td></tr></table>")
            append("</div>")

            append("<div class='page'><h3>RECORD ENTRY</h3>")
            append("<table><tr><th>Part</th><th>SSR Code</th><th>Item No.</th><th>Date</th><th>Location / Description</th><th>Remark</th><th>No.</th><th>L</th><th>B</th><th>AvgB</th><th>H/D</th><th>AvgH</th><th>Qty.</th><th>Total Qty.</th></tr>")
            for (boq in orderedBoq) {
                val ms = byItem[boq.id].orEmpty().sortedWith(compareBy<Measurement>({ it.date }, { it.id }))
                if (ms.isEmpty()) continue
                append("<tr><td>${esc(boq.part)}</td><td><b>${esc(boq.ssrCode)}</b></td><td>${esc(boq.itemNumber)}</td><td colspan='11' class='left'><b>${esc(boq.description)}</b></td></tr>")
                var total = 0.0
                for (m in ms) {
                    total += m.quantity
                    append("<tr>")
                    append("<td>${esc(boq.part)}</td><td>${esc(boq.ssrCode)}</td><td>${esc(boq.itemNumber)}</td>")
                    append("<td>${esc(m.date)}</td><td class='left'>${esc(m.location)}</td><td class='left'>${esc(m.remark)}</td>")
                    append("<td>${qty(m.number)}</td><td>${qty(m.length)}</td><td>${qty(m.breadth)}</td><td></td><td>${qty(m.height)}</td><td></td><td>${qty(m.quantity)}</td><td></td>")
                    append("</tr>")
                }
                append("<tr><td colspan='12' class='right'><b>Total - ${esc(boq.ssrCode)}</b></td><td colspan='2'><b>${qty(total)}</b></td></tr>")
            }
            append("</table></div>")

            append("<div class='page'><h3>Abstract</h3>")
            append("<table><tr><th>Part</th><th>SSR Code</th><th>Item No.</th><th>Description</th><th>MB No.</th><th>Qty. Up to Date</th><th>Tender Rate</th><th>Amount</th><th>Remark</th></tr>")
            for (boq in orderedBoq) {
                val ms = byItem[boq.id].orEmpty()
                if (ms.isEmpty()) continue
                val total = ms.sumOf { it.quantity }
                append("<tr><td>${esc(boq.part)}</td><td>${esc(boq.ssrCode)}</td><td>${esc(boq.itemNumber)}</td><td class='left'>${esc(boq.description)}</td><td>${esc(mb.mbNumber)}</td><td>${qty(total)}</td><td>${money(boq.rate)}</td><td>${money(total * boq.rate)}</td><td class='left'>${esc(ms.last().remark)}</td></tr>")
            }
            append("</table>")
            append("<table><tr><td class='sign'><b>कनिष्ठ अभियंता</b><br>${esc(project.engineerName)}</td><td class='sign'><b>उप अभियंता</b><br>${esc(project.deputyEngineerName)}</td></tr></table>")
            append("</div>")
            append("</body></html>")
        }
        printHtml(context, html, "MB_${mb.mbNumber}", landscape = false)
        return "Opening PDF Preview..."
    }

    suspend fun generateRaBillPdfDocket(
        context: Context,
        project: Project,
        raBill: RaBill,
        boqItems: List<BoqItem>,
        raBillItems: List<RaBillItem>
    ): String {
        val orderedById = sortedBoq(boqItems).associateBy { it.id }
        val orderedItems = raBillItems.sortedWith(compareBy<RaBillItem>({ partRank(orderedById[it.boqItemId]?.part.orEmpty()) }, { codeRank(orderedById[it.boqItemId]?.ssrCode.orEmpty()) }, { codeRank(orderedById[it.boqItemId]?.itemNumber.orEmpty()) }))
        val factor = when (raBill.tenderRateType.uppercase()) {
            "BELOW" -> 1.0 - raBill.tenderRatePercent / 100.0
            "ABOVE" -> 1.0 + raBill.tenderRatePercent / 100.0
            else -> 1.0
        }
        val totalUptoRaw = orderedItems.sumOf { it.totalQuantity * it.rate }
        val totalPrevRaw = orderedItems.sumOf { it.previousQuantity * it.rate }
        val totalCurrentRaw = orderedItems.sumOf { it.currentQuantity * it.rate }
        val totalUpto = totalUptoRaw * factor
        val totalPrev = totalPrevRaw * factor
        val totalCurrent = totalCurrentRaw * factor
        val uptoGst = totalUpto * (raBill.cgstPercent + raBill.sgstPercent) / 100.0
        val prevGst = totalPrev * (raBill.cgstPercent + raBill.sgstPercent) / 100.0
        val uptoFinal = totalUpto + uptoGst + raBill.testingCharges + raBill.royalty
        val previousFinal = totalPrev + prevGst
        val passed = if (raBill.passedForPayment != 0.0) raBill.passedForPayment else raBill.grossAmount + raBill.gstAmount + raBill.testingCharges + raBill.royalty
        val deductions = raBill.securityDeposit + raBill.tds194c + raBill.tdsCgst + raBill.tdsSgst + raBill.labourWelfareCess + raBill.labourCess + raBill.otherRecoveries
        val cheque = if (raBill.chequeAmount != 0.0) raBill.chequeAmount else passed - deductions

        val html = buildString {
            append("""
                <!doctype html><html><head><meta charset='UTF-8'><style>
                @page{size:A4 landscape;margin:7mm}body{font-family:Arial,'Noto Sans Devanagari',sans-serif;font-size:8.5pt;color:#000}.page{page-break-after:always}.page:last-child{page-break-after:auto}
                h3{margin:3px}.center{text-align:center}.left{text-align:left}.right{text-align:right}table{width:100%;border-collapse:collapse;margin:4px 0}th,td{border:1px solid #000;padding:3px;vertical-align:middle;text-align:right}th{text-align:center}.noborder td{border:0}.box{border:1px solid #000;padding:5px}.signature{height:55px;vertical-align:bottom;text-align:center}.small{font-size:7pt}
                </style></head><body>
            """.trimIndent())
            append("<div class='page'><h3 class='center'>Pimpri-Chinchwad Muncipal Corporation, Pimpri 411 018</h3>")
            append("<table><tr><td colspan='5' class='left'><b>Serial No. of this Bill:</b> ${esc(raBill.billNumber)}</td><td colspan='5' class='left'><b>Previous Bill:</b> ${if (raBill.billNumber == "RA-01") "NIL" else "Previous RA Bill"}</td></tr>")
            append("<tr><td colspan='5' class='left'><b>Reference to agreement:</b> ${esc(project.workOrderNumber)}</td><td colspan='5' class='left'><b>Tender No:</b> ${esc(project.tenderNumber)}</td></tr>")
            append("<tr><td colspan='5' class='left'><b>Date of written order to commence work:</b> ${esc(project.workOrderDate.ifBlank { dateText(project.startDate) })}</td><td colspan='5' class='left'><b>Date of Completion as stipulated:</b> ${dateText(project.completionDate)}</td></tr>")
            append("<tr><td colspan='5' class='left'><b>Name of Work:</b><br>${esc(project.workName)}</td><td colspan='5' class='left'><b>Name of the Contractor or Suppliers:</b><br>${esc(project.contractorName)}<br>PAN: ${esc(project.panNumber)}<br>GST: ${esc(project.gstNumber)}<br>Department: ${esc(project.department)}<br>Division: ${esc(project.division)}<br>Sub-Division: ${esc(project.subDivision)}</td></tr></table>")
            append("<table><tr><th>Administrative Approval</th><th>Technical Sanction</th><th>Tender Amount</th><th>Tender Rate</th><th>Adjustment</th><th>Adjusted Work Value</th></tr>")
            append("<tr><td>Rs. ${money(project.estimateAmount)}</td><td>Rs. ${money(if (project.technicalSanctionAmount == 0.0) project.estimateAmount else project.technicalSanctionAmount)}</td><td>Rs. ${money(project.agreementAmount)}</td><td>${esc(raBill.tenderRateType)} ${money(raBill.tenderRatePercent)}%</td><td>Rs. ${money(raBill.tenderAdjustmentAmount)}</td><td>Rs. ${money(raBill.grossAmount)}</td></tr>")
            append("<tr><th>Testing Charges</th><th>Royalty</th><th>CGST</th><th>SGST</th><th>GST Total</th><th>Total Rs.</th></tr>")
            append("<tr><td>${money(raBill.testingCharges)}</td><td>${money(raBill.royalty)}</td><td>${money(raBill.cgstAmount)}</td><td>${money(raBill.sgstAmount)}</td><td>${money(raBill.gstAmount)}</td><td>${money(passed)}</td></tr></table>")
            append("<div class='box'><b>Tender Rate: ${esc(raBill.tenderRateType)} ${money(raBill.tenderRatePercent)}%</b>&nbsp;&nbsp;|&nbsp;&nbsp;<b>Running Account Bill: ${esc(raBill.billNumber)}</b></div>")
            append("<table class='noborder'><tr><td class='signature'><b>JUNIOR ENGINEER</b><br>${esc(project.engineerName)}</td><td class='signature'><b>DEPUTY ENGINEER</b><br>${esc(project.deputyEngineerName)}</td><td class='signature'><b>Accounts Clerk / Divisional Accountant</b></td><td class='signature'><b>EXECUTIVE ENGINEER</b><br>${esc(project.executiveEngineerName)}</td></tr></table></div>")

            append("<div class='page'><h3 class='center'>Part 1- ACCOUNT OF WORK EXECUTED</h3>")
            append("<table><tr><th>Item</th><th>SSR Code</th><th>Description Of Work</th><th>Unit</th><th>Qty previous</th><th>Qty current</th><th>Qty up to date</th><th>Tender Rate</th><th>Total Upto Date</th><th>Since previous Bill</th><th>Upto previous Bill</th></tr><tr><th>1</th><th>SSR</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th><th>10</th></tr>")
            for (item in orderedItems) {
                val boq = orderedById[item.boqItemId]
                append("<tr><td>${esc(boq?.itemNumber.orEmpty())}</td><td>${esc(boq?.ssrCode.orEmpty())}</td><td class='left'>${esc(boq?.description.orEmpty())}</td><td>${esc(boq?.unit.orEmpty())}</td><td>${qty(item.previousQuantity)}</td><td>${qty(item.currentQuantity)}</td><td>${qty(item.totalQuantity)}</td><td>${money(item.rate)}</td><td>${money(item.totalQuantity * item.rate * factor)}</td><td>${money(item.currentQuantity * item.rate * factor)}</td><td>${money(item.previousQuantity * item.rate * factor)}</td></tr>")
            }
            append("<tr><th colspan='8' class='right'>TOTAL Rs</th><th>${money(totalUpto)}</th><th>${money(totalCurrent)}</th><th>${money(totalPrev)}</th></tr>")
            append("<tr><td colspan='8' class='right'><b>${esc(raBill.tenderRateType)} ${money(raBill.tenderRatePercent)}% as per tender Rate</b></td><td colspan='3'>Adjustment: Rs. ${money(raBill.tenderAdjustmentAmount)}</td></tr>")
            append("<tr><td colspan='8' class='right'><b>Total including GST</b></td><td colspan='3'>Rs. ${money(uptoFinal)}</td></tr></table>")
            append("<p class='left'><b>Figure in words:- Rs ${esc(numberToWords(kotlin.math.round(passed).toLong()))} Rupees Only</b></p></div>")

            append("<div class='page'><h3 class='center'>Part II: Account of Secured Advance allowed on the security of materials brought to site</h3>")
            append("<table><tr><th>Quantity outstanding from previous bill</th><th>Deduct quantity utilized</th><th>Quantity outstanding</th><th>Full rate</th><th>Description of materials</th><th>Unit</th><th>Reduced rate</th><th>Up-to-date amount of advance</th><th>Order No.</th><th>Date</th><th>Reasons for non-clearance</th></tr><tr><td colspan='11' style='height:180px'></td></tr></table>")
            append("<table><tr><td colspan='8' class='left'>Total amount outstanding as per this bill (C)</td><td colspan='3'>Rs. 0.00</td></tr><tr><td colspan='8' class='left'>Deduct amount outstanding as entry (C) of previous bill</td><td colspan='3'>Rs. 0.00</td></tr><tr><td colspan='8' class='left'>Net amount since previous bill</td><td colspan='3'>Rs. 0.00</td></tr></table></div>")

            append("<div class='page'><h3 class='center'>Part III : Certificate and Signature</h3>")
            append("<table><tr><td class='left'>1. Entries in columns (4) to (9) of Part 1 are based on measurements recorded by Shri/Smt. ${esc(project.engineerName.ifBlank { "_____________________" })} (Junior Engineer) with MB No: _____________________ and verified and checked by Shri/Smt. ${esc(project.deputyEngineerName.ifBlank { "_____________________" })} (Deputy Engineer).</td></tr>")
            append("<tr><td class='left'>2. Certified that the quantities of work actually executed are recorded in Part I and are subject to verification and detailed measurement.</td></tr><tr><td class='left'>3. Certified that quantities of materials shown in Part II, if any, have actually been brought by the contractor and that no previous advance has been received on their security.</td></tr></table>")
            append("<table class='noborder'><tr><td class='signature'><b>Contractor</b></td><td class='signature'><b>Junior Engineer</b></td><td class='signature'><b>Deputy Engineer</b></td><td class='signature'><b>Executive Engineer</b></td></tr></table></div>")

            append("<div class='page'><h3 class='center'>Part IV Memorandum Of Payments</h3>")
            append("<table><tr><td class='left'>1. Total value of work actually measured as per Part I</td><td>Rs. ${money(uptoFinal)}</td></tr><tr><td class='left'>2. Total up-to-date advance payment for work not yet measured</td><td>Rs. 0.00</td></tr><tr><td class='left'>3. Total up-to-date secured advance</td><td>Rs. 0.00</td></tr><tr><td class='left'>4. Total</td><td><b>Rs. ${money(uptoFinal)}</b></td></tr><tr><td class='left'>5. Deduct- Value of work shown in previous bill</td><td>Rs. ${money(previousFinal)}</td></tr><tr><td class='left'>6. Net value of work since previous bill</td><td>Rs. ${money(passed)}</td></tr><tr><td class='left'>7. Deductions / Amount Withheld</td><td>Rs. ${money(deductions)}</td></tr><tr><td class='left'>8. Balance / Payment now to be made</td><td>Rs. ${money(cheque)}</td></tr></table>")
            append("<h4>8. Payments now to be made as detailed below</h4><table><tr><th>No.</th><th>Recovery / Payment Head</th><th>Amount</th></tr>")
            append("<tr><td>1</td><td class='left'>Security Deposit</td><td>Rs. ${money(raBill.securityDeposit)}</td></tr><tr><td>2</td><td class='left'>194C Contractor</td><td>Rs. ${money(raBill.tds194c)}</td></tr><tr><td>3</td><td class='left'>TDS - CGST</td><td>Rs. ${money(raBill.tdsCgst)}</td></tr><tr><td>4</td><td class='left'>TDS - SGST</td><td>Rs. ${money(raBill.tdsSgst)}</td></tr><tr><td>5</td><td class='left'>Labour Welfare Upkar</td><td>Rs. ${money(raBill.labourWelfareCess)}</td></tr><tr><td>6</td><td class='left'>Labour Cess</td><td>Rs. ${money(raBill.labourCess)}</td></tr><tr><td>7</td><td class='left'>Other Recoveries</td><td>Rs. ${money(raBill.otherRecoveries)}</td></tr><tr><td colspan='2' class='right'><b>Total Deductions</b></td><td><b>Rs. ${money(deductions)}</b></td></tr></table>")
            append("<table class='noborder'><tr><td class='left'><b>Passed for payment</b></td><td>Rs. ${money(passed)}</td></tr><tr><td class='left'><b>Pay by cheque</b></td><td>Rs. ${money(cheque)}</td></tr><tr><td class='left'><b>Deduction of</b></td><td>Rs. ${money(passed - cheque)}</td></tr></table>")
            append("<p class='left'><b>Passed for payment:</b> ${esc(numberToWords(kotlin.math.round(passed).toLong()))} Rupees Only</p><table class='noborder'><tr><td class='signature'><b>Full Signature of Contractor</b></td><td class='signature'><b>Disbursing Office</b></td><td class='signature'><b>Paid by me, vide Cheque No. / Date</b></td></tr></table></div>")
            append("</body></html>")
        }
        printHtml(context, html, "RA_Bill_${raBill.billNumber}", landscape = true)
        return "Opening PDF Preview..."
    }

    fun getCertificatesHtml(project: Project, raBill: RaBill, docIndex: Int? = null): String {
        val workName = esc(project.workName)
        val contractor = esc(project.contractorName)
        val tenderNo = esc(project.tenderNumber)
        val tenderAmt = money(project.agreementAmount)
        val adminAmt = money(project.estimateAmount)
        val tsAmt = money(if (project.technicalSanctionAmount == 0.0) project.estimateAmount else project.technicalSanctionAmount)
        val rateText = if (project.tenderRatePercent != 0.0) "${esc(project.tenderRateType)} ${money(project.tenderRatePercent)}%" else "${esc(raBill.tenderRateType)} ${money(raBill.tenderRatePercent)}%"
        val zone = esc(project.regionalOffice.ifBlank { project.subDivision.ifBlank { "क क्षेत्रीय कार्यालय" } })
        val deName = esc(project.deputyEngineerName.ifBlank { "_______________" })
        val eeName = esc(project.executiveEngineerName.ifBlank { "_______________" })
        val orderDate = esc(project.workOrderDate.ifBlank { dateText(project.startDate) })
        val completionDate = dateText(project.completionDate).ifBlank { "काम चालू आहे." }
        val duration = project.workDurationMonths.coerceAtLeast(1)
        val raAmount = money(raBill.grossAmount)
        val royalty = money(raBill.royalty)
        val adminApprovalNo = esc(project.adminApprovalNumber.ifBlank { "_______________" })
        val tsNo = esc(project.technicalSanctionNumber.ifBlank { "_______________" })
        val adDate = esc(project.advertisementDate.ifBlank { "_______________" })
        val tenderAcceptance = esc(project.tenderAcceptanceDate.ifBlank { "_______________" })

        fun page(body: String): String = "<div class='page-break'>$body</div>"

        val docs = listOf(
            page("""
                <h2 style='text-decoration:underline'>पहिले आर. ए. बिल</h2>
                <table class='no-border'>
                <tr><td>१)</td><td>कामाचे नाव -</td><td><b>$workName</b></td></tr>
                <tr><td>२)</td><td>ठेकेदाराचे नाव -</td><td><b>$contractor</b></td></tr>
                <tr><td>३)</td><td>अंदाजपत्रकीय किंमत -</td><td><b>रक्कम रुपये $adminAmt/-</b></td></tr>
                <tr><td>४)</td><td>टेंडरची रक्कम -</td><td><b>रक्कम रुपये $tenderAmt/-</b></td></tr>
                <tr><td>५)</td><td>कामाची प्रशासकीय मान्यता -</td><td><b>र.रु. $adminAmt/-</b><br>जा.क्र. $adminApprovalNo</td></tr>
                <tr><td>६)</td><td>कामाला तांत्रिक मान्यता -</td><td><b>र.रु. $tsAmt/-</b><br>क्र. $tsNo</td></tr>
                <tr><td>७)</td><td>जाहिरातीचे वर्तमानपत्र व दिनांक -</td><td><b>$adDate</b></td></tr>
                <tr><td>८)</td><td>कामाची निविदा केव्हा मान्य झाली -</td><td><b>$tenderAcceptance</b></td></tr>
                <tr><td>९)</td><td>कामाचा आदेश दिलेला दिनांक -</td><td><b>$orderDate</b></td></tr>
                <tr><td>१०)</td><td>कामाची मुदत -</td><td><b>$duration महिने</b></td></tr>
                <tr><td>११)</td><td>प्रत्यक्ष काम संपलेली तारिख -</td><td><b>$completionDate</b></td></tr>
                <tr><td>१२)</td><td>काम पुर्ण झाले असल्यास कामाचे माप उशिरा घेतले त्याचे कारण -</td><td><b>नाही</b></td></tr>
                <tr><td>१३)</td><td>मुदतवाढ दिली काय ? दिल्यास केव्हा दिली व किती दिली -</td><td><b>_______________</b></td></tr>
                <tr><td>१४)</td><td>पहिले आर. ए. बिलाची रक्कम रुपये -</td><td><b>र.रु. $raAmount /-</b></td></tr>
                <tr><td>१५)</td><td>एस्टिमेट रिवाईज करणे जरुर आहे काय ? -</td><td><b>नाही</b></td></tr>
                <tr><td>१६)</td><td>जादा बाब मंजुर करुन घेतले काय ? -</td><td><b>नाही</b></td></tr>
                <tr><td>१७)</td><td>ठेकेदारास सिमेंट व इतर सामान एकूण किती दिली व त्याची वसुली कशी केली -</td><td><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                <tr><td>१८)</td><td>ठेकेदाराने पाणी वापरले काय व त्याचे पैसे भरले नसल्यास १/२ टक्के कापून घेतले काय ? -</td><td><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                <tr><td>१९)</td><td>ठेकेदारास मशिनरी भाड्याने दिली काय ? -</td><td><b>ठेकेदार याने स्वतः व्यवस्था केली.</b></td></tr>
                <tr><td>२०)</td><td>इतर -</td><td>सदर बिलामधून रॉयल्टीपोटी र.रु. $royalty /- वजा करणेत यावी.</td></tr>
                </table>
                <div class='signature-block'><div><b>कनिष्ठ अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८</div><div><b>उप अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८</div></div>
            """),
            page("""
                <h2 style='text-decoration:underline'>दाखला</h2>
                <div class='list-item'>१) ठेकेदाराचे नाव – <b>$contractor</b></div>
                <div class='list-item'>२) कामाचे नाव – <b>$workName</b></div>
                <div class='list-item'>३) प्रशासकीय मान्यता – <b>रक्कम रुपये $adminAmt/-</b></div>
                <div class='list-item'>४) निविदा रक्कम – <b>रक्कम रुपये $tenderAmt/-</b></div>
                <div class='list-item'>५) निविदा क्रमांक – <b>$tenderNo</b></div>
                <div class='list-item'>६) कामाचा दर – <b>$rateText</b></div>
                <div class='list-item'>७) कामाची मुळ मुदत – <b>$duration महिने</b></div>
                <div class='list-item'>८) कामाचे बिल क्रमांक – <b>${esc(raBill.billNumber)}</b></div>
                <p class='para'>प्रस्तुत कामाची मी <b>${esc(project.engineerName.ifBlank { "_______________" })}</b> उप अभियंता विभाग स्थापत्य $zone १००% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>
                <div class='signature-right'><b>उप अभियंता</b><br>स्थापत्य $zone<br>पिं.चिं.मनपा</div>
            """),
            page("""
                <h2 style='text-decoration:underline'>दाखला</h2>
                <div class='list-item'>१) ठेकेदाराचे नाव – <b>$contractor</b></div><div class='list-item'>२) कामाचे नाव – <b>$workName</b></div>
                <div class='list-item'>३) प्रशासकीय मान्यता – <b>रक्कम रुपये $adminAmt/-</b></div><div class='list-item'>४) निविदा रक्कम – <b>रक्कम रुपये $tenderAmt/-</b></div>
                <div class='list-item'>५) निविदा क्रमांक – <b>$tenderNo</b></div><div class='list-item'>६) कामाचा दर – <b>$rateText</b></div>
                <div class='list-item'>७) कामाची मुळ मुदत – <b>$duration महिने</b></div><div class='list-item'>८) कामाचे बिल क्रमांक – <b>${esc(raBill.billNumber)}</b></div>
                <p class='para'>प्रस्तुत कामाची मी <b>$eeName</b>, कार्यकारी अभियंता विभाग स्थापत्य $zone २५% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>
                <div class='signature-right'><b>कार्यकारी अभियंता</b><br>स्थापत्य $zone<br>पिं.चिं.मनपा</div>
            """),
            page("""
                <h2 style='text-decoration:underline'>Payment Schedule</h2>
                <div style='margin-top:28px'>कामाचे नाव – <b>$workName</b><br>निविदा क्रमांक – <b>$tenderNo</b></div>
                <table><tr><th>अ.क्र.</th><th>बिल क्र.</th><th>बिलाचा दिनांक</th><th>बिलाची रक्कम (₹)</th><th>शेरा</th></tr>
                <tr><td>१</td><td>${esc(raBill.billNumber)}</td><td>${dateText(raBill.date)}</td><td>${raAmount}</td><td class='left'>उपलब्ध तरतुदीप्रमाणे ${esc(raBill.billNumber)} अदा करणेत येत आहे.</td></tr></table>
                <div class='signature-right' style='margin-top:120px'><b>कार्यकारी अभियंता</b><br>स्थापत्य $zone<br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी, पुणे-१८</div>
            """),
            page("""
                <h2 style='text-decoration:underline'>दाखला</h2>
                <div class='list-item'>१) ठेकेदाराचे नाव – <b>$contractor</b></div><div class='list-item'>२) कामाचे नाव – <b>$workName</b></div>
                <div class='list-item'>३) निविदा रक्कम – <b>रक्कम रुपये $tenderAmt/-</b></div><div class='list-item'>४) निविदा क्रमांक – <b>$tenderNo</b></div>
                <p class='para'>प्रस्तुत काम अंदाजपत्रकानुसार त्याच जागेवर पुर्ण करणेत आलेले असून कोणताही स्थळ बदल करणेत आलेला नाही.</p>
                <div class='signature-block' style='margin-top:120px'><div><b>कनिष्ठ अभियंता</b><br>स्थापत्य $zone</div><div><b>उप अभियंता</b><br>स्थापत्य $zone</div></div>
            """),
            page("""
                <div class='letterhead-right'><b>पिंपरी चिंचवड महानगरपालिका,</b><br>$zone कार्यालय, स्थापत्य विभाग<br>जा.क्र.कक्षे/स्था/कावि/____/२०२६<br>दिनांक - ____/____/२०२६</div>
                <h2 style='text-decoration:underline'>दाखला</h2>
                <div>कामाचे नाव – <b>$workName</b><br>निविदा क्रमांक – <b>$tenderNo</b><br>ठेकेदाराचे नाव – <b>$contractor</b></div>
                <p class='para'>वरील कामकाजाबाबत ठेकेदार <b>$contractor</b> यांनी कंत्राटी कामगार (नियमन व निर्मूलन) अधिनियम, १९७० मधील तरतूदींचे पालन केले आहे. तसेच किमान वेतन कायदा १९४८, कर्मचारी राज्य विमा कायदा १९४८, भविष्य निर्वाह निधी कायदा १९५२ इत्यादी कायदेशीर बाबींचे काटेकोरपणे पालन केले आहे. कंत्राटदाराने कामाचा व त्यावर काम करणा-या कामगारांचा विमा उतरविला आहे.</p>
                <div class='signature-right'>पर्यवेक्षकीय अधिकारी –<br>स्वाक्षरी –<br>पदनाम –</div>
                <p>बिल देण्यास शिफारस आहे / नाही.</p>
                <div class='signature-right'>विभागप्रमुख / प्राधिकृत सक्षम अधिकारी<br>स्वाक्षरी –<br>पदनाम –</div>
                <p style='margin-top:36px'>टिप – सदरचा दाखला संबंधित ठेकेदाराचे बिल अदा करताना प्रकरणी समाविष्ट करणे बंधनकारक आहे.</p>
            """),
            page("""
                <h2>पिंपरी चिंचवड महानगरपालिका, पिंपरी – ४११ ०१८</h2><h3 style='text-decoration:underline'>GIS Mapping दाखला</h3>
                <div class='list-item'>१) कामाचे नाव – <b>$workName</b></div><div class='list-item'>२) निविदा क्रमांक – <b>$tenderNo</b></div>
                <p class='para'>सदर कामाअंतर्गत केलेल्या कामाची GIS Mapping नोंद घेण्यात आलेली असून, सदर कामाची बिल अदायगी करणेत यावी.</p>
                <div class='signature-right' style='margin-top:150px'><b>कार्यकारी अभियंता (स्था)</b><br>$zone कार्यालय<br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८</div>
            """),
            page("""
                <div class='office-head'><b style='text-decoration:underline'>कार्यालयीन टिपणी</b><span>$zone, स्थापत्य विभाग<br>दिनांक - ____/____/२०२६</span></div>
                <div style='margin-top:30px'><b>विषय -</b> $workName<br>निविदा नोटीस क्र. $tenderNo</div>
                <p><b>मा.स.सादर,</b></p>
                <p class='para'>उपरोक्त विषयांकीत कामाचा आदेश ठेकेदार <b>$contractor</b> यांना दि.$orderDate रोजी देणेत आला असून कामाचा स्विकृत निविदा दर <b>$rateText</b> आहे. त्यानुसार विषयांकीत काम तसेच आवश्यकतेनुसार इतर अनुषंगिक कामे करणे गरजेचे आहे. परंतु सदर कामे केल्यास मुळ निविदेतील काही बाबींच्या परिमाणात वाढ होणार आहे. सदर बाबींमुळे मुळ निविदा रक्कम बदलत नसून उर्वरीत बाबींच्या बचतीमधून सदर वाढीव परिमाणाचे काम करता येणार आहे.</p>
                <p class='para'>तथापि मा.शहर अभियंता, पिंपरी चिंचवड महानगरपालिका यांचेकडील परिपत्रकान्वये कमी निविदादर असलेल्या विकास कामांना Quantity Variation होत असल्यास आवश्यक पूर्व परवानगी घेऊन काम करणेबाबत सुचित केले आहे. त्यानुसार विषयांकीत कामाचे मुळ निविदेत नमुद परिमाणापेक्षा जास्तीचे परिमाणाचे काम करणे गरजेचे असलेने संबंधित सक्षम अधिका-यांची मान्यता आवश्यक आहे.</p>
                <p class='para'>तरी सोबत जोडलेल्या Quantity Variation Sheet प्रमाणे सुधारीत परिमाणास मान्यता घेणेकामी स्वाक्षरीस्तव सविनय सादर.</p>
                <div style='margin-top:60px;display:flex;justify-content:space-between;text-align:center'><div><b>उप अभियंता (स्था)</b><br>$zone कार्यालय<br>पिं.चिं.महानगरपालिका</div><div><b>कार्यकारी अभियंता (स्था)</b><br>$zone कार्यालय<br>पिं.चिं.महानगरपालिका</div><div><b>सह शहर अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी-४११ ०१८</div></div>
            """ )
        )

        val selected = if (docIndex != null && docIndex in docs.indices) listOf(docs[docIndex]) else docs
        return """
            <!doctype html><html><head><meta charset='UTF-8'><style>
            @page{size:A4 portrait;margin:18mm 18mm 16mm 18mm}body{font-family:'Noto Sans Devanagari','Mangal',sans-serif;font-size:14pt;line-height:1.6;color:#000;margin:0}.page-break{page-break-after:always;min-height:92vh}.page-break:last-child{page-break-after:auto}
            h1,h2,h3,h4{text-align:center;margin:6px 0 18px}.center{text-align:center}.right{text-align:right}.list-item{margin:8px 0}.para{text-align:justify;text-indent:45px;margin-top:28px}.signature-block{display:flex;justify-content:space-between;gap:40px;margin-top:80px;text-align:center}.signature-right{text-align:right;margin-top:70px}.no-border{border-collapse:collapse}.no-border td{border:none !important;padding:3px 6px;text-align:left}.no-border td:first-child{width:6%}.no-border td:nth-child(2){width:35%}.no-border td:nth-child(3){width:59%}table{width:100%;border-collapse:collapse;margin:18px 0}th,td{border:1px solid #000;padding:7px;vertical-align:top}th{font-weight:700}.letterhead-right{display:flex;justify-content:flex-end;text-align:left;margin-bottom:28px}.office-head{display:flex;justify-content:space-between;align-items:flex-start;font-weight:700}.office-head span{font-weight:400}
            </style></head><body>${selected.joinToString("")}</body></html>
        """.trimIndent()
    }

    suspend fun generateCertificatesPdfDocket(context: Context, project: Project, raBill: RaBill, docIndex: Int? = null): String {
        val html = getCertificatesHtml(project, raBill, docIndex)
        val suffix = docIndex?.toString() ?: "All"
        printHtml(context, html, "PCMC_Documents_${raBill.billNumber}_${suffix}", landscape = false)
        return "Opening PDF Preview..."
    }
}
