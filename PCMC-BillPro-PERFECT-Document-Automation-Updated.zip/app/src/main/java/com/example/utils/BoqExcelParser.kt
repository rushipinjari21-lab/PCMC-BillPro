package com.example.utils

import android.content.Context
import android.net.Uri
import com.example.data.BoqItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Backward-compatible entry point used by older code. */
object BoqExcelParser {
    suspend fun parseExcel(context: Context, uri: Uri): List<BoqItem> =
        withContext(Dispatchers.IO) { BoqFileParser.parse(context, uri) }
}
