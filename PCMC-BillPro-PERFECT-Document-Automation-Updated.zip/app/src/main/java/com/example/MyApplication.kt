package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        
        try {
            // FirebaseApp.initializeApp returns null if it cannot find the configuration
            // (e.g. if google-services.json is missing)
            val app = FirebaseApp.initializeApp(this)
            
            if (app != null) {
                // Initialize Firebase App Check with Play Integrity ONLY if Firebase initialized successfully
                val firebaseAppCheck = FirebaseAppCheck.getInstance()
                firebaseAppCheck.installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
                Log.i("MyApplication", "Firebase App Check initialized successfully.")
            } else {
                Log.w("MyApplication", "FirebaseApp.initializeApp returned null. Ensure google-services.json is present.")
            }
        } catch (e: Exception) {
            Log.e("MyApplication", "Error initializing Firebase or App Check: ${e.message}")
        }
    }
}
