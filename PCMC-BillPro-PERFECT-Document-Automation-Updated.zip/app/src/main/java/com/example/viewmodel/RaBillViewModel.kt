package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDao
import com.example.data.RaBill
import com.example.data.RaBillItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Date

@android.annotation.SuppressLint("NewApi")
class RaBillViewModel(private val dao: AppDao) : ViewModel() {

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun getRaBills(sapWorkKey: String): Flow<List<RaBill>> {
        return dao.getRaBillsByWorkKey(sapWorkKey)
    }

    fun generateRaBill(
        sapWorkKey: String,
        billNumber: String,
        gstPercent: Double,
        labourCessPercent: Double,
        sdPercent: Double,
        otherRecoveries: Double,
        tenderRateType: String = "AT PAR",
        tenderRatePercent: Double = 0.0,
        testingCharges: Double = 0.0,
        royalty: Double = 0.0,
        tds194cPercent: Double = 2.0,
        tdsCgstPercent: Double = 1.0,
        tdsSgstPercent: Double = 1.0,
        labourWelfarePercent: Double = 1.0,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (boq == null) {
                    _error.value = "No BOQ found for this project."
                    return@launch
                }

                val boqItems = dao.getBoqItems(boq.id).first()
                val previousBill = dao.getLatestRaBill(sapWorkKey)
                val previousItems = previousBill?.let { dao.getRaBillItems(it.id).first() } ?: emptyList()
                val previousByBoq = previousItems.associateBy { it.boqItemId }

                val raBillItems = mutableListOf<RaBillItem>()
                var rawUptoDateAmount = 0.0
                var currentRawAmount = 0.0

                for (item in boqItems) {
                    val measurements = dao.getMeasurementsByBoqItemId(item.id)
                    val measuredUptoDateQty = measurements.sumOf { it.quantity }
                    val previousQty = previousByBoq[item.id]?.totalQuantity ?: 0.0
                    val currentQty = (measuredUptoDateQty - previousQty).coerceAtLeast(0.0)

                    if (measuredUptoDateQty > 0.0) {
                        val amount = measuredUptoDateQty * item.rate
                        rawUptoDateAmount += amount
                        currentRawAmount += currentQty * item.rate
                        raBillItems.add(
                            RaBillItem(
                                billId = 0,
                                boqItemId = item.id,
                                previousQuantity = previousQty,
                                currentQuantity = currentQty,
                                totalQuantity = measuredUptoDateQty,
                                rate = item.rate,
                                amount = amount
                            )
                        )
                    }
                }

                if (raBillItems.isEmpty()) {
                    _error.value = "No measurements found. Please add measurements in MB first."
                    return@launch
                }

                val normalizedType = tenderRateType.uppercase()
                val adjustment = when (normalizedType) {
                    "BELOW" -> rawUptoDateAmount * tenderRatePercent / 100.0
                    "ABOVE" -> rawUptoDateAmount * tenderRatePercent / 100.0
                    else -> 0.0
                }
                val adjustedUptoDate = when (normalizedType) {
                    "BELOW" -> rawUptoDateAmount - adjustment
                    "ABOVE" -> rawUptoDateAmount + adjustment
                    else -> rawUptoDateAmount
                }

                val adjustedCurrent = when (normalizedType) {
                    "BELOW" -> currentRawAmount * (1.0 - tenderRatePercent / 100.0)
                    "ABOVE" -> currentRawAmount * (1.0 + tenderRatePercent / 100.0)
                    else -> currentRawAmount
                }

                // Official PCMC RA bills apply GST after the tender-rate-adjusted work value.
                val cgstPercent = gstPercent / 2.0
                val sgstPercent = gstPercent / 2.0
                val cgstAmount = adjustedCurrent * cgstPercent / 100.0
                val sgstAmount = adjustedCurrent * sgstPercent / 100.0
                val gstAmount = cgstAmount + sgstAmount

                val securityDeposit = adjustedCurrent * sdPercent / 100.0
                val labourCess = adjustedCurrent * labourCessPercent / 100.0
                val tds194c = adjustedCurrent * tds194cPercent / 100.0
                val tdsCgst = adjustedCurrent * tdsCgstPercent / 100.0
                val tdsSgst = adjustedCurrent * tdsSgstPercent / 100.0
                val labourWelfare = adjustedCurrent * labourWelfarePercent / 100.0

                val grossCurrentWithGst = adjustedCurrent + gstAmount + testingCharges + royalty
                val totalDeductions = securityDeposit + labourCess + tds194c + tdsCgst +
                    tdsSgst + labourWelfare + otherRecoveries
                val passedForPayment = grossCurrentWithGst
                val chequeAmount = passedForPayment - totalDeductions
                val roundingOff = kotlin.math.round(passedForPayment) - passedForPayment

                val bill = RaBill(
                    sapWorkKey = sapWorkKey,
                    billNumber = billNumber,
                    date = Date().time,
                    grossAmount = adjustedCurrent,
                    gstAmount = gstAmount,
                    labourCess = labourCess,
                    securityDeposit = securityDeposit,
                    otherRecoveries = otherRecoveries,
                    netPayable = chequeAmount,
                    tenderRateType = normalizedType,
                    tenderRatePercent = tenderRatePercent,
                    tenderAdjustmentAmount = adjustment,
                    testingCharges = testingCharges,
                    royalty = royalty,
                    cgstPercent = cgstPercent,
                    sgstPercent = sgstPercent,
                    cgstAmount = cgstAmount,
                    sgstAmount = sgstAmount,
                    tds194c = tds194c,
                    tdsCgst = tdsCgst,
                    tdsSgst = tdsSgst,
                    labourWelfareCess = labourWelfare,
                    roundingOff = roundingOff,
                    passedForPayment = passedForPayment,
                    chequeAmount = chequeAmount
                )

                val billId = dao.insertRaBill(bill)
                dao.insertRaBillItems(raBillItems.map { it.copy(billId = billId) })
                onSuccess()
            } catch (e: Exception) {
                _error.value = "Failed to generate RA Bill: ${e.message}"
            }
        }
    }


    @android.annotation.SuppressLint("NewApi")
    fun exportRaBillExcel(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    val boq = dao.getBoqByWorkKey(sapWorkKey)
                    if (project != null && bill != null && boq != null) {
                        val boqItems = dao.getBoqItems(boq.id).first()
                        val raBillItems = dao.getRaBillItems(billId).first()
                        
                        val workbook = org.apache.poi.xssf.usermodel.XSSFWorkbook()
                        val sheet = workbook.createSheet("RA Bill")
                        
                        var rowNum = 0
                        val headerRow = sheet.createRow(rowNum++)
                        val headers = listOf("Item No", "Description", "Unit", "Rate", "BOQ Qty", "BOQ Amount", "Previous Qty", "Previous Amt", "This Bill Qty", "This Bill Amt", "Up to Date Qty", "Up to Date Amt")
                        for ((index, header) in headers.withIndex()) {
                            val cell = headerRow.createCell(index)
                            cell.setCellValue(header)
                            val style = workbook.createCellStyle()
                            val font = workbook.createFont()
                            font.bold = true
                            style.setFont(font)
                            cell.cellStyle = style
                        }
                        
                        for (item in boqItems) {
                            val billItem = raBillItems.find { it.boqItemId == item.id }
                            val prevQty = billItem?.previousQuantity ?: 0.0
                            val thisQty = billItem?.currentQuantity ?: 0.0
                            val upToDateQty = prevQty + thisQty
                            
                            val prevAmt = prevQty * item.rate
                            val thisAmt = thisQty * item.rate
                            val upToDateAmt = upToDateQty * item.rate
                            val boqAmt = item.boqQuantity * item.rate
                            
                            val itemRow = sheet.createRow(rowNum++)
                            itemRow.createCell(0).setCellValue(item.itemNumber)
                            itemRow.createCell(1).setCellValue(item.description)
                            itemRow.createCell(2).setCellValue(item.unit)
                            itemRow.createCell(3).setCellValue(item.rate)
                            itemRow.createCell(4).setCellValue(item.boqQuantity)
                            itemRow.createCell(5).setCellValue(boqAmt)
                            itemRow.createCell(6).setCellValue(prevQty)
                            itemRow.createCell(7).setCellValue(prevAmt)
                            itemRow.createCell(8).setCellValue(thisQty)
                            itemRow.createCell(9).setCellValue(thisAmt)
                            itemRow.createCell(10).setCellValue(upToDateQty)
                            itemRow.createCell(11).setCellValue(upToDateAmt)
                        }
                        
                        val fileName = "RABill_${bill.billNumber}_Excel.xlsx"
                        
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                            val contentValues = android.content.ContentValues().apply {
                                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                            }
                            
                            val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                            uri?.let {
                                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                    workbook.write(outputStream)
                                }
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Excel file saved to Downloads: $fileName")
                                }
                            } ?: run {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Failed to create file")
                                }
                            }
                        } else {
                            try {
                                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                                val file = java.io.File(downloadsDir, fileName)
                                file.outputStream().use { outputStream ->
                                    workbook.write(outputStream)
                                }
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Excel file saved to Downloads: $fileName")
                                }
                            } catch (e: Exception) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Failed to save file: ${e.message}")
                                }
                            }
                        }
                        workbook.close()
                    } else {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                            onResult("Missing project or Bill data")
                        }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onResult("Error: ${e.message}")
                    }
                }
            }
        }
    }



    fun exportRaBill(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && bill != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val raBillItems = dao.getRaBillItems(billId).first()
                    val path = com.example.utils.PdfDocketGenerator.generateRaBillPdfDocket(context, project, bill, boqItems, raBillItems)
                    onResult(path)
                } else {
                    onResult("Missing project or Bill data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }


    fun exportCertificates(context: android.content.Context, sapWorkKey: String, billId: Long, docIndex: Int? = null, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val path = com.example.utils.PdfDocketGenerator.generateCertificatesPdfDocket(context, project, bill, docIndex)
                    onResult(path)
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun exportCertificatesWord(context: android.content.Context, sapWorkKey: String, billId: Long, docIndex: Int? = null, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val html = com.example.utils.PdfDocketGenerator.getCertificatesHtml(project, bill, docIndex)
                    
                    val suffix = docIndex?.toString() ?: "All"
                    val fileName = "Certificates_${bill.billNumber}_${suffix}.doc"
                    
                    val contentValues = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/msword")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                    }
                    
                    val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    uri?.let {
                        context.contentResolver.openOutputStream(it)?.use { outputStream ->
                            outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                            outputStream.write(html.toByteArray(Charsets.UTF_8))
                        }
                        onResult("Word file saved to Downloads: $fileName")
                    } ?: run {
                        onResult("Failed to create file")
                    }
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Error: ${e.message}")
            }
        }
    }
    
    
    @android.annotation.SuppressLint("NewApi")
    fun exportCertificatesExcel(context: android.content.Context, sapWorkKey: String, billId: Long, docIndex: Int? = null, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val html = com.example.utils.PdfDocketGenerator.getCertificatesHtml(project, bill, docIndex)
                    
                    val suffix = docIndex?.toString() ?: "All"
                    val fileName = "Certificates_${bill.billNumber}_${suffix}.xls"
                    
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.ms-excel")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel file saved to Downloads: $fileName")
                        } ?: run {
                            onResult("Failed to create file")
                        }
                    } else {
                        try {
                            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            val file = java.io.File(downloadsDir, fileName)
                            file.outputStream().use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel file saved to Downloads: $fileName")
                        } catch (e: Exception) {
                            e.printStackTrace()
                            onResult("Failed to save file: ${e.message}")
                        }
                    }
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Error: ${e.message}")
            }
        }
    }

    
    fun exportDossierDocxPOI(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    if (project != null && bill != null) {
                        val result = com.example.utils.DocumentExportService.exportDossierToDocx(context, project, bill)
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult(result) }
                    } else {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Missing project or Bill data") }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Error: ${e.message}") }
                }
            }
        }
    }

    fun exportDossierXlsxPOI(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    if (project != null && bill != null) {
                        val result = com.example.utils.DocumentExportService.exportDossierToXlsx(context, project, bill)
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult(result) }
                    } else {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Missing project or Bill data") }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Error: ${e.message}") }
                }
            }
        }
    }

    fun getCertificatesHtml(sapWorkKey: String, billId: Long, docIndex: Int? = null, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val html = com.example.utils.PdfDocketGenerator.getCertificatesHtml(project, bill, docIndex)
                    onResult(html)
                } else {
                    onResult(null)
                }
            } catch (e: Exception) {
                onResult(null)
            }
        }
    }
}

@android.annotation.SuppressLint("NewApi")
class RaBillViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RaBillViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RaBillViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
