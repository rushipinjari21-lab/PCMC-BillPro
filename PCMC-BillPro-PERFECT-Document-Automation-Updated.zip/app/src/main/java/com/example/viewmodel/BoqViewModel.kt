package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDao
import com.example.data.Boq
import com.example.data.BoqItem
import com.example.services.BoqStorage
import com.example.utils.BoqFileParser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class BoqViewModel(private val dao: AppDao) : ViewModel() {
    private val boqStorage = BoqStorage(dao)

    private val _currentBoq = MutableStateFlow<Boq?>(null)
    val currentBoq: StateFlow<Boq?> = _currentBoq

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _importedCount = MutableStateFlow(0)
    val importedCount: StateFlow<Int> = _importedCount

    fun loadBoqForProject(sapWorkKey: String) {
        viewModelScope.launch {
            _currentBoq.value = boqStorage.getBOQ(sapWorkKey)
        }
    }

    fun uploadAndParseBoq(context: Context, sapWorkKey: String, uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val displayName = queryDisplayName(context, uri)
                val parsedItems = BoqFileParser.parse(context, uri, displayName)
                if (parsedItems.isEmpty()) {
                    _errorMessage.value = "No BOQ rows were found. Check that the file contains Item No, SSR Code, Description, Unit, Quantity and Rate columns, or that the PDF contains selectable table text."
                } else {
                    val ordered = BoqFileParser.sortForPcMc(parsedItems)
                    boqStorage.replaceBOQ(sapWorkKey, ordered)
                    _importedCount.value = ordered.size
                    _currentBoq.value = boqStorage.getBOQ(sapWorkKey)
                }
            } catch (e: Exception) {
                _errorMessage.value = "BOQ import failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.toString()
    }

    fun clearError() { _errorMessage.value = null }

    fun deleteBoq(sapWorkKey: String) {
        viewModelScope.launch {
            boqStorage.deleteBOQ(sapWorkKey)
            _currentBoq.value = null
            _importedCount.value = 0
        }
    }

    fun getParts(boqId: Long): Flow<List<String>> = boqStorage.getParts(boqId)
    fun getItemsByPart(boqId: Long, part: String): Flow<List<BoqItem>> = boqStorage.getItemsByPart(boqId, part)
    fun searchItems(boqId: Long, query: String): Flow<List<BoqItem>> = boqStorage.searchItems(boqId, query)
    fun getTotalQty(boqId: Long): Flow<Double> = boqStorage.getTotalQty(boqId)
    fun getTotalAmount(boqId: Long): Flow<Double> = boqStorage.getTotalAmount(boqId)
}

class BoqViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BoqViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BoqViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
