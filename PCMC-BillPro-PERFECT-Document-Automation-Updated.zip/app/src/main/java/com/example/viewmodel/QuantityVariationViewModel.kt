package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDao
import com.example.data.QuantityVariation
import com.example.data.QuantityVariationItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Date

class QuantityVariationViewModel(private val dao: AppDao) : ViewModel() {

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun getVariations(sapWorkKey: String): Flow<List<QuantityVariation>> {
        return dao.getQuantityVariationsByWorkKey(sapWorkKey)
    }
    
    fun getVariationItems(variationId: Long): Flow<List<QuantityVariationItem>> {
        return dao.getQuantityVariationItems(variationId)
    }

    fun generateVariation(sapWorkKey: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (boq == null) {
                    _error.value = "No BOQ found for this project."
                    return@launch
                }

                val boqItems = dao.getBoqItems(boq.id).first()
                val qvItems = mutableListOf<QuantityVariationItem>()

                for (item in boqItems) {
                    val measurements = dao.getMeasurementsByBoqItemId(item.id)
                    val finalQty = measurements.sumOf { it.quantity }
                    
                    val variationQty = finalQty - item.boqQuantity
                    val variationPercent = if (item.boqQuantity > 0) (variationQty / item.boqQuantity) * 100 else 0.0
                    val variationAmount = variationQty * item.rate
                    
                    val type = when {
                        variationQty > 0 -> "Increase"
                        variationQty < 0 -> "Decrease"
                        else -> "No Variation"
                    }
                    
                    qvItems.add(
                        QuantityVariationItem(
                            variationId = 0, // Set later
                            boqItemId = item.id,
                            originalBoqQuantity = item.boqQuantity,
                            finalExecutedQuantity = finalQty,
                            variationQuantity = variationQty,
                            variationPercentage = variationPercent,
                            variationAmount = variationAmount,
                            variationType = type,
                            reason = if (type == "Increase") "Site conditions required extra quantity" else "",
                            engineerRemark = ""
                        )
                    )
                }

                if (qvItems.isEmpty()) {
                    _error.value = "No items available to generate variation."
                    return@launch
                }

                val qv = QuantityVariation(
                    sapWorkKey = sapWorkKey,
                    status = "Draft",
                    createdDate = Date().time,
                    approvedDate = null,
                    approverName = null
                )

                val qvId = dao.insertQuantityVariation(qv)
                
                val itemsToInsert = qvItems.map { it.copy(variationId = qvId) }
                dao.insertQuantityVariationItems(itemsToInsert)

                onSuccess()
            } catch (e: Exception) {
                _error.value = "Failed to generate variation: ${e.message}"
            }
        }
    }

    fun submitVariation(variationId: Long) {
        viewModelScope.launch {
            dao.updateQuantityVariationStatus(variationId, "Submitted", null, null)
        }
    }

    fun approveVariation(variationId: Long, approverName: String) {
        viewModelScope.launch {
            dao.updateQuantityVariationStatus(variationId, "Approved", Date().time, approverName)
        }
    }
    
    fun rejectVariation(variationId: Long) {
        viewModelScope.launch {
            dao.updateQuantityVariationStatus(variationId, "Rejected", Date().time, null)
        }
    }


    fun exportQuantityVariation(context: android.content.Context, sapWorkKey: String, variationId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val variation = dao.getQuantityVariationById(variationId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && variation != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val qvItems = dao.getQuantityVariationItems(variationId).first()
                    val path = com.example.utils.PdfDocketGenerator.generateQuantityVariationPdfDocket(context, project, variation, boqItems, qvItems)
                    onResult(path)
                } else {
                    onResult("Missing project or QV data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }

    fun clearError() {
        _error.value = null
    }
}

class QuantityVariationViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(QuantityVariationViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return QuantityVariationViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
