package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDao
import com.example.data.models.AbstractItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class AbstractViewModel(private val dao: AppDao) : ViewModel() {

    fun getProjectAbstract(sapWorkKey: String): Flow<List<AbstractItem>> = flow {
        val boq = dao.getBoqByWorkKey(sapWorkKey)
        if (boq == null) {
            emit(emptyList())
            return@flow
        }

        // We use collect to get the latest items since getBoqItems returns a Flow
        // However, in a flow builder, we just need the snapshot. We can add a suspend function to DAO or collect first.
        // For simplicity, we'll collect the first emission.
        dao.getBoqItems(boq.id).collect { boqItems ->
            val abstractItems = mutableListOf<AbstractItem>()
            
            for (item in boqItems) {
                val measurements = dao.getMeasurementsByBoqItemId(item.id)
                val totalQty = measurements.sumOf { it.quantity }
                
                // Only include in Abstract if execution has occurred
                if (totalQty > 0) {
                    abstractItems.add(
                        AbstractItem(
                            boqItem = item,
                            previousQuantity = 0.0, // In a robust version, this filters by previous MB dates
                            currentQuantity = totalQty,
                            totalQuantity = totalQty,
                            balanceQuantity = item.boqQuantity - totalQty,
                            amount = totalQty * item.rate
                        )
                    )
                }
            }
            emit(abstractItems)
        }
    }
}

class AbstractViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AbstractViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AbstractViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
