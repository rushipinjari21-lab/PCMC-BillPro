package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDao
import com.example.data.BoqItem
import com.example.data.Measurement
import com.example.data.MeasurementBook
import com.example.services.BoqStorage
import com.example.services.MeasurementStorage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MeasurementViewModel(private val dao: AppDao) : ViewModel() {
    private val measurementStorage = MeasurementStorage(dao)
    private val boqStorage = BoqStorage(dao)

    private val _currentMbId = MutableStateFlow<Long?>(null)
    val currentMbId: StateFlow<Long?> = _currentMbId

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun getMeasurementBooks(sapWorkKey: String): Flow<List<MeasurementBook>> {
        return measurementStorage.getMeasurementBooks(sapWorkKey)
    }

    fun createOrOpenMeasurementBook(sapWorkKey: String, mbNumber: String, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            if (mbNumber.isBlank()) {
                _error.value = "MB Number cannot be blank"
                return@launch
            }
            try {
                val mbId = measurementStorage.createOrGetMeasurementBook(sapWorkKey, mbNumber)
                _currentMbId.value = mbId
                _error.value = null
                onComplete(mbId)
            } catch (e: Exception) {
                _error.value = "Error creating MB: \${e.message}"
            }
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun getMeasurements(mbId: Long): Flow<List<Measurement>> {
        return measurementStorage.getMeasurements(mbId).map { list -> list.sortedByDescending { it.id } }
    }

    fun getBoqItems(sapWorkKey: String): Flow<List<BoqItem>> {
        // Find BOQ ID then get items
        return kotlinx.coroutines.flow.flow {
            val boq = boqStorage.getBOQ(sapWorkKey)
            if (boq != null) {
                boqStorage.getItemsForBoq(boq.id).collect { emit(it) }
            } else {
                emit(emptyList())
            }
        }
    }

    suspend fun getBoqItemBalance(boqItem: BoqItem): Double {
        val executedQty = measurementStorage.getTotalExecutedQuantity(boqItem.id)
        return boqItem.boqQuantity - executedQty
    }

    fun saveMeasurement(
        mbId: Long,
        boqItem: BoqItem,
        date: String,
        location: String,
        remark: String,
        number: Double,
        length: Double,
        breadth: Double,
        height: Double
    ) {
        viewModelScope.launch {
            if (date.isBlank()) {
                _error.value = "Date is mandatory"
                return@launch
            }
            if (location.isBlank()) {
                _error.value = "Location is mandatory"
                return@launch
            }
            if (remark.isBlank()) {
                _error.value = "Remark is mandatory"
                return@launch
            }

            val qty = number * length * breadth * height
            


            val measurement = Measurement(
                mbId = mbId,
                boqItemId = boqItem.id,
                date = date,
                location = location,
                remark = remark,
                number = number,
                length = length,
                breadth = breadth,
                height = height,
                quantity = qty
            )

            try {
                measurementStorage.addMeasurement(measurement)
                _error.value = null
            } catch (e: Exception) {
                _error.value = "Failed to save measurement"
            }
        }
    }

    
    @android.annotation.SuppressLint("NewApi")
    fun exportMBExcel(context: android.content.Context, sapWorkKey: String, mbId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val mb = dao.getMeasurementBookById(mbId)
                    val boq = dao.getBoqByWorkKey(sapWorkKey)
                    if (project != null && mb != null && boq != null) {
                        val boqItems = com.example.utils.BoqFileParser.sortForPcMc(dao.getBoqItems(boq.id).first())
                        val measurements = dao.getMeasurementsByMbId(mbId).first()
                        val workbook = org.apache.poi.xssf.usermodel.XSSFWorkbook()
                        val sheet = workbook.createSheet("Measurement Book")
                        val headerStyle = workbook.createCellStyle().apply {
                            val font = workbook.createFont(); font.bold = true; setFont(font)
                        }
                        val title = sheet.createRow(0); title.createCell(0).setCellValue("PCMC Measurement Book - ${mb.mbNumber}"); title.getCell(0).cellStyle = headerStyle
                        var rowNum = 2
                        val headers = listOf("Part", "SSR Code", "Item No", "Description", "Date", "Location", "Remark", "No", "L", "B", "D/H", "Quantity")
                        val headerRow = sheet.createRow(rowNum++)
                        headers.forEachIndexed { i, h -> headerRow.createCell(i).setCellValue(h); headerRow.getCell(i).cellStyle = headerStyle }
                        val byBoqItem = measurements.groupBy { it.boqItemId }
                        for (item in boqItems) {
                            val itemMeasurements = byBoqItem[item.id].orEmpty().sortedWith(compareBy({ it.date }, { it.id }))
                            for (m in itemMeasurements) {
                                val r = sheet.createRow(rowNum++)
                                r.createCell(0).setCellValue(item.part)
                                r.createCell(1).setCellValue(item.ssrCode)
                                r.createCell(2).setCellValue(item.itemNumber)
                                r.createCell(3).setCellValue(item.description)
                                r.createCell(4).setCellValue(m.date)
                                r.createCell(5).setCellValue(m.location)
                                r.createCell(6).setCellValue(m.remark)
                                r.createCell(7).setCellValue(m.number)
                                r.createCell(8).setCellValue(m.length)
                                r.createCell(9).setCellValue(m.breadth)
                                r.createCell(10).setCellValue(m.height)
                                r.createCell(11).setCellValue(m.quantity)
                            }
                            if (itemMeasurements.isNotEmpty()) {
                                val tr = sheet.createRow(rowNum++)
                                tr.createCell(0).setCellValue("TOTAL")
                                tr.createCell(1).setCellValue(item.ssrCode)
                                tr.createCell(11).setCellValue(itemMeasurements.sumOf { it.quantity })
                            }
                        }
                        headers.indices.forEach { i -> sheet.setColumnWidth(i, when (i) { 3,5,6 -> 18000; 4 -> 5000; 1,2 -> 5000; else -> 4500 }) }
                        val fileName = "MB_${mb.mbNumber.replace(Regex("[^A-Za-z0-9._-]"), "_")}_Excel.xlsx"
                        val values = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                            val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            if (uri == null) throw IllegalStateException("Failed to create download file")
                            context.contentResolver.openOutputStream(uri)?.use { workbook.write(it) } ?: throw IllegalStateException("Failed to open download stream")
                        } else {
                            val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            java.io.File(dir, fileName).outputStream().use { workbook.write(it) }
                        }
                        workbook.close()
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Excel file saved to Downloads: $fileName") }
                    } else {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Missing project or MB data for export") }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult("Export failed: ${e.message}") }
                }
            }
        }
    }



    fun exportMB(context: android.content.Context, sapWorkKey: String, mbId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val mb = dao.getMeasurementBookById(mbId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && mb != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val measurements = dao.getMeasurementsByMbId(mbId).first()
                    val path = com.example.utils.PdfDocketGenerator.generateMbPdfDocket(context, project, mb, boqItems, measurements)
                    onResult(path)
                } else {
                    onResult("Missing project or MB data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }
}

class MeasurementViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MeasurementViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MeasurementViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
