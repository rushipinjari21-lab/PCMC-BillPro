package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDao
import com.example.data.Project
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProjectViewModel(private val dao: AppDao) : ViewModel() {

    val projects: StateFlow<List<Project>> = dao.getAllProjects()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun saveProject(project: Project) {
        viewModelScope.launch {
            dao.insertProject(project)
        }
    }

    fun deleteProject(sapWorkKey: String) {
        viewModelScope.launch {
            dao.deleteProject(sapWorkKey)
        }
    }

    suspend fun getProject(sapWorkKey: String): Project? {
        return dao.getProjectByWorkKey(sapWorkKey)
    }
}

class ProjectViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProjectViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProjectViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
