import re

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    content = f.read()

# Add dateStr state
content = content.replace(
    'var location by remember { mutableStateOf("") }',
    'val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())\n    var dateStr by remember { mutableStateOf(sdf.format(java.util.Date())) }\n    var location by remember { mutableStateOf("") }'
)

# Add Date field to UI
content = content.replace(
    '// Measurement Form',
    '// Measurement Form\n            OutlinedTextField(\n                value = dateStr,\n                onValueChange = { dateStr = it },\n                label = { Text("Date *") },\n                modifier = Modifier.fillMaxWidth()\n            )'
)

# Update saveMeasurement call
content = content.replace(
    'mbId = mbId,\n                            boqItem = item,\n                            location = location,',
    'mbId = mbId,\n                            boqItem = item,\n                            date = dateStr,\n                            location = location,'
)

# Don't reset location and remark
content = content.replace(
    '// Reset simple fields\n                        location = ""\n                        remark = ""',
    '// Reset simple fields (kept date, location, remark to avoid retyping)'
)

# Add Date to MeasurementRowCard
content = content.replace(
    'Text("Loc: ${measurement.location} | Rem: ${measurement.remark}", style = MaterialTheme.typography.bodySmall)',
    'Text("Date: ${measurement.date} | Loc: ${measurement.location} | Rem: ${measurement.remark}", style = MaterialTheme.typography.bodySmall)'
)

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(content)
