import re

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "r") as f:
    content = f.read()

# Replace the messy line with the correct append statements
broken = 'append(".list-content { flex: 1; }            append(\\".no-border td { border: none !important; padding: 4px; }\\")")'
good = 'append(".list-content { flex: 1; }")\n            append(".no-border td { border: none !important; padding: 4px; }")'

content = content.replace(broken, good)

# In case it was formatted slightly differently:
broken2 = 'append(".list-content { flex: 1; }            append(".no-border td { border: none !important; padding: 4px; }")")'
content = content.replace(broken2, good)

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "w") as f:
    f.write(content)

print("Fixed syntax 2")
