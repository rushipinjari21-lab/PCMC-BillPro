import re

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

ra_bill_excel = """
    @android.annotation.SuppressLint("NewApi")
    fun exportRaBillExcel(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && bill != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val raBillItems = dao.getRaBillItems(billId).first()
                    
                    val csv = StringBuilder()
                    csv.append("Item No,Description,Unit,Rate,BOQ Qty,BOQ Amount,Previous Qty,Previous Amt,This Bill Qty,This Bill Amt,Up to Date Qty,Up to Date Amt\\n")
                    
                    for (item in boqItems) {
                        val billItem = raBillItems.find { it.boqItemId == item.id }
                        val prevQty = billItem?.previousQuantity ?: 0.0
                        val thisQty = billItem?.thisBillQuantity ?: 0.0
                        val upToDateQty = prevQty + thisQty
                        
                        val prevAmt = prevQty * item.rate
                        val thisAmt = thisQty * item.rate
                        val upToDateAmt = upToDateQty * item.rate
                        val boqAmt = item.quantity * item.rate
                        
                        val desc = item.description.replace(",", ";").replace("\\n", " ")
                        csv.append("${item.itemNumber},$desc,${item.unit},${item.rate},${item.quantity},$boqAmt,$prevQty,$prevAmt,$thisQty,$thisAmt,$upToDateQty,$upToDateAmt\\n")
                    }
                    
                    val fileName = "RABill_${bill.billNumber}_Excel.csv"
                    
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(csv.toString().toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel (CSV) file saved to Downloads: $fileName")
                        } ?: run {
                            onResult("Failed to create file")
                        }
                    } else {
                        try {
                            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            val file = java.io.File(downloadsDir, fileName)
                            file.outputStream().use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(csv.toString().toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel (CSV) file saved to Downloads: $fileName")
                        } catch (e: Exception) {
                            onResult("Failed to save file: ${e.message}")
                        }
                    }
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Error: ${e.message}")
            }
        }
    }
"""

if "fun exportRaBillExcel" not in content:
    content = content.replace("fun exportRaBill(", ra_bill_excel + "\n    fun exportRaBill(")

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
