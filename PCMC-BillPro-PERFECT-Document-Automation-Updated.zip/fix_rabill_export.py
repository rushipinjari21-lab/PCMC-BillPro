import re

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

replacement = """
    @android.annotation.SuppressLint("NewApi")
    fun exportRaBillExcel(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val project = dao.getProjectByWorkKey(sapWorkKey)
                    val bill = dao.getRaBillById(billId)
                    val boq = dao.getBoqByWorkKey(sapWorkKey)
                    if (project != null && bill != null && boq != null) {
                        val boqItems = dao.getBoqItems(boq.id).first()
                        val raBillItems = dao.getRaBillItems(billId).first()
                        
                        val workbook = org.apache.poi.xssf.usermodel.XSSFWorkbook()
                        val sheet = workbook.createSheet("RA Bill")
                        
                        var rowNum = 0
                        val headerRow = sheet.createRow(rowNum++)
                        val headers = listOf("Item No", "Description", "Unit", "Rate", "BOQ Qty", "BOQ Amount", "Previous Qty", "Previous Amt", "This Bill Qty", "This Bill Amt", "Up to Date Qty", "Up to Date Amt")
                        for ((index, header) in headers.withIndex()) {
                            val cell = headerRow.createCell(index)
                            cell.setCellValue(header)
                            val style = workbook.createCellStyle()
                            val font = workbook.createFont()
                            font.bold = true
                            style.setFont(font)
                            cell.cellStyle = style
                        }
                        
                        for (item in boqItems) {
                            val billItem = raBillItems.find { it.boqItemId == item.id }
                            val prevQty = billItem?.previousQuantity ?: 0.0
                            val thisQty = billItem?.currentQuantity ?: 0.0
                            val upToDateQty = prevQty + thisQty
                            
                            val prevAmt = prevQty * item.rate
                            val thisAmt = thisQty * item.rate
                            val upToDateAmt = upToDateQty * item.rate
                            val boqAmt = item.boqQuantity * item.rate
                            
                            val itemRow = sheet.createRow(rowNum++)
                            itemRow.createCell(0).setCellValue(item.itemNumber)
                            itemRow.createCell(1).setCellValue(item.description)
                            itemRow.createCell(2).setCellValue(item.unit)
                            itemRow.createCell(3).setCellValue(item.rate)
                            itemRow.createCell(4).setCellValue(item.boqQuantity)
                            itemRow.createCell(5).setCellValue(boqAmt)
                            itemRow.createCell(6).setCellValue(prevQty)
                            itemRow.createCell(7).setCellValue(prevAmt)
                            itemRow.createCell(8).setCellValue(thisQty)
                            itemRow.createCell(9).setCellValue(thisAmt)
                            itemRow.createCell(10).setCellValue(upToDateQty)
                            itemRow.createCell(11).setCellValue(upToDateAmt)
                        }
                        
                        val fileName = "RABill_${bill.billNumber}_Excel.xlsx"
                        
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                            val contentValues = android.content.ContentValues().apply {
                                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                            }
                            
                            val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                            uri?.let {
                                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                    workbook.write(outputStream)
                                }
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Excel file saved to Downloads: $fileName")
                                }
                            } ?: run {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Failed to create file")
                                }
                            }
                        } else {
                            try {
                                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                                val file = java.io.File(downloadsDir, fileName)
                                file.outputStream().use { outputStream ->
                                    workbook.write(outputStream)
                                }
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Excel file saved to Downloads: $fileName")
                                }
                            } catch (e: Exception) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    onResult("Failed to save file: ${e.message}")
                                }
                            }
                        }
                        workbook.close()
                    } else {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                            onResult("Missing project or Bill data")
                        }
                    }
                } catch (e: Exception) {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onResult("Error: ${e.message}")
                    }
                }
            }
        }
    }
"""

start_str = '@android.annotation.SuppressLint("NewApi")\n    fun exportRaBillExcel('
end_str = '}\n        }\n    }'

start_idx = content.find(start_str)
if start_idx != -1:
    end_idx = content.find(end_str, start_idx) + len(end_str)
    content = content[:start_idx] + replacement.strip() + "\n\n" + content[end_idx:]

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)

