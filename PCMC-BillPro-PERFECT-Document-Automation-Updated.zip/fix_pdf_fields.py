import re

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'r') as f:
    content = f.read()

# Fix RaBillItem executedQuantity -> totalQuantity
content = content.replace("item.executedQuantity", "item.totalQuantity")

# Fix RaBill percentages
content = content.replace(
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>GST (${raBill.gstPercent}%)</b></td><td><b>${String.format("%.2f", raBill.gstAmount)}</b></td></tr>")',
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>GST</b></td><td><b>${String.format("%.2f", raBill.gstAmount)}</b></td></tr>")'
)
content = content.replace(
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>Labour Cess (${raBill.labourCessPercent}%)</b></td><td><b>-${String.format("%.2f", raBill.labourCess)}</b></td></tr>")',
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>Labour Cess</b></td><td><b>-${String.format("%.2f", raBill.labourCess)}</b></td></tr>")'
)
content = content.replace(
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>Security Deposit (${raBill.sdPercent}%)</b></td><td><b>-${String.format("%.2f", raBill.securityDeposit)}</b></td></tr>")',
    'append("<tr><td colspan=\'5\' style=\'text-align:right\'><b>Security Deposit</b></td><td><b>-${String.format("%.2f", raBill.securityDeposit)}</b></td></tr>")'
)

# Fix QuantityVariationItem fields
content = content.replace("item.executedQuantity", "item.finalExecutedQuantity")
content = content.replace("item.excessQuantity", "if (item.variationQuantity > 0) item.variationQuantity else 0.0")
content = content.replace("item.savingQuantity", "if (item.variationQuantity < 0) -item.variationQuantity else 0.0")

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(content)
