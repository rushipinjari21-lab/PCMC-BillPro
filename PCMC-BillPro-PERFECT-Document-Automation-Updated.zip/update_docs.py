import os

path = "app/src/main/java/com/example/utils/PdfDocketGenerator.kt"
with open(path, "r") as f:
    content = f.read()

doc3_start = content.find('// Doc 3: DE 100%')
doc5_start = content.find('// Doc 5: Payment Schedule')

if doc3_start != -1 and doc5_start != -1:
    new_docs = """// Doc 3: DE 100%
            val workRate = project.remarks.ifBlank { "____ %" }
            val adminApprovalAmt = formatAmt(project.estimateAmount)
            val tenderAmt = formatAmt(project.agreementAmount)
            
            val doc3 = ""\"<div class='page-break'>
                <h2 class='center'>दाखला</h2>
                <p>१) <b>ठेकेदाराचे नाव</b> – \$contractorName</p>
                <p>२) <b>कामाचे नाव</b> – \$workName</p>
                <p>३) <b>प्रशासकीय मान्यता</b> – रक्कम रुपये \$adminApprovalAmt/-</p>
                <p>४) <b>निविदा रक्कम</b> – रक्कम रुपये \$tenderAmt/-</p>
                <p>५) <b>निविदा क्रमांक</b> – \$tenderNo</p>
                <p>६) <b>कामाचा दर</b> – \$workRate</p>
                <p>७) <b>कामाची मुळ मुदत</b> – १२ महिने</p>
                <p>८) <b>कामाचे बिल क्रमांक</b> – \${raBill.billNumber}</p>
                <br>
                <p>प्रस्तुत कामाची मी <b>\$deName</b>, उप अभियंता विभाग स्थापत्य <b>\$zone</b> १००% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>
                <br><br><br>
                <div class='right'>
                    <p><b>उप अभियंता</b><br>स्थापत्य \$zone<br>पिं.चिं.मनपा</p>
                </div>
            </div>""\"
            
            // Doc 4: EE 25%
            val doc4 = ""\"<div class='page-break'>
                <h2 class='center'>दाखला</h2>
                <p>१) <b>ठेकेदाराचे नाव</b> – \$contractorName</p>
                <p>२) <b>कामाचे नाव</b> – \$workName</p>
                <p>३) <b>प्रशासकीय मान्यता</b> – रक्कम रुपये \$adminApprovalAmt/-</p>
                <p>४) <b>निविदा रक्कम</b> – रक्कम रुपये \$tenderAmt/-</p>
                <p>५) <b>निविदा क्रमांक</b> – \$tenderNo</p>
                <p>६) <b>कामाचा दर</b> – \$workRate</p>
                <p>७) <b>कामाची मुळ मुदत</b> – १२ महिने</p>
                <p>८) <b>कामाचे बिल क्रमांक</b> – \${raBill.billNumber}</p>
                <br>
                <p>प्रस्तुत कामाची मी <b>\$eeName</b>, कार्यकारी अभियंता विभाग स्थापत्य <b>\$zone</b> २५% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>
                <br><br><br>
                <div class='right'>
                    <p><b>कार्यकारी अभियंता</b><br>स्थापत्य \$zone<br>पिं.चिं.मनपा</p>
                </div>
            </div>""\"
            
            """
    
    content = content[:doc3_start] + new_docs + content[doc5_start:]
    
with open(path, "w") as f:
    f.write(content)

