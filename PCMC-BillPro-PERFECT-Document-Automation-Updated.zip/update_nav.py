import re

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'onNavigateBack: () -> Unit\n)',
    'onNavigateBack: () -> Unit,\n    onNavigateToRaBill: () -> Unit\n)'
)

content = content.replace(
    'HorizontalDivider()\n            Text("Measurements in this MB", style = MaterialTheme.typography.titleMedium)',
    '''HorizontalDivider()
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Measurements in this MB", style = MaterialTheme.typography.titleMedium)
                Button(onClick = onNavigateToRaBill) {
                    Text("Complete & Generate RA Bill")
                }
            }'''
)

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(content)

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'r') as f:
    nav_content = f.read()

nav_content = nav_content.replace(
    'onNavigateBack = { navController.popBackStack() }\n            )',
    'onNavigateBack = { navController.popBackStack() },\n                onNavigateToRaBill = { navController.navigate(Screen.RaBill.createRoute(sapWorkKey)) }\n            )'
)

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'w') as f:
    f.write(nav_content)
