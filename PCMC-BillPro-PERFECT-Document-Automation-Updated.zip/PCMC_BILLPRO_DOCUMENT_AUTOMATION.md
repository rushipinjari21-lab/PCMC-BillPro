# PCMC BillPro - Document Automation Update

This version updates the existing Android/Kotlin project so the Project record acts as the single master source for PCMC document generation.

## Automatic document package

The Certificates screen now generates the complete eight-document package:

1. पहिले आर. ए. बिल / 20-point scrutiny sheet
2. दाखला - उप अभियंता 100% मोजमाप तपासणी
3. दाखला - कार्यकारी अभियंता 25% मोजमाप तपासणी
4. Payment Schedule
5. दाखला - site verification / original site work
6. दाखला - labour compliance
7. GIS Mapping दाखला
8. कार्यालयीन टिपणी

## Shared fields

The following Project fields are entered once and reused across generated documents:

- Work name
- Contractor name/address
- Tender number and tender amount
- Administrative approval amount/reference
- Technical sanction amount/reference
- Tender rate type and percentage (Below / Above / At Par)
- Work order date and duration
- Advertisement date
- Tender acceptance date
- Ward / Prabhag
- Regional office / subdivision
- Contractor PAN/GST
- Engineer / Deputy Engineer / Executive Engineer names

## Measurement Book rules

- Date is mandatory.
- Location is mandatory.
- Remark is mandatory.
- SSR Code is inherited from BOQ.
- MB screen is newest-first.
- Official MB PDF/Excel export is Part A -> Part B -> Part C -> Part D, then SSR Code ascending.
- Location and remark are retained in exported measurement rows.

## Reference material

The `reference_documents` directory contains the supplied PCMC RA Bill, MB and document screenshots used as the formatting/text reference for this update.
