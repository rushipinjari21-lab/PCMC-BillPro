import re

with open('./app/src/main/java/com/example/ui/variation/QuantityVariationScreen.kt', 'r') as f:
    content = f.read()

# Pass context to the view
content = content.replace(
'''                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(variations, key = { it.id }) { variation ->
                            VariationCard(variation) {
                                selectedVariation = variation
                            }
                        }
                    }''',
'''                    val context = androidx.compose.ui.platform.LocalContext.current
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(variations, key = { it.id }) { variation ->
                            VariationCard(
                                variation = variation,
                                onClick = { selectedVariation = variation },
                                onDownloadClick = {
                                    viewModel.exportQuantityVariation(context, sapWorkKey, variation.id) { result ->
                                        android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        }
                    }'''
)

# Update VariationCard definition
content = content.replace(
    'fun VariationCard(variation: QuantityVariation, onClick: () -> Unit) {',
    'fun VariationCard(variation: QuantityVariation, onClick: () -> Unit, onDownloadClick: () -> Unit) {'
)

# Update VariationCard UI to include the download button
content = content.replace(
'''            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Status: ${variation.status}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(variation.createdDate))
                Text(text = dateStr, style = MaterialTheme.typography.bodySmall)
            }''',
'''            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Status: ${variation.status}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    IconButton(onClick = onDownloadClick) {
                        Icon(androidx.compose.material.icons.Icons.Default.Download, contentDescription = "Export")
                    }
                }
                val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(variation.createdDate))
                Text(text = dateStr, style = MaterialTheme.typography.bodySmall)
            }'''
)

# Ensure Icons.Default.Download is imported
if 'androidx.compose.material.icons.filled.Download' not in content:
    content = content.replace('import androidx.compose.material.icons.filled.Add', 'import androidx.compose.material.icons.filled.Add\nimport androidx.compose.material.icons.filled.Download')

with open('./app/src/main/java/com/example/ui/variation/QuantityVariationScreen.kt', 'w') as f:
    f.write(content)
