import re

with open('./app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'r') as f:
    content = f.read()

# Remove the validation block
to_remove = """            // Validation for exceeding BOQ balance (Warning vs Hard Block - let's block if strict)
            val balance = getBoqItemBalance(boqItem)
            if (qty > balance) {
                _error.value = "Error: Measurement (${String.format("%.2f", qty)}) exceeds available BOQ balance (${String.format("%.2f", balance)})"
                return@launch
            }"""

content = content.replace(to_remove, "")

with open('./app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'w') as f:
    f.write(content)
