with open("app/src/main/java/com/example/viewmodel/RaBillViewModel.kt", "r") as f:
    content = f.read()

import re
content = re.sub(r'fun exportCertificatesToWord\(', '@android.annotation.SuppressLint("NewApi")\n    fun exportCertificatesToWord(', content)
content = re.sub(r'fun exportRaBillToPdf\(', '@android.annotation.SuppressLint("NewApi")\n    fun exportRaBillToPdf(', content)
content = re.sub(r'fun exportCertificatesToPdf\(', '@android.annotation.SuppressLint("NewApi")\n    fun exportCertificatesToPdf(', content)

with open("app/src/main/java/com/example/viewmodel/RaBillViewModel.kt", "w") as f:
    f.write(content)
