import re

with open('./app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

export_function = """
    fun exportRaBill(context: android.content.Context, sapWorkKey: String, billId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && bill != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val raBillItems = dao.getRaBillItems(billId).first()
                    val path = com.example.utils.ExcelExport.exportRaBillToCsv(context, project, bill, boqItems, raBillItems)
                    onResult("Exported to $path")
                } else {
                    onResult("Missing project or Bill data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }
"""

content = content.replace("    fun clearError() {", export_function + "\n    fun clearError() {")

with open('./app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
