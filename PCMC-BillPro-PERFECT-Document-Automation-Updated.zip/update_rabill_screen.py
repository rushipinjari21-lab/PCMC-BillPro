import re

with open('app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    content = f.read()

ra_bill_word = """                OutlinedButton(
                    onClick = { 
                        viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RA Bill")
                }"""
                
ra_bill_excel = """                OutlinedButton(
                    onClick = { 
                        viewModel.exportRaBillExcel(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(androidx.compose.material.icons.filled.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RA Bill CSV")
                }"""

if "exportRaBillExcel" not in content:
    content = content.replace(ra_bill_word, ra_bill_word + "\n" + ra_bill_excel)

with open('app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(content)
