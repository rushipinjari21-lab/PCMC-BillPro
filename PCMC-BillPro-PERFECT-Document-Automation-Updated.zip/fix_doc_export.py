import re

with open('app/src/main/java/com/example/utils/DocumentExportService.kt', 'r') as f:
    content = f.read()

content = content.replace('project.estimatedAmount', 'project.estimateAmount')
content = content.replace('project.tenderAmount', 'project.agreementAmount')
content = content.replace('project.tenderNo', 'project.tenderNumber')
content = content.replace('project.tenderRate', 'project.remarks')

with open('app/src/main/java/com/example/utils/DocumentExportService.kt', 'w') as f:
    f.write(content)
