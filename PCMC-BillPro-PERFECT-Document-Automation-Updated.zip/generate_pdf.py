import os

code = """package com.example.utils

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Log
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.*

object ExcelExport {
    
    private var activeWebView: WebView? = null
    
    private suspend fun printHtml(context: Context, htmlContent: String, jobName: String, landscape: Boolean = false) {
        withContext(Dispatchers.Main) {
            try {
                val webView = WebView(context)
                activeWebView = webView
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                        val printAdapter = view.createPrintDocumentAdapter(jobName)
                        val builder = PrintAttributes.Builder()
                        if (landscape) {
                            builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                        } else {
                            builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4.asPortrait())
                        }
                        printManager.print(jobName, printAdapter, builder.build())
                    }
                }
                webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null)
            } catch (e: Exception) {
                Log.e("PdfExport", "Error generating PDF", e)
            }
        }
    }

    suspend fun exportMbToCsv(
        context: Context,
        project: Project,
        mb: MeasurementBook,
        boqItems: List<BoqItem>,
        measurements: List<Measurement>
    ): String {
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>")
            append("@page { size: A4 portrait; margin: 10mm; }")
            append("body { font-family: sans-serif; font-size: 12px; line-height: 1.4; }")
            append(".page-break { page-break-after: always; }")
            append(".center { text-align: center; }")
            append(".right { text-align: right; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px; }")
            append("th, td { border: 1px solid black; padding: 4px; text-align: center; }")
            append(".left { text-align: left; }")
            append(".header-box { border: 1px solid black; padding: 10px; margin-bottom: 20px; }")
            append("</style></head><body>")

            // Page 1: Cover
            append("<div class='page-break'>")
            append("<h2 class='center'>पिंपरी चिंचवड महानगरपालिका<br>पिंपरी - ४११ ०१८<br>मोजमाप पुस्तक<br>नमुना क्र. ४५, सौ. बां.वि. ९</h2>")
            append("<br><br><br>")
            append("<table>")
            append("<tr><td class='left' width='30%'>मोजमाप पुस्तक क्रमांक<br>मोजमाप पुस्तक वापरणाऱ्याचे नाव</td><td class='left'>पान क्र. ________ ते ________<br>१) कनिष्ठ अभियंता : श्री / श्रीमती -: ${project.engineerName}<br><br>२) उप अभियंता : श्री / श्रीमती -: ________________________<br><br>३) कार्यकारी अभियंता : श्री / श्रीमती -: ________________________</td></tr>")
            append("<tr><td class='left'>विभागाचे नाव:</td><td class='left'>${project.department} - ${project.division}</td></tr>")
            append("<tr><td class='left'>Project No. :</td><td class='left'>${project.sapWorkKey}</td></tr>")
            append("<tr><td class='left'>MB No. :</td><td class='left'>${mb.mbNumber}</td></tr>")
            append("</table>")
            
            append("<table>")
            append("<tr><th>अ.क्र.</th><th>कामाचे नाव</th><th>निविदा क्र.</th><th>पान क्र.</th><th>बिल प्रकार / बिल क्र. व दिनांक</th><th>ठेकेदाराचे नाव</th></tr>")
            append("<tr><td>1</td><td class='left'>${project.workName}</td><td>${project.tenderNumber}</td><td></td><td></td><td class='left'>${project.contractorName}</td></tr>")
            append("</table>")
            append("</div>")

            // Page 2: Issue
            append("<div class='page-break'>")
            append("<br><br><p>This M.B. Issued to Shri ________________________________________________</p>")
            append("<p>_______________________________________________________________Dy. Engg.</p>")
            append("<p>Ward Name: ____________________________</p>")
            append("<p>Date: ________________</p>")
            append("<br><br><div class='right'><p>Accounts Officer<br>P.C.M.C. Engg. Section</p></div>")
            append("</div>")

            // Page 3: Record Entry
            append("<div class='page-break'>")
            append("<h3 class='center'>RECORD ENTRY</h3>")
            append("<table>")
            append("<tr><th width='15%'>Date</th><th width='35%'>Description</th><th>No</th><th>L</th><th>B</th><th>AvgB</th><th>H</th><th>AvgH</th><th>Qty.</th><th>Total Qty.</th></tr>")
            
            val groupedMeas = measurements.groupBy { it.boqItemId }
            for ((boqId, measList) in groupedMeas) {
                val boq = boqItems.find { it.id == boqId }
                if (boq != null) {
                    append("<tr><td colspan='10' class='left'><b>Item No. ${boq.itemNumber} - ${boq.description}</b></td></tr>")
                    var totalQty = 0.0
                    for (m in measList) {
                        append("<tr>")
                        append("<td>${m.date}</td>")
                        append("<td class='left'>${m.location}</td>")
                        append("<td>${String.format("%.3f", m.number)}</td>")
                        append("<td>${String.format("%.3f", m.length)}</td>")
                        append("<td>${String.format("%.3f", m.breadth)}</td>")
                        append("<td></td>")
                        append("<td>${String.format("%.3f", m.height)}</td>")
                        append("<td></td>")
                        append("<td>${String.format("%.3f", m.quantity)}</td>")
                        append("<td></td>")
                        append("</tr>")
                        totalQty += m.quantity
                    }
                    append("<tr><td colspan='8' class='right'><b>Total</b></td><td></td><td><b>${String.format("%.3f", totalQty)}</b></td></tr>")
                }
            }
            append("</table>")
            append("</div>")
            
            // Abstract
            append("<div class='page-break'>")
            append("<h3 class='center'>Abstract</h3>")
            append("<table>")
            append("<tr><th>Item No.</th><th>Description</th><th>Qty</th><th>Tender Rate</th><th>Amount</th></tr>")
            for ((boqId, measList) in groupedMeas) {
                val boq = boqItems.find { it.id == boqId }
                if (boq != null) {
                    val totalQty = measList.sumOf { it.quantity }
                    val amount = totalQty * boq.rate
                    append("<tr>")
                    append("<td>${boq.itemNumber}</td>")
                    append("<td class='left'>${boq.description}</td>")
                    append("<td>${String.format("%.3f", totalQty)}</td>")
                    append("<td>${String.format("%.2f", boq.rate)}</td>")
                    append("<td>${String.format("%.2f", amount)}</td>")
                    append("</tr>")
                }
            }
            append("</table>")
            append("</div>")

            append("</body></html>")
        }
        printHtml(context, html, "MB_${mb.mbNumber}", landscape = false)
        return "Opening PDF Preview..."
    }

    suspend fun exportRaBillToCsv(
        context: Context,
        project: Project,
        raBill: RaBill,
        boqItems: List<BoqItem>,
        raBillItems: List<RaBillItem>
    ): String {
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>")
            append("@page { size: A4 landscape; margin: 10mm; }")
            append("body { font-family: sans-serif; font-size: 11px; line-height: 1.3; }")
            append(".page-break { page-break-after: always; }")
            append(".center { text-align: center; }")
            append(".right { text-align: right; }")
            append(".left { text-align: left; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 5px; font-size: 10px; }")
            append("th, td { border: 1px solid black; padding: 4px; text-align: right; }")
            append("th { background-color: #f2f2f2; text-align: center; }")
            append(".th-left { text-align: left; }")
            append("</style></head><body>")

            // Page 1: Cover
            append("<div class='page-break' style='column-count: 2; column-gap: 20px; font-size: 12px;'>")
            append("<h3 class='center' style='column-span: all;'>Pimpri-Chinchwad Muncipal Corporation, Pimpri 411 018</h3>")
            append("<div style='border: 1px solid black; padding: 10px; break-inside: avoid;'>")
            append("<p>Administrative Approval:- Rs. ${project.estimateAmount}</p>")
            append("<p>Technical Sanction:- Rs. ${project.estimateAmount}</p>")
            append("<p>Tendor Amount : Rs. ${project.agreementAmount}</p>")
            append("<p>Total Rs : Rs. ${String.format("%.2f", raBill.grossAmount)}</p>")
            append("<p>Tender No:- ${project.tenderNumber}</p>")
            append("<br><br><p><b>JUNIOR ENGINEER</b></p><br><p><b>DEPUTY ENGINEER</b></p><br><p>Checked<br><br>Accounts clerk &nbsp;&nbsp;&nbsp;&nbsp; Divisional Accountant</p>")
            append("</div>")
            
            append("<div style='border: 1px solid black; padding: 10px; break-inside: avoid;'>")
            append("<p>DIVISION: ${project.division}</p>")
            append("<p>SUB-DIVISION: ${project.subDivision}</p>")
            append("<p>Department: ${project.department}</p>")
            append("<p><b>Running Account Bill: ${raBill.billNumber}</b></p>")
            append("<p><b>Name of the Contractor or Suppliers:-</b><br>${project.contractorName}</p>")
            append("<p><b>Name of Work:-</b><br>${project.workName}</p>")
            append("<p>Date of written order to commence work: ${project.workOrderNumber}</p>")
            append("<br><p>Audited &nbsp;&nbsp;&nbsp;&nbsp; Review Superident</p><br><p>Auditor &nbsp;&nbsp;&nbsp;&nbsp; Gazetted Officer</p>")
            append("</div>")
            append("</div>")

            // Page 2: Part 1
            append("<div class='page-break'>")
            append("<h3 class='center'>Part 1- ACCOUNT OF WORK EXECUTED</h3>")
            append("<table>")
            append("<tr>")
            append("<th>Quantity<br>executed<br>upto previous<br>bill</th>")
            append("<th>Quantity<br>executed<br>since<br>Previous Bill</th>")
            append("<th>Quantity<br>executed upto<br>date</th>")
            append("<th class='th-left'>Description Of Work</th>")
            append("<th>Tendor Rate</th>")
            append("<th>Proposed Rate</th>")
            append("<th>Unit</th>")
            append("<th>Total Upto<br>date</th>")
            append("<th>Since previous<br>Bill</th>")
            append("<th>Upto previous<br>bill</th>")
            append("</tr>")
            
            var totalGross = 0.0
            raBillItems.forEach { item ->
                val boq = boqItems.find { it.id == item.boqItemId }
                val desc = boq?.description ?: ""
                val rate = boq?.rate ?: 0.0
                val unit = boq?.unit ?: ""
                
                val currentAmt = item.currentQuantity * rate
                val prevAmt = item.previousQuantity * rate
                val totalAmt = item.totalQuantity * rate
                totalGross += totalAmt
                
                append("<tr>")
                append("<td>${String.format("%.3f", item.previousQuantity)}</td>")
                append("<td>${String.format("%.3f", item.currentQuantity)}</td>")
                append("<td>${String.format("%.3f", item.totalQuantity)}</td>")
                append("<td class='left'>${boq?.itemNumber} $desc</td>")
                append("<td>${String.format("%.2f", rate)}</td>")
                append("<td>${String.format("%.2f", rate)}</td>")
                append("<td class='center'>$unit</td>")
                append("<td>${String.format("%.2f", totalAmt)}</td>")
                append("<td>${String.format("%.2f", currentAmt)}</td>")
                append("<td>${String.format("%.2f", prevAmt)}</td>")
                append("</tr>")
            }
            append("<tr><td colspan='7' class='right'><b>TOTAL Rs</b></td><td><b>${String.format("%.2f", totalGross)}</b></td><td></td><td></td></tr>")
            append("</table>")
            append("</div>")

            // Page 3: Part IV
            append("<div class='page-break'>")
            append("<h3 class='center'>Part IV Memorandum Of Payments</h3>")
            append("<table>")
            append("<tr><td class='left' width='70%'>1. Total value of work actually measured as per part I</td><td><b>Rs. ${String.format("%.2f", raBill.grossAmount)}</b></td></tr>")
            append("<tr><td class='left' colspan='2'><b>Payments now to be made as detailed below -</b></td></tr>")
            append("<tr><td class='left'>1 Security Deposit</td><td>Rs. ${String.format("%.2f", raBill.securityDeposit)}</td></tr>")
            append("<tr><td class='left'>2 GST Amount</td><td>Rs. ${String.format("%.2f", raBill.gstAmount)}</td></tr>")
            append("<tr><td class='left'>3 Labour Cess</td><td>Rs. ${String.format("%.2f", raBill.labourCess)}</td></tr>")
            append("<tr><td class='left'>4 Other Recoveries</td><td>Rs. ${String.format("%.2f", raBill.otherRecoveries)}</td></tr>")
            
            val totalDeductions = raBill.securityDeposit + raBill.gstAmount + raBill.labourCess + raBill.otherRecoveries
            
            append("<tr><td class='left'><b>Total Deductions</b></td><td><b>Rs. ${String.format("%.2f", totalDeductions)}</b></td></tr>")
            append("<tr><td class='left'><b>Net Payable Amount</b></td><td><b>Rs. ${String.format("%.2f", raBill.netPayable)}</b></td></tr>")
            append("</table>")
            append("<br><br><br><p class='right'><b>Full Signature of Contractor</b></p>")
            append("</div>")

            append("</body></html>")
        }
        printHtml(context, html, "RABill_${raBill.billNumber}", landscape = true)
        return "Opening PDF Preview..."
    }

    suspend fun exportQuantityVariationToCsv(
        context: Context,
        project: Project,
        variation: QuantityVariation,
        boqItems: List<BoqItem>,
        qvItems: List<QuantityVariationItem>
    ): String {
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>")
            append("@page { size: A4 portrait; margin: 10mm; }")
            append("body { font-family: sans-serif; font-size: 11px; line-height: 1.4; }")
            append(".center { text-align: center; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 10px; }")
            append("th, td { border: 1px solid black; padding: 5px; text-align: center; }")
            append(".left { text-align: left; }")
            append("</style></head><body>")
            
            append("<h2 class='center'>Pimpri Chinchwad Municipal Corporation, Pimpri - 18<br>C Zone Office, Civil Department</h2>")
            append("<p class='center'><b>Name of Work -</b> ${project.workName}<br><b>Agency Name -</b> ${project.contractorName}<br><b>Tender No.</b> ${project.tenderNumber}</p>")
            append("<h3 class='center'>Quantity Variation Sheet</h3>")
            
            append("<table>")
            append("<tr><th rowspan='2'>Item<br>No.</th><th rowspan='2' class='left'>Description</th><th rowspan='2'>Unit</th><th colspan='3'>As per Tender</th><th colspan='3'>As Executed</th></tr>")
            append("<tr><th>Tender<br>quantity</th><th>Rate</th><th>Amount</th><th>Qty. As<br>Executed</th><th>Rate</th><th>Amount</th></tr>")
            
            var totalTenderAmt = 0.0
            var totalExecAmt = 0.0
            
            qvItems.forEach { item ->
                val boq = boqItems.find { it.id == item.boqItemId }
                val desc = boq?.description ?: ""
                val rate = boq?.rate ?: 0.0
                val unit = boq?.unit ?: ""
                val boqQty = boq?.boqQuantity ?: 0.0
                val tenderAmt = boqQty * rate
                val execAmt = item.finalExecutedQuantity * rate
                
                totalTenderAmt += tenderAmt
                totalExecAmt += execAmt
                
                append("<tr>")
                append("<td>${boq?.itemNumber}</td>")
                append("<td class='left'>$desc</td>")
                append("<td>$unit</td>")
                append("<td>${String.format("%.3f", boqQty)}</td>")
                append("<td>${String.format("%.2f", rate)}</td>")
                append("<td>${String.format("%.2f", tenderAmt)}</td>")
                append("<td>${String.format("%.3f", item.finalExecutedQuantity)}</td>")
                append("<td>${String.format("%.2f", rate)}</td>")
                append("<td>${String.format("%.2f", execAmt)}</td>")
                append("</tr>")
            }
            append("<tr><td colspan='5' style='text-align:right'><b>Total :-</b></td><td><b>${String.format("%.2f", totalTenderAmt)}</b></td><td colspan='2'></td><td><b>${String.format("%.2f", totalExecAmt)}</b></td></tr>")
            append("</table>")
            
            append("<br><br><br><br>")
            append("<div style='display: flex; justify-content: space-between; text-align: center;'>")
            append("<div><b>Junior Engineer</b><br>C Zone, Civil Dept.<br>P.C.M.C. Pimpri - 18</div>")
            append("<div><b>Deputy Engineer</b><br>C Zone, Civil Dept.<br>P.C.M.C. Pimpri - 18</div>")
            append("<div><b>Executive Engineer</b><br>C Zone, Civil Dept.<br>P.C.M.C. Pimpri - 18</div>")
            append("</div>")

            append("</body></html>")
        }
        printHtml(context, html, "QV_${project.sapWorkKey}", landscape = false)
        return "Opening PDF Preview..."
    }

    suspend fun exportCertificatesToCsv(
        context: Context,
        project: Project,
        raBill: RaBill
    ): String {
        val workName = project.workName
        val contractorName = project.contractorName
        
        val html = buildString {
            append("<html><head><meta charset='UTF-8'><style>")
            append("@page { size: A4 portrait; margin: 15mm; }")
            append("body { font-family: sans-serif; font-size: 14px; line-height: 1.6; }")
            append(".page-break { page-break-after: always; }")
            append(".center { text-align: center; }")
            append(".right { text-align: right; }")
            append("table { width: 100%; border-collapse: collapse; margin-top: 10px; }")
            append("th, td { border: 1px solid black; padding: 8px; text-align: center; }")
            append("</style></head><body>")
            
            // Page 1: First RA Bill Cover
            append("<div class='page-break'>")
            append("<h2 class='center'>पहिले आर. ए. बिल</h2>")
            append("<p>१) <b>कामाचे नाव –</b> $workName</p>")
            append("<p>२) <b>ठेकेदाराचे नाव –</b> $contractorName</p>")
            append("<p>३) <b>अंदाजपत्रकीय किंमत –</b> रक्कम रुपये ${project.estimateAmount}/-</p>")
            append("<p>४) <b>टेंडरची रक्कम –</b> रक्कम रुपये ${project.agreementAmount}/-</p>")
            append("<p>५) <b>कामाची प्रशासकीय मान्यता –</b> रक्कम रुपये ${project.estimateAmount}/-</p>")
            append("<p>६) <b>कामाचा आदेश दिलेला दिनांक –</b> ${project.workOrderNumber}</p>")
            append("<p>७) <b>कामाची मुदत –</b> </p>")
            append("<p>८) <b>प्रत्यक्ष काम संपलेली तारिख –</b> काम चालू आहे.</p>")
            append("<p>९) <b>पहिले आर. ए. बिलाची रक्कम रुपये –</b> र.रु. ${String.format("%.2f", raBill.netPayable)} /-</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between; text-align: center;'><div><b>कनिष्ठ अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८.</div><div><b>उप अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८..</div></div>")
            append("</div>")
            
            // Page 2: 100% Checking Certificate
            append("<div class='page-break'>")
            append("<h2 class='center'>दाखला</h2>")
            append("<p>१) <b>ठेकेदाराचे नाव –</b> $contractorName</p>")
            append("<p>२) <b>कामाचे नाव –</b> $workName</p>")
            append("<p>३) <b>प्रशासकीय मान्यता –</b> रक्कम रुपये ${project.estimateAmount}/-</p>")
            append("<p>४) <b>निविदा रक्कम –</b> रक्कम रुपये ${project.agreementAmount}/-</p>")
            append("<p>५) <b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<p>६) <b>कामाचे बिल क्रमांक –</b> ${raBill.billNumber}</p>")
            append("<p>प्रस्तुत कामाची मी <b>उप अभियंता</b> विभाग स्थापत्य क क्षत्रिय १००% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>")
            append("<br><br><br>")
            append("<div class='right'><p><b>उप अभियंता</b><br>स्थापत्य क क्षत्रिय<br>पिं.चिं.मनपा</p></div>")
            append("</div>")

            // Page 3: 25% Checking Certificate
            append("<div class='page-break'>")
            append("<h2 class='center'>दाखला</h2>")
            append("<p>१) <b>ठेकेदाराचे नाव –</b> $contractorName</p>")
            append("<p>२) <b>कामाचे नाव –</b> $workName</p>")
            append("<p>३) <b>प्रशासकीय मान्यता –</b> रक्कम रुपये ${project.estimateAmount}/-</p>")
            append("<p>४) <b>निविदा रक्कम –</b> रक्कम रुपये ${project.agreementAmount}/-</p>")
            append("<p>५) <b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<p>६) <b>कामाचे बिल क्रमांक –</b> ${raBill.billNumber}</p>")
            append("<p>प्रस्तुत कामाची मी <b>कार्यकारी अभियंता</b> विभाग स्थापत्य क क्षत्रिय २५% तपासणी केली असुन सदरच्या कामाचे इस्टीमेट तयार करताना केलेल्या सार्वजनिक बांधकाम विभागाकडील मानांकनानुसार योग्य व समाधानकारक आहे.</p>")
            append("<br><br><br>")
            append("<div class='right'><p><b>कार्यकारी अभियंता</b><br>स्थापत्य क क्षत्रिय<br>पिं.चिं.मनपा</p></div>")
            append("</div>")
            
            // Page 4: Payment Schedule
            append("<div class='page-break'>")
            append("<h2 class='center'>Payment Schedule</h2>")
            append("<p><b>कामाचे नाव –</b> $workName</p>")
            append("<p><b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<table><tr><th>Sr.<br>No.</th><th>Bill No.</th><th>Bill<br>Amount</th><th>Remark</th></tr>")
            append("<tr><td>1</td><td>${raBill.billNumber}</td><td>${String.format("%.2f", raBill.grossAmount)}</td><td>उपलब्ध तरतुदीप्रमाणे पहिले रनिंग देयक अदा करणेत येत आहे</td></tr></table>")
            append("<br><br><br>")
            append("<div class='right'><p><b>कार्यकारी अभियंता</b><br>स्थापत्य क क्षत्रिय<br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी, पुणे-१८</p></div>")
            append("</div>")
            
            // Page 5: No site change
            append("<div class='page-break'>")
            append("<h2 class='center'>दाखला</h2>")
            append("<p>१) <b>ठेकेदाराचे नाव –</b> $contractorName</p>")
            append("<p>२) <b>कामाचे नाव –</b> $workName</p>")
            append("<p>३) <b>निविदा रक्कम –</b> रक्कम रुपये ${project.agreementAmount}/-</p>")
            append("<p>४) <b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<p>प्रस्तुत काम अंदाजपत्रकानुसार त्याच जागेवर पुर्ण करणेत आलेले असून कोणताही स्थळ बदल करणेत आलेला नाही.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between; text-align: center;'><div><b>कनिष्ठ अभियंता</b><br>स्थापत्य क क्षत्रिय</div><div><b>उप अभियंता</b><br>स्थापत्य क क्षत्रिय</div></div>")
            append("</div>")

            // Page 6: Labor Laws
            append("<div class='page-break'>")
            append("<h3 class='center'>पिंपरी चिंचवड महानगरपालिका,<br>क क्षेत्रीय कार्यालय, स्थापत्य विभाग</h3>")
            append("<h2 class='center'>दाखला</h2>")
            append("<p><b>कामाचे नाव –</b> $workName</p>")
            append("<p><b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<p><b>ठेकेदाराचे नाव –</b> $contractorName</p>")
            append("<p>वरील कामकाजाबाबत ठेकेदार $contractorName यांनी प्रकरणी कंत्राटी कामगार (नियमन व निर्मूलन) अधिनियम १९७० मधील तरतूदींचे पालन केले आहे. तसेच किमान वेतन कायदा १९४८, कर्मचारी राज्या विमा कायदा १९४८, भविष्य निर्वाह निधी कायदा १९५२ इत्यादी कायदेशीर बाबींचे काटेकोरपणे पालन केले आहे. कंत्राटदाराने कामाचा व त्यावर काम करणा-या कामगारांचा विमा नॅशनल इंन्शुरन्स कं. लि., चिंचवड यांच्याकडे उतरवला आहे.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between;'><div><b>पर्यवेक्षकीय अधिकारी –</b><br>स्वाक्षरी –<br>पदनाम –</div><div><b>विभागप्रमुख / प्राधिकृत सक्षम अधिकारी</b><br>स्वाक्षरी –<br>पदनाम –</div></div>")
            append("<br><br><p>टिप – सदरचा दाखला संबंधित ठेकेदाराचे बिल अदा करताना प्रकरणी समाविष्ट करणे बंधनकारक आहे.</p>")
            append("</div>")
            
            // Page 7: GIS Mapping
            append("<div class='page-break'>")
            append("<h3 class='center'>पिंपरी चिंचवड महानगरपालिका, पिंपरी – ४११ ०१८</h3>")
            append("<h2 class='center'>GIS Mapping दाखला</h2>")
            append("<p>१) <b>कामाचे नाव –</b> $workName</p>")
            append("<p>२) <b>निविदा क्रमांक –</b> ${project.tenderNumber}</p>")
            append("<p>सदर कामाअंतर्गत केलेल्या कामाची GIS Mapping नोंद घेण्यात आलेली असून, सदर कामाची बिल अदायगी करणेत यावी.</p>")
            append("<br><br><br>")
            append("<div class='right'><p><b>कार्यकारी अभियंता (स्था)</b><br>क क्षेत्रीय कार्यालय<br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी – ४११ ०१८</p></div>")
            append("</div>")
            
            // Page 8: Office Note (Quantity Variation)
            append("<div>")
            append("<div style='display: flex; justify-content: space-between;'><div><b>कार्यालयीन टिपणी</b></div><div><b>क क्षेत्रीय, स्थापत्य विभाग</b></div></div>")
            append("<p><b>विषय -</b> $workName</p>")
            append("<p><b>निविदा नोटीस क्र.</b> ${project.tenderNumber}</p>")
            append("<p><b>मा.स.सादर,</b></p>")
            append("<p>उपरोक्त विषयांकीत कामाचा आदेश ठेकेदार $contractorName यांना देण्यात आला असून कामाचा स्विकृत निविदा दर कमी/जास्त इतका आहे. त्यानुसार आवश्यकतेनुसार इतर अनुषंगिक कामे करणे गरजेचे आहे. परंतु सदर कामे केल्यास मुळ निविदेतील काही बाबींच्या परिमाणात वाढ होणार आहे. सदर बाबींमुळे मुळ निविदा रक्कम बदलत नसून उर्वरीत बाबींच्या बचतीमधून सदर वाढीव परिमाणाचे काम करता येणार आहे.</p>")
            append("<p>तरी सोबत जोडलेल्या Quantity Variation Sheet प्रमाणे सुधारीत परिमाणास मान्यता घेणेकामी स्वाक्षरीस्तव सविनय सादर.</p>")
            append("<br><br><br>")
            append("<div style='display: flex; justify-content: space-between; text-align: center;'><div><b>उप अभियंता (स्था)</b><br>क क्षेत्रीय कार्यालय<br>पिं.चिं.महानगरपालिका</div><div><b>कार्यकारी अभियंता (स्था)</b><br>क क्षेत्रीय कार्यालय<br>पिं.चिं.महानगरपालिका</div><div><b>सह शहर अभियंता</b><br>पिंपरी चिंचवड महानगरपालिका,<br>पिंपरी-४११ ०१८</div></div>")
            append("</div>")

            append("</body></html>")
        }
        
        printHtml(context, html, "Certificates_${raBill.billNumber}", landscape = false)
        return "Opening PDF Preview..."
    }
}
"""

with open('./app/src/main/java/com/example/utils/ExcelExport.kt', 'w') as f:
    f.write(code)
