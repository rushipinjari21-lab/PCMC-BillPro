import re

with open('./app/src/main/java/com/example/viewmodel/QuantityVariationViewModel.kt', 'r') as f:
    content = f.read()

export_function = """
    fun exportQuantityVariation(context: android.content.Context, sapWorkKey: String, variationId: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val variation = dao.getQuantityVariationById(variationId)
                val boq = dao.getBoqByWorkKey(sapWorkKey)
                if (project != null && variation != null && boq != null) {
                    val boqItems = dao.getBoqItems(boq.id).first()
                    val qvItems = dao.getQuantityVariationItems(variationId).first()
                    val path = com.example.utils.ExcelExport.exportQuantityVariationToCsv(context, project, variation, boqItems, qvItems)
                    onResult("Exported to $path")
                } else {
                    onResult("Missing project or QV data for export")
                }
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }
"""

content = content.replace("    fun clearError() {", export_function + "\n    fun clearError() {")

with open('./app/src/main/java/com/example/viewmodel/QuantityVariationViewModel.kt', 'w') as f:
    f.write(content)
