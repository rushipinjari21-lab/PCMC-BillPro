import re

# --- 1. Fix MeasurementScreen Scrolling ---
with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'r') as f:
    mb_content = f.read()

mb_content = mb_content.replace(
'''    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {''',
'''    ) { innerPadding ->
        val scrollState = androidx.compose.foundation.rememberScrollState()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .androidx.compose.foundation.verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {'''
)

# We can't have a LazyColumn inside a vertically scrollable Column unless it has a fixed height,
# but it's easier to change the LazyColumn to a Column with a loop if we are making the parent scrollable.
lazy_column_str = '''            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(measurements, key = { it.id }) { m ->
                    MeasurementRowCard(m)
                }
            }'''

column_str = '''            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                measurements.forEach { m ->
                    MeasurementRowCard(m)
                }
            }'''

mb_content = mb_content.replace(lazy_column_str, column_str)

with open('./app/src/main/java/com/example/ui/mb/MeasurementScreen.kt', 'w') as f:
    f.write(mb_content)


# --- 2. Fix RaBillScreen Dialog Scrolling and Certificate Button ---
with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'r') as f:
    rabill_content = f.read()

rabill_dialog_scroll_target = '''            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {'''
rabill_dialog_scroll_replacement = '''            val scrollState = androidx.compose.foundation.rememberScrollState()
            Column(
                modifier = Modifier.androidx.compose.foundation.verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {'''
rabill_content = rabill_content.replace(rabill_dialog_scroll_target, rabill_dialog_scroll_replacement)


# Now let's fix the buttons in RaBillCard
rabill_buttons_target = '''            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Row {
                        IconButton(onClick = { 
                            viewModel.exportCertificates(context, bill.sapWorkKey, bill.id) { result ->
                                android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) {
                            Icon(Icons.Default.List, contentDescription = "Export Certificates (Marathi)")
                        }
                        IconButton(onClick = { 
                            viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                                android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) {
                            Icon(Icons.Default.Download, contentDescription = "Export Bill")
                        }
                    }
                }
                Text(
                    text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(bill.date)),
                    style = MaterialTheme.typography.bodySmall
                )
            }'''

rabill_buttons_replacement = '''            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = bill.billNumber, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(bill.date)),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { 
                        viewModel.exportRaBill(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RA Bill")
                }
                
                Button(
                    onClick = { 
                        viewModel.exportCertificates(context, bill.sapWorkKey, bill.id) { result ->
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("दाखला (Certificates)")
                }
            }'''

rabill_content = rabill_content.replace(rabill_buttons_target, rabill_buttons_replacement)

with open('./app/src/main/java/com/example/ui/rabill/RaBillScreen.kt', 'w') as f:
    f.write(rabill_content)

