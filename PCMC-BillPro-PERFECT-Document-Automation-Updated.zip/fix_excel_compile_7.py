import re

for file_path in [
    'app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt',
    'app/src/main/java/com/example/ui/mb/MeasurementScreen.kt',
    'app/src/main/java/com/example/ui/rabill/RaBillScreen.kt'
]:
    with open(file_path, 'r') as f:
        content = f.read()
    
    content = content.replace('androidx.compose.material.icons.filled.List', 'Icons.Default.Menu')
    
    with open(file_path, 'w') as f:
        f.write(content)
