import re

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

# Add exportCertificatesExcel
cert_excel_func = """
    @android.annotation.SuppressLint("NewApi")
    fun exportCertificatesExcel(context: android.content.Context, sapWorkKey: String, billId: Long, docIndex: Int? = null, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            try {
                val project = dao.getProjectByWorkKey(sapWorkKey)
                val bill = dao.getRaBillById(billId)
                if (project != null && bill != null) {
                    val html = com.example.utils.PdfDocketGenerator.getCertificatesHtml(project, bill, docIndex)
                    
                    val suffix = docIndex?.toString() ?: "All"
                    val fileName = "Certificates_${bill.billNumber}_${suffix}.xls"
                    
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.ms-excel")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        uri?.let {
                            context.contentResolver.openOutputStream(it)?.use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel file saved to Downloads: $fileName")
                        } ?: run {
                            onResult("Failed to create file")
                        }
                    } else {
                        try {
                            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                            val file = java.io.File(downloadsDir, fileName)
                            file.outputStream().use { outputStream ->
                                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                                outputStream.write(html.toByteArray(Charsets.UTF_8))
                            }
                            onResult("Excel file saved to Downloads: $fileName")
                        } catch (e: Exception) {
                            e.printStackTrace()
                            onResult("Failed to save file: ${e.message}")
                        }
                    }
                } else {
                    onResult("Missing project or Bill data")
                }
            } catch (e: Exception) {
                onResult("Error: ${e.message}")
            }
        }
    }
"""

if "fun exportCertificatesExcel" not in content:
    content = content.replace("fun getCertificatesHtml(", cert_excel_func + "\n    fun getCertificatesHtml(")

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
