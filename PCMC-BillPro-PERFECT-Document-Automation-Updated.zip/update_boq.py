import re

with open('./app/src/main/java/com/example/ui/boq/BoqScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'sapWorkKey: String,\n    onNavigateBack: () -> Unit\n)',
    'sapWorkKey: String,\n    onNavigateBack: () -> Unit,\n    onNavigateToMb: () -> Unit = {}\n)'
)

content = content.replace(
    'items(boqItems, key = { it.id }) { item ->\n                    BoqItemCard(item)\n                }',
    '''item {
                    Button(onClick = onNavigateToMb, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text("Next: Go to Measurement Book")
                    }
                }
                items(boqItems, key = { it.id }) { item ->
                    BoqItemCard(item)
                }'''
)

with open('./app/src/main/java/com/example/ui/boq/BoqScreen.kt', 'w') as f:
    f.write(content)

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'r') as f:
    nav_content = f.read()

nav_content = nav_content.replace(
    'onNavigateBack = { navController.popBackStack() }\n            )',
    'onNavigateBack = { navController.popBackStack() },\n                onNavigateToMb = { navController.navigate(Screen.MeasurementBook.createRoute(sapWorkKey)) }\n            )'
)

with open('./app/src/main/java/com/example/ui/navigation/AppNavigation.kt', 'w') as f:
    f.write(nav_content)
