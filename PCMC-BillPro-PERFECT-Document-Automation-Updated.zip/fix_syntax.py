import re

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "r") as f:
    content = f.read()

bad_string = "append(\".list-content { flex: 1; }            append(\\\".no-border td { border: none !important; padding: 4px; }\\\")\")"
good_string = "append(\".list-content { flex: 1; }\")\n            append(\".no-border td { border: none !important; padding: 4px; }\")"

content = content.replace("append(\".list-content { flex: 1; }            append(\".no-border td { border: none !important; padding: 4px; }\")\")", good_string)

with open("app/src/main/java/com/example/utils/PdfDocketGenerator.kt", "w") as f:
    f.write(content)

print("Fixed syntax")
