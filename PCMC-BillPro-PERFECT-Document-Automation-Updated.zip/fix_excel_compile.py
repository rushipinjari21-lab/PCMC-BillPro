import re

# Fix Icons
for file_path in [
    'app/src/main/java/com/example/ui/certificates/CertificatesScreen.kt',
    'app/src/main/java/com/example/ui/mb/MeasurementScreen.kt',
    'app/src/main/java/com/example/ui/rabill/RaBillScreen.kt'
]:
    with open(file_path, 'r') as f:
        content = f.read()
    
    content = content.replace('androidx.compose.material.icons.filled.TableChart', 'androidx.compose.material.icons.Icons.Default.Assessment')
    
    with open(file_path, 'w') as f:
        f.write(content)

# Fix MeasurementViewModel
with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'r') as f:
    content = f.read()
content = content.replace('${m.nos}', '${m.number}')
with open('app/src/main/java/com/example/viewmodel/MeasurementViewModel.kt', 'w') as f:
    f.write(content)

# Fix RaBillViewModel
with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace('billItem?.thisBillQuantity', 'billItem?.currentQuantity')
content = content.replace('item.quantity', 'item.boqQuantity')

with open('app/src/main/java/com/example/viewmodel/RaBillViewModel.kt', 'w') as f:
    f.write(content)
