# PCMC BillPro - Agent Instructions & Automation Rules

## MEASUREMENT BOOK (MB) AUTOMATION RULES

### 1. BULK ENTRIES PRESERVATION
- **Never summarize or omit measurement lines.** Process every single line item provided in the input or uploaded files.

### 2. CROSS-ITEM ENTRY TRANSFORMATIONS
When instructed to "Copy/Derive Item X to Item Y", apply the following transformation matrices:
- **To Plaster / Paint (from Brickwork):** Set Nos = Source_Nos * 2 (for both faces), Length = Source_L, Height = Source_H, Breadth = 0.
- **To Wall Area / Putty:** Set Length = Source_L, Height = Source_H, Breadth = 0.
- **To Flooring / PCC Bed (from Excavation):** Set Length = Source_L, Breadth = Source_B, Height = override_depth or 0.10m.

### 3. CIRCULAR GEOMETRY & TREE KATTA EXPANSION
When the user specifies a circular tree katta or circular chamber with:
- Inner Diameter (Din), Wall Thickness (t), Height (H), Foundation Depth (df), PCC Depth (dpcc), and Quantity (Nos):
Calculate the following standard dimensions:
* Dmean = Din + t
* Douter = Din + (2 * t)
* Mean Length (L_mean) = 3.1416 * Dmean
* Outer Length (L_out) = 3.1416 * Douter
* Inner Length (L_in) = 3.1416 * Din
* Trench Width (B_trench) = t + 0.15
* Coping Width (B_coping) = t + 0.05

Automatically generate and append the following 6 distinct MB line entries:
1. **Excavation (CUM):** Nos = Nos, L = L_mean, B = B_trench, H = df
2. **PCC Base (CUM):** Nos = Nos, L = L_mean, B = B_trench, H = dpcc
3. **Brick Masonry (CUM):** Nos = Nos, L = L_mean, B = t, H = H
4. **Outer Plaster (SQM):** Nos = Nos, L = L_out, B = 0, H = H
5. **Inner Plaster (SQM):** Nos = Nos, L = L_in, B = 0, H = H
6. **Top Coping Stone (SQM):** Nos = Nos, L = L_mean, B = B_coping, H = 0
